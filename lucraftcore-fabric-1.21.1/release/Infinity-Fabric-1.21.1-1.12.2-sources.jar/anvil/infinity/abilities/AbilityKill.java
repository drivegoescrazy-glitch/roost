package anvil.infinity.abilities;

import anvil.infinity.conditions.ICondition;
import anvil.infinity.registry.InfinityEffects;
import anvil.infinity.items.ItemSoulStone;
import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import lucraft.mods.lucraftcore.superpowers.abilities.AbilityTargeting;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Kill: dusts the entity the player is looking at. The original asked the
 * client for its crosshair target; the port raycasts on the server with the
 * player's own interaction range, which reaches the same entity.
 */
public class AbilityKill extends Ability {

    private final ICondition<class_1309> condition;

    public AbilityKill(class_3222 player) {
        this(player, ItemSoulStone::canKill);
    }

    public AbilityKill(class_3222 player, ICondition<class_1309> condition) {
        super(player);
        this.condition = condition;
    }

    @Override
    public String getId() {
        return "kill";
    }

    @Override
    public AbilityType getType() {
        return AbilityType.ACTION;
    }

    @Override
    protected boolean onUse() {
        if (!condition.isFulfilled(player))
            return false;

        class_3218 world = player.method_51469();
        class_243 eye = player.method_33571();
        class_243 direction = player.method_5828(1.0F);
        class_1309 target = AbilityTargeting.findTarget(world, player, eye, direction,
                player.method_55755());
        if (target == null)
            return false;

        var entry = class_7923.field_41174.method_47983(InfinityEffects.SNAP);
        if (entry == null)
            return false;
        target.method_6092(new class_1293(entry, 1));
        return true;
    }
}
