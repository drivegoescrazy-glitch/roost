package lucraft.mods.lucraftcore.superpowers;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.effects.EffectHandler;
import lucraft.mods.lucraftcore.superpowers.suitsets.SuitSet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;
import java.util.List;

public class ModuleSuperpowers {

    public static void register() {
        // Touch the attachment type during mod initialization. Player data is
        // deserialized before the first join callback, so loading this class
        // lazily from the tick would make Fabric skip the saved ability map
        // with "Unknown attachment type lucraftcore:abilities".
        PlayerAbilities.registerAttachments();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                String who = player.method_5477().getString();

                LucraftCore.guard("ability tick of " + who, () -> {
                    PlayerAbilities.tickSuit(player);
                    PlayerAbilities.tickPower(player);
                    PlayerAbilities.tick(player);
                    PlayerAbilities.tickGauntlet(player);
                });

                LucraftCore.guard("effect tick of " + who, () -> {
                    SuitSet worn = SuitSet.getWornSuit(player);
                    EffectHandler.tick(player, "suit", worn == null ? List.of() : worn.getEffects());
                    Superpower power = SuperpowerHandler.getPower(player);
                    EffectHandler.tick(player, "power", power == null ? List.of() : power.getEffects());
                });

                if (player.field_6012 % 20 == 0)
                    LucraftCore.guard("ability bar of " + who, () -> AbilityBarSync.send(player));
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                LucraftCore.guard("player ability sync for " + handler.field_14140.method_5477().getString(),
                        () -> PlayerAbilities.sync(handler.field_14140)));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            LucraftCore.guard("player ability cleanup for " + handler.field_14140.method_5477().getString(),
                    () -> PlayerAbilities.clear(handler.field_14140));
            LucraftCore.guard("effect cleanup for " + handler.field_14140.method_5477().getString(),
                    () -> EffectHandler.clearAll(handler.field_14140));
        });
        // An integrated server is stopped when leaving a world. Cached abilities
        // belong to the old server instance and must not leak into the next one.
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            PlayerAbilities.clearAll();
            EffectHandler.clearAll();
        });

        CommandAbility.register();
        CommandSuperpower.register();

        LucraftCore.LOGGER.info("Superpowers module registered: {} abilities", AbilityRegistry.ABILITIES.size());
    }
}
