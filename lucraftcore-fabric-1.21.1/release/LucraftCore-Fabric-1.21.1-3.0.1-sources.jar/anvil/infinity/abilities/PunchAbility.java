package anvil.infinity.abilities;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.Ability;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/**
 * The 1.12 Power Stone punch added {@code Float.MAX_VALUE} extra damage to
 * unarmed hits through Lucraft's own PUNCH_DAMAGE attribute. Modern Minecraft
 * has no such attribute, so the bonus is applied as a temporary attack-damage
 * modifier while the main hand is empty.
 *
 * <p>When the strength ability is active it already gives the same maximum
 * attack damage; adding a second maximum modifier would overflow the float
 * damage calculation, so the punch modifier is skipped in that case.</p>
 */
public class PunchAbility extends Ability {

    private static final class_2960 MODIFIER_ID = LucraftCore.id("ability_infinity_punch");

    public PunchAbility(class_3222 player) {
        super(player);
    }

    @Override
    public String getId() {
        return "infinity_punch";
    }

    @Override
    protected void onEnabled() {
        update();
    }

    @Override
    protected void onTick() {
        update();
    }

    @Override
    protected void onDisabled() {
        remove();
    }

    @Override
    protected void cleanup() {
        remove();
    }

    private void update() {
        class_1324 instance = player.method_5996(class_5134.field_23721);
        if (instance == null)
            return;
        // AttributeAbility uses this id for the Power Stone strength modifier.
        boolean strengthActive = instance.method_6199(LucraftCore.id("ability_infinity_strength")) != null;
        boolean shouldApply = player.method_6047().method_7960() && !strengthActive;
        if (!shouldApply) {
            instance.method_6200(MODIFIER_ID);
            return;
        }
        if (instance.method_6199(MODIFIER_ID) == null)
            instance.method_26837(new class_1322(MODIFIER_ID,
                    Float.MAX_VALUE, class_1322.class_1323.field_6328));
    }

    private void remove() {
        class_1324 instance = player.method_5996(class_5134.field_23721);
        if (instance != null)
            instance.method_6200(MODIFIER_ID);
    }
}
