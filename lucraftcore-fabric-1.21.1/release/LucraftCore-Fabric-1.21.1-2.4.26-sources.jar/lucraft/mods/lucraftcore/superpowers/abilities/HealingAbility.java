package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import net.minecraft.class_3222;

public class HealingAbility extends Ability {

    private final int frequency;
    private final float amount;

    public HealingAbility(class_3222 player, int frequency, float amount) {
        super(player);
        this.frequency = frequency;
        this.amount = amount;
    }

    @Override
    public String getId() {
        return "healing";
    }

    @Override
    protected void onTick() {
        if (frequency > 0 && ticks % frequency == 0)
            player.method_6025(amount);
    }
}
