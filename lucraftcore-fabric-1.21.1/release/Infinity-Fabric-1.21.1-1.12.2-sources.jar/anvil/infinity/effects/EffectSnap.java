package anvil.infinity.effects;

import anvil.infinity.helpers.SnapMessageHelper;
import anvil.infinity.registry.InfinitySounds;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3419;
import net.minecraft.class_4081;


/**
 * "Dusted": one tick before the effect runs out the target disintegrates with
 * the snap sound and the dusting message, exactly like the original effect.
 */
public class EffectSnap extends class_1291 {

    public EffectSnap() {
        super(class_4081.field_18272, 0x4B0F4B);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        // The original checked for a remaining duration of exactly one tick.
        return duration == 1;
    }

    @Override
    public boolean method_5572(class_1309 entity, int amplifier) {
        class_1937 world = entity.method_37908();
        world.method_43128(null, entity.method_23317(), entity.method_23318(), entity.method_23321(), InfinitySounds.SNAP,
                class_3419.field_15251, 5.0F, 0.0F);
        if (entity.method_16914() || entity instanceof class_1657)
            SnapMessageHelper.deathMessage(entity);
        entity.method_5768();
        return true;
    }

}
