package lucraft.mods.lucraftcore.infinity.items;

import net.minecraft.class_1792;

/** Base for infinity equipment: one per stack and immune to fire and lava. */
public class ItemIndestructible extends class_1792 {

    public ItemIndestructible() {
        super(new class_1792.class_1793().method_7889(1).method_24359());
    }
}
