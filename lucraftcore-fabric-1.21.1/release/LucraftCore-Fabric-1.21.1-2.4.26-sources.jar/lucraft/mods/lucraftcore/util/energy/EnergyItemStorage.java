package lucraft.mods.lucraftcore.util.energy;

import lucraft.mods.lucraftcore.util.LCComponents;
import net.minecraft.class_1799;

/** Energy buffer backed by the {@code lucraftcore:energy} item component. */
public class EnergyItemStorage extends EnergyStorage {

    private final class_1799 stack;

    public EnergyItemStorage(class_1799 stack, int capacity) {
        this(stack, capacity, capacity, capacity);
    }

    public EnergyItemStorage(class_1799 stack, int capacity, int maxTransfer) {
        this(stack, capacity, maxTransfer, maxTransfer);
    }

    public EnergyItemStorage(class_1799 stack, int capacity, int maxReceive, int maxExtract) {
        super(capacity, maxReceive, maxExtract, getStored(stack));
        this.stack = stack;
        setEnergyStored(getStored(stack));
    }

    public static boolean isEnergyItem(class_1799 stack) {
        return !stack.method_7960() && stack.method_57824(LCComponents.ENERGY) != null;
    }

    public static int getStored(class_1799 stack) {
        if (stack.method_7960())
            return 0;
        Integer stored = stack.method_57824(LCComponents.ENERGY);
        return stored == null ? 0 : stored;
    }

    public static void setStored(class_1799 stack, int energy) {
        if (!stack.method_7960())
            stack.method_57379(LCComponents.ENERGY, Math.max(0, energy));
    }

    @Override
    public int getEnergyStored() {
        return getStored(stack);
    }

    @Override
    public void setEnergyStored(int energy) {
        setStored(stack, Math.min(getMaxEnergyStored(), Math.max(0, energy)));
    }
}
