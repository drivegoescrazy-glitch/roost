package lucraft.mods.lucraftcore.superpowers.suitsets;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;

public class SuitSetRegistry {

    private static final Map<class_2960, SuitSet> SUITS = new LinkedHashMap<>();

    public static void register(SuitSet suit) {
        SUITS.put(suit.getId(), suit);
    }

    public static SuitSet get(class_2960 id) {
        return SUITS.get(id);
    }

    public static List<SuitSet> getAll() {
        return new ArrayList<>(SUITS.values());
    }

    public static int size() {
        return SUITS.size();
    }
}
