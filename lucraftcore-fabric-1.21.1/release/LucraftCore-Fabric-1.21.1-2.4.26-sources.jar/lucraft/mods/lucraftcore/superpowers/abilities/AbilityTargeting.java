package lucraft.mods.lucraftcore.superpowers.abilities;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/** Shared target selection for punch and beam abilities. */
public final class AbilityTargeting {

    private AbilityTargeting() {
    }

    /**
     * Finds the closest living entity in the direction the player is looking,
     * within the given distance and cone.
     */
    public static class_1309 findTarget(class_3218 world, class_1657 player, class_243 eye, class_243 direction, double maxDistance) {
        class_1309 best = null;
        double bestDistance = maxDistance;
        class_238 box = player.method_5829().method_1014(maxDistance);
        for (class_1297 entity : world.method_8335(player, box)) {
            if (!(entity instanceof class_1309 living) || !living.method_5805() || entity.method_7325())
                continue;
            class_243 to = living.method_5829().method_1005().method_1020(eye);
            double distance = to.method_1033();
            if (distance < 0.001D || distance > maxDistance)
                continue;
            if (to.method_1029().method_1026(direction) < 0.75D)
                continue;
            if (distance < bestDistance) {
                bestDistance = distance;
                best = living;
            }
        }
        return best;
    }
}
