package anvil.infinity.helpers;

import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/** Whether a living entity wears a gauntlet that contains a given stone. */
public final class GauntletHelper {

    private GauntletHelper() {
    }

    public static boolean hasStone(class_1309 entity, EnumInfinityStone stone) {
        return hasStoneIn(entity, class_1268.field_5808, stone) || hasStoneIn(entity, class_1268.field_5810, stone);
    }

    private static boolean hasStoneIn(class_1309 entity, class_1268 hand, EnumInfinityStone stone) {
        class_1799 stack = entity.method_5998(hand);
        if (stack.method_7960() || !(stack.method_7909() instanceof ItemInfinityGauntlet))
            return false;
        return ItemInfinityGauntlet.hasStone(stack, stone);
    }

    public static boolean hasPowerStone(class_1309 entity) {
        return hasStone(entity, EnumInfinityStone.POWER);
    }

    public static boolean hasSpaceStone(class_1309 entity) {
        return hasStone(entity, EnumInfinityStone.SPACE);
    }

    public static boolean hasRealityStone(class_1309 entity) {
        return hasStone(entity, EnumInfinityStone.REALITY);
    }

    public static boolean hasSoulStone(class_1309 entity) {
        return hasStone(entity, EnumInfinityStone.SOUL);
    }

    public static boolean hasTimeStone(class_1309 entity) {
        return hasStone(entity, EnumInfinityStone.TIME);
    }

    public static boolean hasMindStone(class_1309 entity) {
        return hasStone(entity, EnumInfinityStone.MIND);
    }

    public static boolean hasFullGauntlet(class_1309 entity) {
        return hasPowerStone(entity) && hasSpaceStone(entity) && hasRealityStone(entity)
                && hasSoulStone(entity) && hasTimeStone(entity) && hasMindStone(entity);
    }
}
