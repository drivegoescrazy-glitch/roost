package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.List;

/**
 * Runs commands when the ability is used, granted or revoked. Replaces the
 * original command abilities (use / on gain / on lose / loop).
 */
public class CommandRunnerAbility extends Ability {

    private final AbilityConfig config;

    public CommandRunnerAbility(class_3222 player, AbilityConfig config) {
        super(player);
        this.config = config;
    }

    @Override
    public String getId() {
        return config.abilityId();
    }

    @Override
    public AbilityType getType() {
        return AbilityType.ACTION;
    }

    @Override
    protected boolean onUse() {
        return run(config.getStringList("commands", "command"));
    }

    @Override
    public void onGrant() {
        super.onGrant();
        run(config.getStringList("grant_commands"));
    }

    @Override
    public void onRevoke() {
        run(config.getStringList("revoke_commands"));
        super.onRevoke();
    }

    @Override
    protected void onTick() {
        List<String> loop = config.getStringList("loop_commands");
        if (loop.isEmpty())
            return;
        int interval = Math.max(1, config.getInt("interval", 20));
        if (ticks % interval == 0)
            run(loop);
    }

    private boolean run(List<String> commands) {
        if (commands.isEmpty())
            return false;
        MinecraftServer server = player.method_5682();
        if (server == null)
            return false;
        class_2168 source = server.method_3739().method_9232(player).method_9217()
                .method_9208(player.method_19538());
        for (String command : commands)
            server.method_3734().method_44252(source, command);
        return true;
    }
}
