package lucraft.mods.lucraftcore.utilities.recipes;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

/** One extractor recipe: item in, item out, paid for with FE over time. */
public record ExtractorRecipe(class_1792 input, int inputCount, class_1799 output, int energy, int time) {

    public boolean matches(class_1799 stack) {
        return !stack.method_7960() && stack.method_31574(input) && stack.method_7947() >= inputCount;
    }

    public int energyPerTick() {
        return time <= 0 ? energy : Math.max(1, energy / time);
    }
}
