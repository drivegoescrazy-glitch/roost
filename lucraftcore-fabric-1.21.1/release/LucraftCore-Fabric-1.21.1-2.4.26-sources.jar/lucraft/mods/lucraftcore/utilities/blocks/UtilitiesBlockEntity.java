package lucraft.mods.lucraftcore.utilities.blocks;

import lucraft.mods.lucraftcore.util.inventory.StackInventory;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/** Base for the mod's machines: carries an inventory that is saved to NBT. */
public abstract class UtilitiesBlockEntity extends class_2586 implements class_1263 {

    protected final StackInventory inventory;

    protected UtilitiesBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state, int slots, int... outputSlots) {
        this(type, pos, state, new StackInventory(slots, outputSlots));
    }

    protected UtilitiesBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state, StackInventory inventory) {
        super(type, pos, state);
        this.inventory = inventory;
        this.inventory.method_5489(inv -> this.method_5431());
    }

    public StackInventory getInventory() {
        return inventory;
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10566("Inventory", inventory.method_7660(registries));
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        inventory.method_7659(nbt.method_10554("Inventory", 10), registries);
    }

    // Inventory delegation so hoppers and other vanilla automation can use machines.
    @Override
    public int method_5439() {
        return inventory.method_5439();
    }

    @Override
    public boolean method_5442() {
        return inventory.method_5442();
    }

    @Override
    public class_1799 method_5438(int slot) {
        return inventory.method_5438(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 stack = inventory.method_5434(slot, amount);
        method_5431();
        return stack;
    }

    @Override
    public class_1799 method_5441(int slot) {
        class_1799 stack = inventory.method_5441(slot);
        method_5431();
        return stack;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        inventory.method_5447(slot, stack);
        method_5431();
    }

    @Override
    public int method_5444() {
        return inventory.method_5444();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return inventory.method_5437(slot, stack);
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        inventory.method_5448();
        method_5431();
    }
}
