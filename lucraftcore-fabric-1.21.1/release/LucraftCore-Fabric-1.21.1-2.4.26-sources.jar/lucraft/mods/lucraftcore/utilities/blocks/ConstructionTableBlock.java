package lucraft.mods.lucraftcore.utilities.blocks;

import com.mojang.serialization.MapCodec;
import lucraft.mods.lucraftcore.utilities.recipes.InstructionRecipe;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

/**
 * Instruction-driven crafting station. Right-click with an instruction item to
 * craft the first affordable recipe; sneak-right-click lists the recipes.
 */
public class ConstructionTableBlock extends class_2237 {

    public static final class_2753 FACING = class_2383.field_11177;

    public ConstructionTableBlock(class_4970.class_2251 settings) {
        super(settings);
        method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(ConstructionTableBlock::new);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ConstructionTableBlockEntity(pos, state);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.field_9236)
            return class_1269.field_5812;
        if (!(world.method_8321(pos) instanceof ConstructionTableBlockEntity table))
            return class_1269.field_5811;
        class_1799 held = player.method_6047();
        if (table.getRecipes(held).isEmpty()) {
            player.method_7353(class_2561.method_43471("lucraftcore.info.noinstructionrecipes"), true);
            return class_1269.field_5812;
        }
        if (player.method_5715()) {
            for (InstructionRecipe recipe : table.getRecipes(held))
                player.method_7353(recipe.getOutput().method_7964().method_27661(), false);
            return class_1269.field_5812;
        }
        if (table.craftFrom(player, held)) {
            player.method_7353(class_2561.method_43471("lucraftcore.info.crafted"), true);
            player.method_6104(class_1268.field_5808);
        } else {
            player.method_7353(class_2561.method_43471("lucraftcore.info.missingrequirements"), true);
        }
        return class_1269.field_5812;
    }

    @Override
    protected void method_9515(class_2689.class_2690<net.minecraft.class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, net.minecraft.class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!world.field_9236 && !state.method_27852(newState.method_26204())
                && world.method_8321(pos) instanceof UtilitiesBlockEntity machine)
            class_1264.method_5451(world, pos, machine);
        super.method_9536(state, world, pos, newState, moved);
    }
}
