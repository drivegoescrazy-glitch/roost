package anvil.infinity.command;

import anvil.infinity.abilities.AbilityLocate;
import anvil.infinity.compat.CompatHandler;
import anvil.infinity.config.InfinityConfig;
import anvil.infinity.worldgen.WorldData;
import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.PlayerAbilities;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import java.util.Map;

/** {@code /generatedStones}: which stones have generated, and where if permitted. */
public final class GeneratedStonesCommand {

    private GeneratedStonesCommand() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("generatedStones")
                        .executes(context -> execute(context.getSource()))));
    }

    public static int execute(class_2168 source) {
        class_3222 player = source.method_44023();
        boolean locate = player != null && hasLocate(player);
        if (player != null && CompatHandler.isHeroesExpansion())
            locate = locate || CompatHandler.heroesExpansionCanLocate(player);

        WorldData data = WorldData.get(source.method_9225());
        class_5250 message = class_2561.method_43470("Generated: ");
        message.method_27693("\n Space Stone: " + data.space);
        if (locate)
            message.method_27693("\n X: " + data.spacex + "\n Z: " + data.spacez + "\n Dim: " + InfinityConfig.spaceDim);
        message.method_27693("\n Power Stone: " + data.power);
        if (locate)
            message.method_27693("\n X: " + data.powerx + "\n Z: " + data.powerz + "\n Dim: " + InfinityConfig.powerDim);
        message.method_27693("\n Mind Stone: " + data.mind);
        if (locate)
            message.method_27693("\n X: " + data.mindx + "\n Z: " + data.mindz + "\n Dim: " + InfinityConfig.mindDim);
        message.method_27693("\n Soul Stone: " + data.soul);
        if (locate)
            message.method_27693("\n X: " + data.soulx + "\n Z: " + data.soulz + "\n Dim: " + InfinityConfig.soulDim);
        message.method_27693("\n Time Stone: " + data.time);
        if (locate)
            message.method_27693("\n X: " + data.timex + "\n Z: " + data.timez + "\n Dim: " + InfinityConfig.timeDim);
        message.method_27693("\n Reality Stone: " + data.reality);
        if (locate)
            message.method_27693("\n X: " + data.realityx + "\n Z: " + data.realityz
                    + "\n Dim: " + InfinityConfig.realityDim);

        class_5250 result = message;
        source.method_9226(() -> result, false);
        return 1;
    }

    /** The original checked for the locate ability on the command sender. */
    private static boolean hasLocate(class_3222 player) {
        Map<String, Ability> displayed = PlayerAbilities.getDisplayed(player);
        return displayed.containsKey(AbilityLocate.ID);
    }
}
