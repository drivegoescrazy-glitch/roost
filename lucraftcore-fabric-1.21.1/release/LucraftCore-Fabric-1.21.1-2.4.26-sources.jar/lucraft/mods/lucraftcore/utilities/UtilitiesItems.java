package lucraft.mods.lucraftcore.utilities;

import lucraft.mods.lucraftcore.LucraftCore;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Items that used to live in the utilities module (crafting tools and components). */
public class UtilitiesItems {

    public static final List<class_1792> ALL = new ArrayList<>();
    public static final Map<String, class_1792> TRI_POLYMER = new LinkedHashMap<>();

    /** Same order as the original EnumDyeColor names (silver = light gray). */
    public static final String[] TRI_POLYMER_COLOURS = {
            "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
            "silver", "cyan", "purple", "blue", "brown", "green", "red", "black"
    };

    public static class_1792 HAMMER;
    public static class_1792 WIRE_CUTTER;
    public static class_1792 INJECTION;
    public static class_1792 INSTRUCTION;
    public static class_1792 LV_CAPACITOR;
    public static class_1792 MV_CAPACITOR;
    public static class_1792 HV_CAPACITOR;
    public static class_1792 SERVO_MOTOR;
    public static class_1792 BASIC_CIRCUIT;
    public static class_1792 ADVANCED_CIRCUIT;
    public static class_1761 GROUP;

    public static void register() {
        HAMMER = register("hammer", new ItemHammer());
        WIRE_CUTTER = register("wire_cutter", new ItemHammer());
        INJECTION = register("injection", new ItemInjection());
        INSTRUCTION = register("instruction", new ItemInstruction());
        LV_CAPACITOR = register("lv_capacitor", new class_1792(new class_1792.class_1793()));
        MV_CAPACITOR = register("mv_capacitor", new class_1792(new class_1792.class_1793()));
        HV_CAPACITOR = register("hv_capacitor", new class_1792(new class_1792.class_1793()));
        SERVO_MOTOR = register("servo_motor", new class_1792(new class_1792.class_1793()));
        BASIC_CIRCUIT = register("basic_circuit", new class_1792(new class_1792.class_1793()));
        ADVANCED_CIRCUIT = register("advanced_circuit", new class_1792(new class_1792.class_1793()));

        for (String colour : TRI_POLYMER_COLOURS) {
            TRI_POLYMER.put(colour, register("tri_polymer_" + colour, new class_1792(new class_1792.class_1793())));
        }

        GROUP = class_2378.method_10230(class_7923.field_44687, LucraftCore.id("lucraftcore"),
                FabricItemGroup.builder()
                        .method_47321(class_2561.method_43471("itemGroup.tabLucraftCore"))
                        .method_47320(() -> new class_1799(HAMMER))
                        .method_47317((context, entries) -> {
                            for (class_1792 item : ALL)
                                entries.method_45421(item);
                            for (lucraft.mods.lucraftcore.utilities.recipes.InstructionRecipe recipe
                                    : lucraft.mods.lucraftcore.utilities.recipes.InstructionRecipe.getAll())
                                entries.method_45420(ItemInstruction.createStack(recipe));
                            for (lucraft.mods.lucraftcore.superpowers.suitsets.SuitSet suit
                                    : lucraft.mods.lucraftcore.superpowers.suitsets.SuitSetRegistry.getAll())
                                for (class_1792 piece : suit.getPieces().values())
                                    entries.method_45421(piece);
                            for (class_1792 machine : lucraft.mods.lucraftcore.utilities.blocks.UtilitiesBlocks.ALL_ITEMS)
                                entries.method_45421(machine);
                            for (class_1792 infinity : lucraft.mods.lucraftcore.infinity.ModuleInfinity.ALL_ITEMS)
                                entries.method_45421(infinity);
                        })
                        .method_47324());

        LucraftCore.LOGGER.info("Utilities module registered: {} items", ALL.size());
    }

    private static class_1792 register(String name, class_1792 item) {
        class_2378.method_10230(class_7923.field_41178, LucraftCore.id(name), item);
        ALL.add(item);
        return item;
    }
}
