package lucraft.mods.lucraftcore.utilities.blocks;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_4970;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/** Machine blocks and their block entities. */
public final class UtilitiesBlocks {

    public static final List<class_1792> ALL_ITEMS = new ArrayList<>();

    public static class_2248 CONSTRUCTION_TABLE;
    public static class_2248 SUIT_STAND;
    public static class_2248 EXTRACTOR;
    public static class_2248 BOILER;
    public static class_2248 FURNACE_GENERATOR;

    public static class_2591<ConstructionTableBlockEntity> CONSTRUCTION_TABLE_ENTITY;
    public static class_2591<SuitStandBlockEntity> SUIT_STAND_ENTITY;
    public static class_2591<ExtractorBlockEntity> EXTRACTOR_ENTITY;
    public static class_2591<BoilerBlockEntity> BOILER_ENTITY;
    public static class_2591<FurnaceGeneratorBlockEntity> FURNACE_GENERATOR_ENTITY;

    private UtilitiesBlocks() {
    }

    public static void register() {
        CONSTRUCTION_TABLE = registerBlock("construction_table", ConstructionTableBlock::new);
        SUIT_STAND = registerBlock("suit_stand", SuitStandBlock::new);
        EXTRACTOR = registerBlock("extractor", ExtractorBlock::new);
        BOILER = registerBlock("boiler", BoilerBlock::new);
        FURNACE_GENERATOR = registerBlock("furnace_generator", FurnaceGeneratorBlock::new);

        CONSTRUCTION_TABLE_ENTITY = registerEntity("construction_table", ConstructionTableBlockEntity::new, CONSTRUCTION_TABLE);
        SUIT_STAND_ENTITY = registerEntity("suit_stand", SuitStandBlockEntity::new, SUIT_STAND);
        EXTRACTOR_ENTITY = registerEntity("extractor", ExtractorBlockEntity::new, EXTRACTOR);
        BOILER_ENTITY = registerEntity("boiler", BoilerBlockEntity::new, BOILER);
        FURNACE_GENERATOR_ENTITY = registerEntity("furnace_generator", FurnaceGeneratorBlockEntity::new, FURNACE_GENERATOR);

        LucraftCore.LOGGER.info("Registered {} machine block(s)", ALL_ITEMS.size());
    }

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory) {
        class_2960 id = LucraftCore.id(name);
        class_4970.class_2251 settings = class_4970.class_2251.method_9637().method_9632(3.0F).method_29292();
        class_2248 block = class_2378.method_10230(class_7923.field_41175, id, factory.apply(settings));
        class_1792 item = class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
        ALL_ITEMS.add(item);
        return block;
    }

    @SuppressWarnings("unchecked")
    private static <T extends net.minecraft.class_2586> class_2591<T> registerEntity(
            String name, class_2591.class_5559<? extends T> factory, class_2248 block) {
        class_2591<T> type = (class_2591<T>) class_2591.class_2592.method_20528(factory, block).method_11034(null);
        return class_2378.method_10230(class_7923.field_41181, LucraftCore.id(name), type);
    }

    /** Opens a vanilla chest-style view of the machine's inventory. */
    public static void openMachine(class_1657 player, UtilitiesBlockEntity machine, class_2561 title) {
        class_1263 inventory = machine.getInventory();
        player.method_17355(new class_747((syncId, playerInventory, playerEntity) ->
                new class_1707(class_3917.field_18664, syncId, playerInventory,
                        inventory, 1), title));
    }
}
