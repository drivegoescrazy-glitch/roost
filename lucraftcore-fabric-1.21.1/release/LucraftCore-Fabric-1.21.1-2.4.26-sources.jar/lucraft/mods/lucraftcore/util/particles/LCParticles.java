package lucraft.mods.lucraftcore.util.particles;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_7923;

/** Particle types used by abilities and suits. */
public final class LCParticles {

    /** Soft coloured cloud used by energy blasts and trails. */
    public static final class_2400 COLORED_CLOUD = class_2378.method_10230(
            class_7923.field_41180,
            LucraftCore.id("colored_cloud"),
            new class_2400(false) {
            });

    private LCParticles() {
    }

    public static void register() {
        LucraftCore.LOGGER.debug("Registered particle type colored_cloud");
    }
}
