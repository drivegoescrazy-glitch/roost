package lucraft.mods.lucraftcore.infinity;

import net.minecraft.class_124;

/** The six infinity stones, in the original gauntlet slot order. */
public enum EnumInfinityStone {

    SPACE(class_124.field_1075),
    SOUL(class_124.field_1065),
    REALITY(class_124.field_1061),
    TIME(class_124.field_1060),
    POWER(class_124.field_1076),
    MIND(class_124.field_1054);

    private final class_124 color;

    EnumInfinityStone(class_124 color) {
        this.color = color;
    }

    public class_124 getTextColor() {
        return color;
    }
}
