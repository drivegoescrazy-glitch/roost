package lucraft.mods.lucraftcore.materials;

import lucraft.mods.lucraftcore.LCConfig;
import lucraft.mods.lucraftcore.LucraftCore;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1291;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2893;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModuleMaterials {

    public static final Map<Material, Map<Material.Component, class_1792>> ITEMS = new LinkedHashMap<>();
    public static final Map<Material, class_2248> ORES = new LinkedHashMap<>();
    public static final Map<Material, class_2248> BLOCKS = new LinkedHashMap<>();

    private static class_1291 radiation;
    private static class_6880<class_1291> radiationEntry;
    public static class_1761 GROUP;

    private static final Material.Component[] ITEM_COMPONENTS = {
            Material.Component.INGOT, Material.Component.NUGGET, Material.Component.PLATE,
            Material.Component.DUST, Material.Component.WIRING
    };

    public static void register() {
        if (!LCConfig.materials)
            return;

        radiation = class_2378.method_10230(class_7923.field_41174, LucraftCore.id("radiation"), new RadiationStatusEffect());
        radiationEntry = class_7923.field_41174.method_47983(radiation);

        registerItems();
        registerBlocks();
        registerCreativeTab();
        registerWorldgen();

        LucraftCore.LOGGER.info("Materials module registered: {} materials, {} items, {} blocks",
                Material.ALL.size(), ITEMS.values().stream().mapToInt(Map::size).sum(), ORES.size() + BLOCKS.size());
    }

    public static class_6880<class_1291> radiationEntry() {
        return radiationEntry;
    }

    public static class_1291 radiation() {
        return radiation;
    }

    private static void registerItems() {
        for (Material material : Material.ALL) {
            for (Material.Component component : ITEM_COMPONENTS) {
                if (!material.has(component))
                    continue;
                if ((material == Material.IRON || material == Material.GOLD)
                        && (component == Material.Component.INGOT || component == Material.Component.NUGGET))
                    continue;
                class_1792 item = new ItemLCMaterial(material, component);
                class_2378.method_10230(class_7923.field_41178, material.getId(component), item);
                ITEMS.computeIfAbsent(material, m -> new LinkedHashMap<>()).put(component, item);
            }
        }
    }

    private static void registerBlocks() {
        for (Material material : Material.ALL) {
            for (Material.Component component : new Material.Component[]{Material.Component.ORE, Material.Component.BLOCK}) {
                if (!material.has(component))
                    continue;
                class_2248 block = new BlockLCMaterial(material, component);
                class_2378.method_10230(class_7923.field_41175, material.getId(component), block);
                class_2378.method_10230(class_7923.field_41178, material.getId(component), new class_1747(block, new class_1792.class_1793()));
                (component == Material.Component.ORE ? ORES : BLOCKS).put(material, block);
            }
        }
    }

    private static void registerCreativeTab() {
        GROUP = class_2378.method_10230(class_7923.field_44687, LucraftCore.id("materials"),
                FabricItemGroup.builder()
                        .method_47321(class_2561.method_43471("itemGroup.tabMaterials"))
                        .method_47320(() -> new class_1799(ITEMS.get(Material.IRIDIUM).get(Material.Component.PLATE)))
                        .method_47317((context, entries) -> {
                            for (Material material : Material.ALL) {
                                Map<Material.Component, class_1792> items = ITEMS.get(material);
                                if (items != null) {
                                    for (Material.Component component : ITEM_COMPONENTS) {
                                        class_1792 item = items.get(component);
                                        if (item != null)
                                            entries.method_45421(item);
                                    }
                                }
                                class_2248 ore = ORES.get(material);
                                if (ore != null)
                                    entries.method_45421(ore);
                                class_2248 block = BLOCKS.get(material);
                                if (block != null)
                                    entries.method_45421(block);
                            }
                        })
                        .method_47324());
    }

    private static void registerWorldgen() {
        for (Material material : Material.ALL) {
            if (!material.generatesOre())
                continue;
            BiomeModifications.addFeature(
                    BiomeSelectors.foundInOverworld(),
                    class_2893.class_2895.field_13176,
                    class_5321.method_29179(class_7924.field_41245, LucraftCore.id("ore_" + material.getName())));
        }
    }
}
