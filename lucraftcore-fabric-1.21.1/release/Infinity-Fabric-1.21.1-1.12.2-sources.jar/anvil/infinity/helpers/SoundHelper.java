package anvil.infinity.helpers;

import net.minecraft.class_1309;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

/** Plays a sound at an entity's position, with the original's distance delay. */
public final class SoundHelper {

    private SoundHelper() {
    }

    public static void playSoundAtEntity(class_1309 entity, class_3414 sound) {
        entity.method_37908().method_43128(null, entity.method_23317(), entity.method_23318(), entity.method_23321(), sound,
                class_3419.field_15251, 5.0F, 0.0F);
    }
}
