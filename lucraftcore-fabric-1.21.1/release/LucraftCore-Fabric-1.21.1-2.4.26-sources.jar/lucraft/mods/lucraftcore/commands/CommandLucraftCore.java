package lucraft.mods.lucraftcore.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.addonpacks.AddonPackHandler;
import lucraft.mods.lucraftcore.addonpacks.AddonPackInfo;
import lucraft.mods.lucraftcore.util.energy.EnergyItemStorage;
import lucraft.mods.lucraftcore.util.energy.EnergyStorage;
import lucraft.mods.lucraftcore.util.energy.EnergyUtil;
import lucraft.mods.lucraftcore.util.fluids.FluidTank;
import lucraft.mods.lucraftcore.util.inventory.InventoryUtil;
import lucraft.mods.lucraftcore.extendedinventory.ExtendedInventoryData;
import lucraft.mods.lucraftcore.extendedinventory.ExtendedInventoryHandler;
import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.ModuleInfinity;
import lucraft.mods.lucraftcore.infinity.blocks.InfinityGeneratorBlockEntity;
import lucraft.mods.lucraftcore.infinity.items.InventoryInfinityGauntlet;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import lucraft.mods.lucraftcore.utilities.blocks.FuelValues;
import lucraft.mods.lucraftcore.utilities.blocks.FurnaceGeneratorBlockEntity;
import lucraft.mods.lucraftcore.utilities.blocks.UtilitiesBlocks;
import lucraft.mods.lucraftcore.utilities.recipes.MachineRecipes;
import lucraft.mods.lucraftcore.util.inventory.StackInventory;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3612;
import net.minecraft.class_7923;
import java.util.List;

/**
 * Operator commands for the engine layer: a self test of the energy, fluid and
 * inventory APIs, and a listing of loaded addon packs.
 */
public final class CommandLucraftCore {

    private CommandLucraftCore() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("lucraftcore")
                        .requires(source -> source.method_9259(2))
                        .then(class_2170.method_9247("engine").executes(CommandLucraftCore::runEngineTest))
                        .then(class_2170.method_9247("addonpacks").executes(CommandLucraftCore::listAddonPacks))
                        .then(class_2170.method_9247("machines").executes(CommandLucraftCore::runMachineTest))
                        .then(class_2170.method_9247("infinity").executes(CommandLucraftCore::runInfinityTest))
                        .then(class_2170.method_9247("extended").executes(CommandLucraftCore::runExtendedTest))));
    }

    private static int runMachineTest(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        boolean ok = true;

        int coal = FuelValues.burnTime(new class_1799(class_1802.field_8713));
        boolean fuelOk = coal == 1600 && FuelValues.burnTime(new class_1799(class_1802.field_8600)) == 100
                && FuelValues.burnTime(class_1799.field_8037) == 0;
        ok &= fuelOk;
        report(source, "fuel", fuelOk, "coal=" + coal);

        boolean registered = true;
        for (String id : List.of("construction_table", "suit_stand", "extractor", "boiler", "furnace_generator"))
            registered &= class_7923.field_41181.method_10223(LucraftCore.id(id)) != null;
        ok &= registered;
        report(source, "machine_blocks", registered, "5 block entity types");

        JsonObject json = new JsonObject();
        json.addProperty("input", "minecraft:iron_ore");
        json.addProperty("count", 1);
        JsonObject output = new JsonObject();
        output.addProperty("item", "minecraft:iron_ingot");
        output.addProperty("count", 2);
        json.add("output", output);
        json.addProperty("energy", 400);
        json.addProperty("time", 40);
        boolean added = MachineRecipes.add("extractor", LucraftCore.id("test/extractor"), json);
        var recipe = MachineRecipes.findExtractor(new class_1799(class_1802.field_8599));
        boolean recipeOk = added && recipe != null && recipe.output().method_31574(class_1802.field_8620)
                && recipe.output().method_7947() == 2 && recipe.energyPerTick() == 10;
        ok &= recipeOk;
        report(source, "extractor_recipe", recipeOk,
                "loaded=" + MachineRecipes.extractorRecipes().size() + ", found=" + (recipe != null));

        FurnaceGeneratorBlockEntity generator = new FurnaceGeneratorBlockEntity(class_2338.field_10980,
                UtilitiesBlocks.FURNACE_GENERATOR.method_9564());
        int accepted = generator.getEnergy().receiveEnergy(500, false);
        boolean energyOk = accepted == 500 && generator.getEnergy().getEnergyStored() == 500;
        ok &= energyOk;
        report(source, "machine_energy", energyOk, "accepted=" + accepted);

        final boolean result = ok;
        source.method_9226(() -> class_2561.method_43470("[Lucraft] machines " + (result ? "PASS" : "FAIL")
                + " | extractor recipes=" + MachineRecipes.extractorRecipes().size()
                + ", boiler recipes=" + MachineRecipes.boilerRecipes().size()), false);
        return result ? 1 : 0;
    }

    private static int runInfinityTest(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        try {
            return runInfinityTestInternal(source);
        } catch (Throwable throwable) {
            LucraftCore.LOGGER.error("Infinity self test failed", throwable);
            source.method_9213(class_2561.method_43470("Infinity self test failed: " + throwable));
            return 0;
        }
    }

    private static int runInfinityTestInternal(class_2168 source) {
        boolean ok = true;

        class_1799 gauntlet = new class_1799(ModuleInfinity.INFINITY_GAUNTLET);
        gauntlet.method_57379(ItemInfinityGauntlet.STONES, List.of(new class_1799(class_1802.field_8477)));
        boolean componentOk = ItemInfinityGauntlet.getStones(gauntlet).size() == 1
                && !ItemInfinityGauntlet.hasStone(gauntlet, EnumInfinityStone.SPACE);
        boolean rejectsNonStone = !new InventoryInfinityGauntlet(gauntlet).method_5437(0, new class_1799(class_1802.field_8477));
        boolean gauntletOk = componentOk && rejectsNonStone;
        ok &= gauntletOk;
        report(source, "gauntlet", gauntletOk,
                "stones=" + ItemInfinityGauntlet.getStones(gauntlet).size() + ", nonStoneRejected=" + rejectsNonStone);

        InfinityGeneratorBlockEntity generator = new InfinityGeneratorBlockEntity(class_2338.field_10980,
                ModuleInfinity.INFINITY_GENERATOR.method_9564());
        int accepted = generator.getEnergy().receiveEnergy(1234, false);
        boolean energyOk = accepted == 1234 && generator.getEnergy().getEnergyStored() == 1234;
        ok &= energyOk;
        report(source, "infinity_generator", energyOk, "accepted=" + accepted);

        boolean registered = class_7923.field_41181.method_10223(LucraftCore.id("infinity_generator")) != null
                && class_7923.field_41178.method_10223(LucraftCore.id("infinity_gauntlet")) == ModuleInfinity.INFINITY_GAUNTLET;
        ok &= registered;
        report(source, "infinity_registry", registered, "gauntlet + generator registered");

        final boolean result = ok;
        source.method_9226(() -> class_2561.method_43470("[Lucraft] infinity " + (result ? "PASS" : "FAIL")), false);
        return result ? 1 : 0;
    }

    private static int runExtendedTest(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("This test needs a player"));
            return 0;
        }
        ExtendedInventoryData previous = ExtendedInventoryHandler.get(player);
        boolean ok = true;

        ExtendedInventoryHandler.setStack(player, ExtendedInventoryData.SLOT_NECKLACE,
                new class_1799(class_1802.field_8477));
        boolean stored = ExtendedInventoryHandler.getStack(player, ExtendedInventoryData.SLOT_NECKLACE)
                .method_31574(class_1802.field_8477);
        ok &= stored;
        report(source, "extended_storage", stored, "necklace slot persisted");

        class_1277 inventory = ExtendedInventoryHandler.createInventory(player);
        boolean screenOk = inventory.method_5439() == 9
                && inventory.method_5437(ExtendedInventoryData.SLOT_NECKLACE, new class_1799(class_1802.field_8477))
                && !inventory.method_5437(6, new class_1799(class_1802.field_8477));
        ok &= screenOk;
        report(source, "extended_screen", screenOk, "size=" + inventory.method_5439() + ", extra slots locked");

        ExtendedInventoryHandler.setStack(player, ExtendedInventoryData.SLOT_NECKLACE,
                previous.get(ExtendedInventoryData.SLOT_NECKLACE));
        final boolean result = ok;
        source.method_9226(() -> class_2561.method_43470("[Lucraft] extended inventory " + (result ? "PASS" : "FAIL")), false);
        return result ? 1 : 0;
    }

    private static int runEngineTest(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        boolean ok = true;

        EnergyStorage first = new EnergyStorage(1000, 1000);
        EnergyStorage second = new EnergyStorage(1000, 1000);
        int received = first.receiveEnergy(600, false);
        int moved = EnergyUtil.transfer(first, second, 400);
        int drained = second.extractEnergy(150, false);
        boolean energyOk = received == 600 && moved == 400 && drained == 150
                && first.getEnergyStored() == 200 && second.getEnergyStored() == 250;
        ok &= energyOk;
        report(source, "energy", energyOk,
                "receive=" + received + ", transfer=" + moved + ", drain=" + drained
                        + ", stored=" + first.getEnergyStored() + "/" + second.getEnergyStored());

        class_1799 battery = new class_1799(class_1802.field_8802);
        EnergyItemStorage.setStored(battery, 0);
        EnergyItemStorage itemStorage = new EnergyItemStorage(battery, 5000);
        int charged = itemStorage.receiveEnergy(1200, false);
        boolean itemEnergyOk = charged == 1200 && EnergyItemStorage.getStored(battery) == 1200
                && EnergyItemStorage.isEnergyItem(battery);
        ok &= itemEnergyOk;
        report(source, "item_energy", itemEnergyOk,
                "charged=" + charged + ", stored=" + EnergyItemStorage.getStored(battery) + "/5000");

        FluidTank tank = new FluidTank(8000);
        int filled = tank.fill(class_3612.field_15910, 4000, false);
        int drainedFluid = tank.drain(1000, false);
        boolean fluidOk = filled == 4000 && drainedFluid == 1000 && tank.getAmount() == 3000
                && tank.contains(class_3612.field_15910);
        ok &= fluidOk;
        report(source, "fluid", fluidOk, "filled=" + filled + ", drained=" + drainedFluid
                + ", remaining=" + tank.getAmount() + "/" + tank.getCapacity());

        StackInventory inventory = new StackInventory(3);
        class_1799 remainder = InventoryUtil.insert(inventory, new class_1799(class_1802.field_8831, 100), false);
        class_1799 extracted = InventoryUtil.extract(inventory, stack -> stack.method_31574(class_1802.field_8831), 10, false);
        int left = InventoryUtil.count(inventory, new class_1799(class_1802.field_8831));
        boolean inventoryOk = remainder.method_7960() && extracted.method_7947() == 10 && left == 90;
        ok &= inventoryOk;
        report(source, "inventory", inventoryOk, "remainder=" + remainder.method_7947()
                + ", extracted=" + extracted.method_7947() + ", left=" + left);

        boolean passed = ok;
        source.method_9226(() -> class_2561.method_43470("[Lucraft] engine self test " + (passed ? "PASSED" : "FAILED")), false);
        if (!passed)
            LucraftCore.LOGGER.warn("Engine self test failed");
        return ok ? 1 : 0;
    }

    private static int listAddonPacks(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        List<AddonPackInfo> packs = AddonPackHandler.getPacks();
        source.method_9226(() -> class_2561.method_43470("[Lucraft] " + packs.size() + " addon pack(s), "
                + AddonPackHandler.getInstructionRecipeCount() + " instruction recipe(s), "
                + AddonPackHandler.getSuitSetCount() + " suit set(s), "
                + AddonPackHandler.getSuperpowerCount() + " superpower(s)"), false);
        for (AddonPackInfo pack : packs)
            source.method_9226(() -> class_2561.method_43470(" - " + pack.getName() + " (" + pack.getFileName() + ") by " + pack.getAuthor()), false);
        return packs.size();
    }

    private static void report(class_2168 source, String name, boolean passed, String detail) {
        String line = "[Lucraft] " + name + ": " + (passed ? "ok" : "FAILED") + " (" + detail + ")";
        source.method_9226(() -> class_2561.method_43470(line), false);
    }
}
