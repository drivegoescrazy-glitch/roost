package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import lucraft.mods.lucraftcore.util.network.LCNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

/**
 * Punch ability: hits the entity the player is aiming at. Covers the original
 * punch, fire punch, potion punch and set punch through settings
 * ({@code damage}, {@code knockback}, {@code fire_ticks}, {@code potion},
 * {@code duration}, {@code amplifier}).
 */
public class PunchAbility extends Ability {

    private final AbilityConfig config;

    public PunchAbility(class_3222 player, AbilityConfig config) {
        super(player);
        this.config = config;
    }

    @Override
    public String getId() {
        return config.abilityId();
    }

    @Override
    public AbilityType getType() {
        return AbilityType.ACTION;
    }

    @Override
    protected boolean onUse() {
        if (!payEnergy())
            return false;

        class_3218 world = player.method_51469();
        double reach = config.getDouble("reach", 3.5D);
        class_243 eye = player.method_33571();
        class_243 direction = player.method_5828(1.0F);
        class_1309 target = AbilityTargeting.findTarget(world, player, eye, direction, reach);
        if (target == null)
            return false;

        float damage = (float) config.getDouble("damage", 4.0D);
        target.method_5643(world.method_48963().method_48802(player), damage);

        double knockback = config.getDouble("knockback", 0.4D);
        if (knockback > 0)
            target.method_6005(knockback, -direction.field_1352, -direction.field_1350);

        int fireTicks = config.getInt("fire_ticks", 0);
        if (fireTicks > 0)
            target.method_56073(fireTicks);

        String potion = config.getString("potion", null);
        if (potion != null) {
            class_2960 effectId = class_2960.method_12829(potion);
            class_1291 effect = effectId == null ? null : class_7923.field_41174.method_10223(effectId);
            if (effect != null) {
                class_6880<class_1291> entry = class_7923.field_41174.method_47983(effect);
                if (entry != null)
                    target.method_6092(new class_1293(entry,
                            config.getInt("duration", 100), config.getInt("amplifier", 0)));
            }
        }

        player.method_6104(class_1268.field_5808);
        LCNetworking.sendSwing(world, player.method_5628(), player.method_19538(), class_1268.field_5808);
        return true;
    }
}
