package lucraft.mods.lucraftcore.utilities.blocks;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5558;

public class FurnaceGeneratorBlock extends class_2237 {

    public static final class_2753 FACING = class_2383.field_11177;

    public FurnaceGeneratorBlock(class_4970.class_2251 settings) {
        super(settings);
        method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(FurnaceGeneratorBlock::new);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new FurnaceGeneratorBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return world.field_9236 ? null : method_31618(type, UtilitiesBlocks.FURNACE_GENERATOR_ENTITY,
                FurnaceGeneratorBlockEntity::tick);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236 && world.method_8321(pos) instanceof UtilitiesBlockEntity machine)
            UtilitiesBlocks.openMachine(player, machine, class_2561.method_43471("block.lucraftcore.furnace_generator"));
        return class_1269.field_5812;
    }

    @Override
    protected void method_9515(class_2689.class_2690<net.minecraft.class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, net.minecraft.class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!world.field_9236 && !state.method_27852(newState.method_26204())
                && world.method_8321(pos) instanceof UtilitiesBlockEntity machine)
            class_1264.method_5451(world, pos, machine);
        super.method_9536(state, world, pos, newState, moved);
    }
}
