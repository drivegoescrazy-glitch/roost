package lucraft.mods.lucraftcore.utilities.recipes;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class InstructionRecipe {

    private static final Map<class_2960, InstructionRecipe> RECIPES = new LinkedHashMap<>();

    private final class_2960 id;
    private final class_1799 output;
    private final List<class_1799> requirements;

    public InstructionRecipe(class_2960 id, class_1799 output, List<class_1799> requirements) {
        this.id = id;
        this.output = output;
        this.requirements = requirements;
    }

    public class_2960 getId() {
        return id;
    }

    public class_1799 getOutput() {
        return output;
    }

    public List<class_1799> getRequirements() {
        return requirements;
    }

    public boolean hasRequirements(net.minecraft.class_1661 inventory) {
        for (class_1799 requirement : requirements) {
            int found = 0;
            for (int i = 0; i < inventory.method_5439(); i++) {
                class_1799 stack = inventory.method_5438(i);
                if (!stack.method_7960() && class_1799.method_31577(stack, requirement))
                    found += stack.method_7947();
            }
            if (found < requirement.method_7947())
                return false;
        }
        return true;
    }

    public void consume(net.minecraft.class_1661 inventory) {
        for (class_1799 requirement : requirements) {
            int remaining = requirement.method_7947();
            for (int i = 0; i < inventory.method_5439() && remaining > 0; i++) {
                class_1799 stack = inventory.method_5438(i);
                if (stack.method_7960() || !class_1799.method_31577(stack, requirement))
                    continue;
                int taken = Math.min(remaining, stack.method_7947());
                stack.method_7934(taken);
                remaining -= taken;
            }
        }
        inventory.method_5431();
    }

    public static void register(InstructionRecipe recipe) {
        if (RECIPES.containsKey(recipe.getId())) {
            LucraftCore.LOGGER.error("Duplicate instruction recipe {}", recipe.getId());
            return;
        }
        RECIPES.put(recipe.getId(), recipe);
    }

    public static InstructionRecipe byId(class_2960 id) {
        return RECIPES.get(id);
    }

    public static List<InstructionRecipe> getAll() {
        return new ArrayList<>(RECIPES.values());
    }

    public static int size() {
        return RECIPES.size();
    }
}
