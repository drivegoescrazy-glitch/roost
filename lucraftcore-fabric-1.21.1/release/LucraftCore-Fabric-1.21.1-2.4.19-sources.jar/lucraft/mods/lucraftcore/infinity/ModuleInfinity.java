package lucraft.mods.lucraftcore.infinity;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.infinity.blocks.InfinityGeneratorBlock;
import lucraft.mods.lucraftcore.infinity.blocks.InfinityGeneratorBlockEntity;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import lucraft.mods.lucraftcore.infinity.items.ItemLCCast;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

/** Infinity gauntlet, gauntlet cast and infinity generator. */
public final class ModuleInfinity {

    public static final List<class_1792> ALL_ITEMS = new ArrayList<>();

    public static class_1792 INFINITY_GAUNTLET;
    public static class_1792 INFINITY_GAUNTLET_CAST;
    public static class_2248 INFINITY_GENERATOR;
    public static class_2591<InfinityGeneratorBlockEntity> INFINITY_GENERATOR_ENTITY;

    private ModuleInfinity() {
    }

    public static void register() {
        INFINITY_GAUNTLET = registerItem("infinity_gauntlet", new ItemInfinityGauntlet());
        INFINITY_GAUNTLET_CAST = registerItem("infinity_gauntlet_cast", new ItemLCCast());

        INFINITY_GENERATOR = class_2378.method_10230(class_7923.field_41175, LucraftCore.id("infinity_generator"),
                new InfinityGeneratorBlock(class_4970.class_2251.method_9637().method_9629(5.0F, 10.0F).method_29292().method_22488()));
        ALL_ITEMS.add(class_2378.method_10230(class_7923.field_41178, LucraftCore.id("infinity_generator"),
                new class_1747(INFINITY_GENERATOR, new class_1792.class_1793())));

        @SuppressWarnings("unchecked")
        class_2591<InfinityGeneratorBlockEntity> type =
                (class_2591<InfinityGeneratorBlockEntity>) class_2591.class_2592
                        .method_20528(InfinityGeneratorBlockEntity::new, INFINITY_GENERATOR).method_11034(null);
        INFINITY_GENERATOR_ENTITY = class_2378.method_10230(class_7923.field_41181,
                LucraftCore.id("infinity_generator"), type);

        LucraftCore.LOGGER.info("Infinity module registered");
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        class_1792 registered = class_2378.method_10230(class_7923.field_41178, LucraftCore.id(name), item);
        ALL_ITEMS.add(registered);
        return registered;
    }
}
