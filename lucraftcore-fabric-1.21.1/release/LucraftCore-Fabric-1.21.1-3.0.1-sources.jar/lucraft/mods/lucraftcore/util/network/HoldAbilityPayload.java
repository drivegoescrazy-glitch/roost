package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** C2S start/stop of a held ability while the use key is down. */
public record HoldAbilityPayload(String abilityId, boolean held) implements class_8710 {

    public static final class_8710.class_9154<HoldAbilityPayload> ID = new class_8710.class_9154<>(LucraftCore.id("hold_ability"));

    public static final class_9139<class_9129, HoldAbilityPayload> CODEC = class_9139.method_56435(
            class_9135.field_48554, HoldAbilityPayload::abilityId,
            class_9135.field_48547, HoldAbilityPayload::held,
            HoldAbilityPayload::new);

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
