package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;

/** S2C sync of the ability bar: ids, active state and cooldowns. */
public record AbilityBarPayload(class_2487 data) implements class_8710 {

    public static final class_8710.class_9154<AbilityBarPayload> ID = new class_8710.class_9154<>(LucraftCore.id("ability_bar"));

    public static final class_9139<class_9129, AbilityBarPayload> CODEC = class_9139.method_56434(
            class_9135.field_48556, AbilityBarPayload::data,
            AbilityBarPayload::new);

    public record Entry(String id, boolean enabled, int cooldown, int maxCooldown, boolean held) {
    }

    public static AbilityBarPayload of(List<Entry> entries) {
        class_2499 list = new class_2499();
        for (Entry entry : entries) {
            class_2487 compound = new class_2487();
            compound.method_10582("id", entry.id());
            compound.method_10556("enabled", entry.enabled());
            compound.method_10569("cooldown", entry.cooldown());
            compound.method_10569("max", entry.maxCooldown());
            compound.method_10556("held", entry.held());
            list.add(compound);
        }
        class_2487 root = new class_2487();
        root.method_10566("entries", list);
        return new AbilityBarPayload(root);
    }

    public List<Entry> entries() {
        List<Entry> entries = new ArrayList<>();
        class_2499 list = data.method_10554("entries", 10);
        for (int index = 0; index < list.size(); index++) {
            class_2487 compound = list.method_10602(index);
            entries.add(new Entry(compound.method_10558("id"), compound.method_10577("enabled"),
                    compound.method_10550("cooldown"), compound.method_10550("max"), compound.method_10577("held")));
        }
        return entries;
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
