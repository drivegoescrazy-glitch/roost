package lucraft.mods.lucraftcore.util.triggers;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/** Registers the mod's advancement criteria. */
public final class LCriteria {

    public static final AbilityUsedCriterion ABILITY_USED = new AbilityUsedCriterion();

    private LCriteria() {
    }

    public static void register() {
        class_2378.method_10230(class_7923.field_47496, LucraftCore.id("ability_used"), ABILITY_USED);
        LucraftCore.LOGGER.debug("Registered advancement criterion ability_used");
    }
}
