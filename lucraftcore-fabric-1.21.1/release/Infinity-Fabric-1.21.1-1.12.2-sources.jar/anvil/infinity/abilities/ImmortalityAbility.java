package anvil.infinity.abilities;

import lucraft.mods.lucraftcore.superpowers.abilities.AttributeAbility;
import net.minecraft.class_1322;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/**
 * The Soul Stone's immortality. The original set the maximum health modifier to
 * {@code Float.MAX_VALUE}, which the modern client renders as hundreds of
 * hearts; this boost plus the lethal damage immunity in
 * {@link anvil.infinity.helpers.ImmortalityHandler} keeps the same "you cannot
 * die" behaviour with a usable health bar.
 */
public class ImmortalityAbility extends AttributeAbility {

    public static final double HEALTH_BOOST = 20.0D;

    public ImmortalityAbility(class_3222 player) {
        super(player, "immortality", class_5134.field_23716, HEALTH_BOOST,
                class_1322.class_1323.field_6328);
    }
}
