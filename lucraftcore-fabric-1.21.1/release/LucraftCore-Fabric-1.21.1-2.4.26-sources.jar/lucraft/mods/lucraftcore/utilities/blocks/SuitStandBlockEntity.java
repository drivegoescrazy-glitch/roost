package lucraft.mods.lucraftcore.utilities.blocks;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * Armour storage: four armour slots plus three general slots. The worn-suit
 * check only looks at players, so the stand is storage rather than a suit
 * wearer for now.
 */
public class SuitStandBlockEntity extends UtilitiesBlockEntity {

    public SuitStandBlockEntity(class_2338 pos, class_2680 state) {
        super(UtilitiesBlocks.SUIT_STAND_ENTITY, pos, state, 9);
    }
}
