package lucraft.mods.lucraftcore.infinity.render;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.items.InventoryInfinityGauntlet;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import java.util.List;

/**
 * The original 3D gauntlet item renderer: the gauntlet model with the texture
 * of the 1.12 mod in its fingerless variant, worn around the hand while held,
 * and every inserted stone drawn as the same small cube the stones use
 * elsewhere, at the knuckle positions the original renderer defined.
 *
 * <p>The 1.12 mod put the 3D model behind a {@code builtin/entity} model whose
 * {@code display} block described the old {@code TileEntityItemStackRenderer}
 * pipeline, where it stacked on top of the renderer's own translate/scale.
 * Those numbers do not carry over to the 1.21 item pipeline as-is, so the
 * gauntlet is placed here, per camera mode, in the item's own frame: the model
 * is turned so the knuckle stones face the viewer ({@code +Z}), the wrist
 * points down ({@code -Y}) and the fist is hand sized, which is how the
 * gauntlet read in the original mod.</p>
 */
public class GauntletItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {

    public static final class_2960 TEXTURE = LucraftCore.id("textures/models/infinity_gauntlet.png");

    @Override
    public void render(class_1799 stack, class_811 mode, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        if (stack.method_7960() || !(stack.method_7909() instanceof ItemInfinityGauntlet))
            return;

        GauntletModel.Built model = GauntletModel.create();
        // The gauntlet is worn over the hand: the original ships the version
        // without the separate finger parts (LCConfig.fingersOnGauntlet = false).
        GauntletModel.setFingersVisible(model, false);

        matrices.method_22903();
        // 1.21 hands builtin item renderers a stack that has already been moved
        // into the 0..1 item cube; undo that so the gauntlet can be placed around
        // the item's own origin.
        matrices.method_22904(0.5D, 0.5D, 0.5D);
        applyMode(matrices, mode);
        matrices.method_22905(-1.0F, -1.0F, -1.0F);
        // The model's own coordinates run from y = 0.875 (wrist end) to
        // y = 1.5 (knuckles). While worn, the wrist cuff is what the hand goes
        // into, so the cuff straddles the item origin; everywhere else the whole
        // gauntlet is centred on it.
        double yOffset = isHand(mode) ? -1.375D : -1.19D;
        matrices.method_22904(0.0D, yOffset, 0.0D);
        model.root().method_22699(matrices,
                vertexConsumers.getBuffer(class_1921.method_23578(TEXTURE)),
                light, overlay, 0xFFFFFFFF);

        List<class_1799> stones = ItemInfinityGauntlet.getStones(stack);
        for (int i = 0; i < stones.size() && i < InventoryInfinityGauntlet.SLOTS.length; i++) {
            class_1799 stone = stones.get(i);
            if (stone.method_7960())
                continue;
            BuiltinItemRendererRegistry.DynamicItemRenderer renderer =
                    BuiltinItemRendererRegistry.INSTANCE.get(stone.method_7909());
            if (renderer == null)
                continue;

            matrices.method_22903();
            translateToStone(matrices, InventoryInfinityGauntlet.SLOTS[i]);
            matrices.method_22905(0.35F, 0.35F, 0.35F);
            matrices.method_22904(-0.5D, -0.5D, -0.5D);
            renderer.render(stone, mode, matrices, vertexConsumers, light, overlay);
            matrices.method_22909();
        }

        matrices.method_22909();
    }

    /**
     * Places the gauntlet for a camera mode. The model frame handed to this
     * method has the knuckle stones towards {@code +Z}, the fingers towards
     * {@code +Y} and the wrist towards {@code -Y}; every mode only tilts,
     * mirrors and sizes it from there.
     */
    private static void applyMode(class_4587 matrices, class_811 mode) {
        switch (mode) {
            case field_4317 -> {
                matrices.method_22905(0.90F, 0.90F, 0.90F);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(18.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-25.0F));
                matrices.method_22904(0.0D, -0.02D, 0.0D);
            }
            case field_4319 -> {
                matrices.method_22905(0.70F, 0.70F, 0.70F);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(10.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-20.0F));
            }
            case field_4318 -> {
                matrices.method_22905(0.55F, 0.55F, 0.55F);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-20.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(25.0F));
                matrices.method_22904(0.0D, -0.15D, 0.0D);
            }
            case field_4316 -> {
                matrices.method_22905(0.50F, 0.50F, 0.50F);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                matrices.method_22904(0.0D, 0.10D, 0.0D);
            }
            case field_4322 -> {
                matrices.method_22904(0.06D, -0.02D, 0.02D);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-22.0F));
                matrices.method_22905(0.62F, 0.62F, 0.62F);
            }
            case field_4321 -> {
                matrices.method_22904(-0.06D, -0.02D, 0.02D);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(22.0F));
                matrices.method_22905(0.62F, 0.62F, 0.62F);
            }
            case field_4320 -> {
                matrices.method_22904(0.0D, -0.02D, 0.0D);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-28.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-35.0F));
                matrices.method_22905(0.60F, 0.60F, 0.60F);
            }
            case field_4323 -> {
                matrices.method_22904(0.0D, -0.02D, 0.0D);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-28.0F));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(35.0F));
                matrices.method_22905(0.60F, 0.60F, 0.60F);
            }
        }
    }

    private static boolean isHand(class_811 mode) {
        return mode == class_811.field_4321
                || mode == class_811.field_4322
                || mode == class_811.field_4323
                || mode == class_811.field_4320;
    }

    /** The original per-stone placement on the gauntlet. */
    private static void translateToStone(class_4587 matrices, EnumInfinityStone type) {
        switch (type) {
            case SOUL -> matrices.method_22904(0.119D, 1.07D, -0.14D);
            case REALITY -> matrices.method_22904(0.044D, 1.07D, -0.14D);
            case SPACE -> matrices.method_22904(-0.0375D, 1.07D, -0.14D);
            case POWER -> matrices.method_22904(-0.118D, 1.07D, -0.14D);
            case MIND -> matrices.method_22904(0.006D, 1.164D, -0.14D);
            case TIME -> {
                matrices.method_22904(-0.14D, 1.095D, 0.062D);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
            }
        }
    }
}
