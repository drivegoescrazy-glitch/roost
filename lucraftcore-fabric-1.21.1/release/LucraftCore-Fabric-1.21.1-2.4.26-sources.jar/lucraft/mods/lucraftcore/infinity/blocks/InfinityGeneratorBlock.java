package lucraft.mods.lucraftcore.infinity.blocks;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5558;

public class InfinityGeneratorBlock extends class_2237 {

    public InfinityGeneratorBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(InfinityGeneratorBlock::new);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new InfinityGeneratorBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return world.field_9236 ? null : method_31618(type,
                lucraft.mods.lucraftcore.infinity.ModuleInfinity.INFINITY_GENERATOR_ENTITY, InfinityGeneratorBlockEntity::tick);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236 && world.method_8321(pos) instanceof InfinityGeneratorBlockEntity generator) {
            lucraft.mods.lucraftcore.utilities.blocks.UtilitiesBlocks.openMachine(player, generator,
                    class_2561.method_43471("container.lucraftcore.infinity_generator"));
        }
        return class_1269.field_5812;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!world.field_9236 && !state.method_27852(newState.method_26204())
                && world.method_8321(pos) instanceof InfinityGeneratorBlockEntity generator) {
            for (int i = 0; i < generator.getInventory().method_5439(); i++) {
                class_1799 stack = generator.getInventory().method_5438(i);
                if (!stack.method_7960())
                    class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), stack);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }
}
