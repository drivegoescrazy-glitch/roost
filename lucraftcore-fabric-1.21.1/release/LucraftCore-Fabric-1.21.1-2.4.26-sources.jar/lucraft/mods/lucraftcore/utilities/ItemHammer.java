package lucraft.mods.lucraftcore.utilities;

import net.minecraft.class_1792;

/**
 * Crafting tool. The original kept itself in the grid through Forge's container-item
 * mechanic; here {@link lucraft.mods.lucraftcore.mixin.CraftingResultSlotMixin} does that.
 */
public class ItemHammer extends class_1792 {

    public ItemHammer() {
        super(new class_1792.class_1793().method_7889(1));
    }
}
