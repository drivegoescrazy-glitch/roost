package lucraft.mods.lucraftcore.util.inventory;

import net.minecraft.class_1277;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

/**
 * Inventory with optional output slots, used by machines and item-held
 * inventories. Insertion skips output slots; {@link #insert} returns the
 * remainder so callers never lose items.
 */
public class StackInventory extends class_1277 {

    private final int[] outputSlots;

    public StackInventory(int size) {
        this(size, new int[0]);
    }

    public StackInventory(int size, int... outputSlots) {
        super(size);
        this.outputSlots = outputSlots == null ? new int[0] : outputSlots.clone();
    }

    public boolean isOutput(int slot) {
        for (int output : outputSlots)
            if (output == slot)
                return true;
        return false;
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return !isOutput(slot) && super.method_5437(slot, stack);
    }

    /** Inserts a stack into the first available slots and returns the remainder. */
    public class_1799 insert(class_1799 stack) {
        return InventoryUtil.insert(this, stack, false);
    }

    public class_1799 extract(int slot, int amount) {
        return method_5434(slot, amount);
    }

    public int method_18861(class_1792 item) {
        int count = 0;
        for (int i = 0; i < method_5439(); i++)
            if (method_5438(i).method_31574(item))
                count += method_5438(i).method_7947();
        return count;
    }

    public class_1799 findFirst(Predicate<class_1799> predicate) {
        for (int i = 0; i < method_5439(); i++) {
            class_1799 stack = method_5438(i);
            if (!stack.method_7960() && predicate.test(stack))
                return stack;
        }
        return class_1799.field_8037;
    }

    public interface Predicate<T> {
        boolean test(T value);
    }
}
