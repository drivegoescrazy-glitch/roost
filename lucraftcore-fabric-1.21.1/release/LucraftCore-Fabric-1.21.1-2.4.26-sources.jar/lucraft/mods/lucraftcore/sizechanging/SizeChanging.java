package lucraft.mods.lucraftcore.sizechanging;

import com.mojang.brigadier.arguments.FloatArgumentType;
import lucraft.mods.lucraftcore.LCConfig;
import lucraft.mods.lucraftcore.LucraftCore;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import java.util.List;

public class SizeChanging {

    public static final float MIN_SIZE = 0.05F;
    public static final float MAX_SIZE = 10F;

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) ->
                dispatcher.register(class_2170.method_9247("sizechange")
                        .requires(source -> source.method_9259(2))
                        .then(class_2170.method_9244("size", FloatArgumentType.floatArg(MIN_SIZE, MAX_SIZE))
                                .executes(context -> apply(context.getSource(), List.of(context.getSource().method_9207()),
                                        FloatArgumentType.getFloat(context, "size"))))
                        .then(class_2170.method_9244("targets", net.minecraft.class_2186.method_9306())
                                .then(class_2170.method_9244("size", FloatArgumentType.floatArg(MIN_SIZE, MAX_SIZE))
                                        .executes(context -> apply(context.getSource(),
                                                net.minecraft.class_2186.method_9317(context, "targets"),
                                                FloatArgumentType.getFloat(context, "size")))))));
    }

    private static int apply(class_2168 source, java.util.Collection<? extends net.minecraft.class_1297> targets, float size) {
        int changed = 0;
        for (net.minecraft.class_1297 entity : targets) {
            if (!(entity instanceof class_1309 living))
                continue;
            setSize(living, size);
            changed++;
        }
        int count = changed;
        source.method_9226(() -> class_2561.method_43470("Set size of " + count + " entities to " + size), false);
        return changed;
    }

    public static void setSize(class_1309 entity, float size) {
        size = Math.max(MIN_SIZE, Math.min(MAX_SIZE, size));

        set(entity, class_5134.field_47760, "scale", size - 1F, class_1322.class_1323.field_6330);
        set(entity, class_5134.field_23719, "speed", (size - 1F) * 0.5D, class_1322.class_1323.field_6330);
        set(entity, class_5134.field_23721, "attack", size - 1F, class_1322.class_1323.field_6330);
        set(entity, class_5134.field_47761, "step", (size - 1F) * 0.6D, class_1322.class_1323.field_6328);
        set(entity, class_5134.field_23728, "jump", size - 1F, class_1322.class_1323.field_6330);
        set(entity, class_5134.field_23718, "knockback",
                Math.max(-0.9D, Math.min(1.0D, (size - 1F) * 0.5D)), class_1322.class_1323.field_6328);
        set(entity, class_5134.field_49077, "fall",
                size > 1F ? (1D / size) - 1D : 0D, class_1322.class_1323.field_6328);
        entity.method_18382();
    }

    private static void set(class_1309 entity, class_6880<class_1320> attribute, String name, double value,
                            class_1322.class_1323 operation) {
        class_1324 instance = entity.method_5996(attribute);
        if (instance == null)
            return;
        class_2960 id = LucraftCore.id("size_" + name);
        class_1322 modifier = instance.method_6199(id);
        if (Math.abs(value) < 1.0E-5D) {
            if (modifier != null)
                instance.method_6200(id);
            return;
        }
        instance.method_61163(new class_1322(id, value, operation));
    }
}
