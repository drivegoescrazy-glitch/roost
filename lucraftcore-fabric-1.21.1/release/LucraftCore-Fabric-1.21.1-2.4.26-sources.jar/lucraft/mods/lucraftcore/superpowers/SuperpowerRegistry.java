package lucraft.mods.lucraftcore.superpowers;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2960;

/** Registry of addon-pack superpowers. */
public final class SuperpowerRegistry {

    private static final Map<class_2960, Superpower> SUPERPOWERS = new LinkedHashMap<>();

    private SuperpowerRegistry() {
    }

    public static void clear() {
        SUPERPOWERS.clear();
    }

    public static void register(Superpower superpower) {
        SUPERPOWERS.put(superpower.getId(), superpower);
    }

    public static Superpower get(class_2960 id) {
        return id == null ? null : SUPERPOWERS.get(id);
    }

    public static Superpower get(String id) {
        return get(class_2960.method_12829(id));
    }

    public static Collection<Superpower> getAll() {
        return SUPERPOWERS.values();
    }

    public static int size() {
        return SUPERPOWERS.size();
    }
}
