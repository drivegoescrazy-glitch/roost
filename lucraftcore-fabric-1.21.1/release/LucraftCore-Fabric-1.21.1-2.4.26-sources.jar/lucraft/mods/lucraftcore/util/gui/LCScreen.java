package lucraft.mods.lucraftcore.util.gui;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

/**
 * Base for the mod's container screens: supplies the background texture size and
 * draws the vanilla-style background. Subclasses add widgets and foreground
 * decorations.
 */
public abstract class LCScreen<T extends class_1703> extends class_465<T> {

    private final class_2960 background;

    protected LCScreen(T handler, class_1661 inventory, class_2561 title, class_2960 background, int width, int height) {
        super(handler, inventory, title);
        this.background = background;
        this.field_2792 = width;
        this.field_2779 = height;
        this.field_25267 = 8;
        this.field_25268 = 6;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        context.method_25302(background, field_2776, field_2800, 0, 0, field_2792, field_2779);
    }

    public class_2960 getBackground() {
        return background;
    }
}
