package lucraft.mods.lucraftcore.client;

import lucraft.mods.lucraftcore.util.particles.LCParticles;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;

/** Coloured cloud particle used by energy blasts and suit trails. */
public class LCColoredParticle extends class_4003 {

    private final int color;

    public LCColoredParticle(class_638 world, double x, double y, double z,
                             double velocityX, double velocityY, double velocityZ,
                             class_4002 provider, int color) {
        super(world, x, y, z, velocityX, velocityY, velocityZ);
        this.color = color;
        this.method_18140(provider);
        this.field_3847 = 20 + this.field_3840.method_43048(15);
        this.field_17867 = 0.45F + this.field_3840.method_43057() * 0.35F;
        this.field_3844 = 0.0F;
        this.field_28786 = 0.96F;
        this.field_3841 = 1.0F;
        this.field_3861 = ((color >> 16) & 0xFF) / 255.0F;
        this.field_3842 = ((color >> 8) & 0xFF) / 255.0F;
        this.field_3859 = (color & 0xFF) / 255.0F;
    }

    public int getColor() {
        return color;
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }
}
