package lucraft.mods.lucraftcore.infinity.screen;

import lucraft.mods.lucraftcore.infinity.ModuleInfinity;
import lucraft.mods.lucraftcore.infinity.items.InventoryInfinityGauntlet;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityStone;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

/**
 * The original gauntlet container: six stone slots at the 1.12 coordinates plus
 * the full player inventory, with the held gauntlet's hotbar slot locked.
 *
 * <p>The client side builds its inventory from its own main-hand stack, which is
 * kept in sync as a data component, so no extra screen data is needed.</p>
 */
public class InfinityGauntletScreenHandler extends class_1703 {

    /** Original {@code ContainerInfinityGauntlet} slot positions, in slot order. */
    private static final int[] SLOT_X = {38, 59, 80, 101, 69, 129};
    private static final int[] SLOT_Y = {28, 28, 28, 28, 58, 38};

    private static final int STONE_SLOTS = 6;
    private static final int MAIN_START = 6;
    private static final int MAIN_END = 33;
    private static final int HOTBAR_START = 33;
    private static final int HOTBAR_END = 42;

    private final class_1263 inventory;
    private final class_1657 player;

    public InfinityGauntletScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory,
                new InventoryInfinityGauntlet(playerInventory.field_7546.method_6047()));
    }

    public InfinityGauntletScreenHandler(int syncId, class_1661 playerInventory,
                                         InventoryInfinityGauntlet inventory) {
        super(ModuleInfinity.GAUNTLET_SCREEN_HANDLER, syncId);
        this.inventory = inventory;
        this.player = playerInventory.field_7546;

        for (int i = 0; i < STONE_SLOTS; i++)
            method_7621(new SlotInfinityStone(inventory, player, InventoryInfinityGauntlet.SLOTS[i],
                    i, SLOT_X[i], SLOT_Y[i]));

        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
                method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 129 + row * 18));

        for (int col = 0; col < 9; col++)
            method_7621(new class_1735(playerInventory, col, 8 + col * 18, 187) {
                @Override
                public boolean method_7674(class_1657 playerEntity) {
                    // The original prevented moving the gauntlet out of its own screen.
                    return method_7677() != playerEntity.method_6047();
                }
            });
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 result = class_1799.field_8037;
        if (index < 0 || index >= field_7761.size())
            return result;
        class_1735 slot = field_7761.get(index);
        if (!slot.method_7681())
            return result;

        class_1799 stack = slot.method_7677();
        result = stack.method_7972();

        if (index < STONE_SLOTS) {
            if (!method_7616(stack, MAIN_START, HOTBAR_END, true))
                return class_1799.field_8037;
            slot.method_7670(stack, result);
        } else if (stack.method_7909() instanceof ItemInfinityStone stone && !stone.isContainer()) {
            int target = stoneSlot(stone.getType());
            if (target < 0 || !method_7616(stack, target, target + 1, false))
                return class_1799.field_8037;
        } else if (index >= HOTBAR_START && index < HOTBAR_END) {
            if (!method_7616(stack, MAIN_START, MAIN_END, false))
                return class_1799.field_8037;
        } else if (!method_7616(stack, HOTBAR_START, HOTBAR_END, false)) {
            return class_1799.field_8037;
        }

        if (stack.method_7960())
            slot.method_53512(class_1799.field_8037);
        else
            slot.method_7668();

        if (stack.method_7947() == result.method_7947())
            return class_1799.field_8037;

        slot.method_7667(player, stack);
        return result;
    }

    private static int stoneSlot(lucraft.mods.lucraftcore.infinity.EnumInfinityStone type) {
        for (int i = 0; i < InventoryInfinityGauntlet.SLOTS.length; i++)
            if (InventoryInfinityGauntlet.SLOTS[i] == type)
                return i;
        return -1;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        lucraft.mods.lucraftcore.LucraftCore.guard("saving the infinity gauntlet", () -> {
            if (inventory instanceof InventoryInfinityGauntlet gauntletInventory)
                gauntletInventory.save();
        });
    }
}
