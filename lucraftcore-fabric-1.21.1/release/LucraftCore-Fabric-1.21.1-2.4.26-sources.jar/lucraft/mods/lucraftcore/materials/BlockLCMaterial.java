package lucraft.mods.lucraftcore.materials;

import lucraft.mods.lucraftcore.LCConfig;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

public class BlockLCMaterial extends class_2248 {

    private final Material material;
    private final Material.Component component;

    public BlockLCMaterial(Material material, Material.Component component) {
        super(class_4970.class_2251.method_9637()
                .method_9629(material.getBlockHardness(), material.getResistance())
                .method_9626(component == Material.Component.ORE ? class_2498.field_11544 : class_2498.field_11533)
                .method_29292()
                .method_9640());
        this.material = material;
        this.component = component;
    }

    public Material getMaterial() {
        return material;
    }

    public Material.Component getComponent() {
        return component;
    }

    @Override
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (!LCConfig.radiation || !material.isRadioactive())
            return;

        double radius = component == Material.Component.ORE ? 3.0D : 1.5D;
        int amplifier = component == Material.Component.ORE ? 1 : 0;
        for (class_1309 entity : world.method_8390(class_1309.class, new net.minecraft.class_238(pos).method_1014(radius), e -> true)) {
            entity.method_6092(new class_1293(ModuleMaterials.radiationEntry(), 100, amplifier));
        }
        if (world.method_8608())
            return;
        world.method_14199(class_2398.field_11234, pos.method_10263() + 0.5D, pos.method_10264() + 1.0D, pos.method_10260() + 0.5D, 2, 0.3D, 0.3D, 0.3D, 0.0D);
    }

    @Override
    public void method_9591(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity) {
        if (LCConfig.radiation && material.isRadioactive() && entity instanceof class_1309 living) {
            living.method_6092(new class_1293(ModuleMaterials.radiationEntry(), 100, 0));
        }
        super.method_9591(world, pos, state, entity);
    }
}
