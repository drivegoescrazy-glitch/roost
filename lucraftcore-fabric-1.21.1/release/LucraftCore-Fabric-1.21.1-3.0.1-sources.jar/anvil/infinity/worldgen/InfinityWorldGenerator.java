package anvil.infinity.worldgen;

import anvil.infinity.config.InfinityConfig;
import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Generates one temple per stone and world, far from spawn, with the original
 * 1-in-1000 per chunk chance in the configured dimensions.
 */
public final class InfinityWorldGenerator {

    /**
     * Chunks that were generated far enough from spawn and are waiting for their
     * temple roll. 1.21 finishes chunk generation on worker threads and forbids
     * reading neighbouring chunks from there, so the roll and the placement are
     * done at the end of a world tick, once the chunk is a normal loaded chunk.
     */
    private static final Map<class_5321<class_1937>, Queue<class_1923>> PENDING = new ConcurrentHashMap<>();

    private InfinityWorldGenerator() {
    }

    public static void register() {
        ServerChunkEvents.CHUNK_GENERATE.register((world, chunk) -> {
            if (!InfinityConfig.worldgenEnabled)
                return;
            lucraft.mods.lucraftcore.LucraftCore.guard("queueing infinity stone worldgen", () -> {
                class_1923 pos = chunk.method_12004();
                // Original condition: both coordinates outside +-1000.
                if (pos.field_9181 <= 1000 && pos.field_9181 >= -1000 || pos.field_9180 <= 1000 && pos.field_9180 >= -1000)
                    return;
                PENDING.computeIfAbsent(world.method_27983(), key -> new ConcurrentLinkedQueue<>()).add(pos);
            });
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> PENDING.clear());

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            Queue<class_1923> queue = PENDING.get(world.method_27983());
            if (queue == null || queue.isEmpty())
                return;
            lucraft.mods.lucraftcore.LucraftCore.guard("infinity stone worldgen", () -> {
                int budget = 32;
                class_1923 pos;
                while (budget-- > 0 && (pos = queue.poll()) != null)
                    generate(world, pos.field_9181, pos.field_9180);
            });
        });
    }

    /** Mirrors {@code IWorldGenerator#generate}; kept public for tests. */
    public static void generate(class_3218 world, int chunkX, int chunkZ) {
        if (!InfinityConfig.worldgenEnabled || !world.method_14178().method_12123(chunkX, chunkZ))
            return;

        if (InfinityConfig.worldgenDebug)
            System.out.println("Chunk generation in Dim: " + world.method_27983().method_29177());

        if (chunkX <= 1000 && chunkX >= -1000 || chunkZ <= 1000 && chunkZ >= -1000)
            return;

        int blockX = chunkX * 16 + 8;
        int blockZ = chunkZ * 16 + 8;
        if (!canGenMind(world) && !canGenPower(world) && !canGenReality(world)
                && !canGenSoul(world) && !canGenSpace(world) && !canGenTime(world))
            return;

        if (InfinityConfig.worldgenDebug)
            System.out.println("A Stone can be generated here");

        if (world.method_8409().method_43048(1000) != 0)
            return;

        int y = getGroundFromAbove(world, blockX, blockZ);
        StoneTempleGen.generate(world, new class_2338(blockX, y, blockZ));
    }

    /**
     * First solid/water block from above, used as the temple's floor. The
     * original scanned down to y=31 because 1.12 worlds ended there; the scan
     * now stops at the bottom of the current world.
     */
    public static int getGroundFromAbove(class_3218 world, int x, int z) {
        int y = world.method_31600();
        int bottom = world.method_31607() + 1;
        boolean found = false;
        while (!found && y-- >= bottom) {
            var block = world.method_8320(new class_2338(x, y, z)).method_26204();
            found = block == class_2246.field_10382 || block == class_2246.field_10219 || block == class_2246.field_10102
                    || block == class_2246.field_10255 || block == class_2246.field_10340 || block == class_2246.field_10566
                    || block == class_2246.field_10460 || block == class_2246.field_10520;
        }
        return y;
    }

    public static boolean isCornerValid(class_3218 world, class_2338 pos) {
        int variation = 3;
        int highest = getGroundFromAbove(world, pos.method_10263(), pos.method_10260());
        return highest > pos.method_10264() - variation && highest < pos.method_10264() + variation;
    }

    public static boolean canGenPower(class_3218 world) {
        return !WorldData.get(world).power && dimensionMatches(world, EnumInfinityStone.POWER);
    }

    public static boolean canGenSoul(class_3218 world) {
        return !WorldData.get(world).soul && dimensionMatches(world, EnumInfinityStone.SOUL);
    }

    public static boolean canGenSpace(class_3218 world) {
        return !WorldData.get(world).space && dimensionMatches(world, EnumInfinityStone.SPACE);
    }

    public static boolean canGenReality(class_3218 world) {
        return !WorldData.get(world).reality && dimensionMatches(world, EnumInfinityStone.REALITY);
    }

    public static boolean canGenTime(class_3218 world) {
        return !WorldData.get(world).time && dimensionMatches(world, EnumInfinityStone.TIME);
    }

    public static boolean canGenMind(class_3218 world) {
        return !WorldData.get(world).mind && dimensionMatches(world, EnumInfinityStone.MIND);
    }

    /**
     * The original compared numeric dimension ids. The config accepts the old
     * numbers (-1 nether, 0 overworld, 1 end) as well as a dimension id such as
     * {@code minecraft:overworld}, which is what modded dimensions use now.
     */
    public static boolean dimensionMatches(class_3218 world, EnumInfinityStone stone) {
        String configured = InfinityConfig.dimension(stone).trim();
        class_2960 current = world.method_27983().method_29177();
        try {
            int legacy = Integer.parseInt(configured);
            return switch (legacy) {
                case -1 -> current.equals(class_2960.method_60656("the_nether"));
                case 0 -> current.equals(class_2960.method_60656("overworld"));
                case 1 -> current.equals(class_2960.method_60656("the_end"));
                default -> false;
            };
        } catch (NumberFormatException ignored) {
            class_2960 wanted = class_2960.method_12829(configured);
            return wanted != null && wanted.equals(current);
        }
    }
}
