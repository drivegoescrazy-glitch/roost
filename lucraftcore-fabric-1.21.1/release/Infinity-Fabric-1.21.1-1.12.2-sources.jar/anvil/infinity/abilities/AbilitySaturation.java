package anvil.infinity.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_3222;

/** Saturation: keeps the wearer fed, like the original constant ability. */
public class AbilitySaturation extends Ability {

    public AbilitySaturation(class_3222 player) {
        super(player);
    }

    @Override
    public String getId() {
        return "saturation";
    }

    @Override
    public AbilityType getType() {
        return AbilityType.CONSTANT;
    }

    @Override
    protected void onTick() {
        player.method_7344().method_7580(20);
    }
}
