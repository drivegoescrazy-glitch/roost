package lucraft.mods.lucraftcore.mixin;

import lucraft.mods.lucraftcore.utilities.ItemHammer;
import net.minecraft.class_1657;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_8566;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(class_1734.class)
public class CraftingResultSlotMixin {

    @Shadow
    @Final
    private class_8566 input;

    @Unique
    private final List<class_1799> lucraftcore$tools = new ArrayList<>();

    @Inject(method = "onTakeItem", at = @At("HEAD"))
    private void lucraftcore$collectTools(class_1657 player, class_1799 stack, CallbackInfo ci) {
        lucraftcore$tools.clear();
        for (int i = 0; i < input.method_5439(); i++) {
            class_1799 slot = input.method_5438(i);
            if (!slot.method_7960() && slot.method_7909() instanceof ItemHammer)
                lucraftcore$tools.add(new class_1799(slot.method_7909()));
        }
    }

    @Inject(method = "onTakeItem", at = @At("RETURN"))
    private void lucraftcore$restoreTools(class_1657 player, class_1799 stack, CallbackInfo ci) {
        for (class_1799 tool : lucraftcore$tools) {
            for (int i = 0; i < input.method_5439(); i++) {
                if (input.method_5438(i).method_7960()) {
                    input.method_5447(i, tool);
                    break;
                }
            }
        }
        lucraftcore$tools.clear();
    }
}
