package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.AbilityBarSync;
import lucraft.mods.lucraftcore.superpowers.PlayerAbilities;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Registration and sending helpers for the mod's play-channel payloads.
 * Replaces the original Forge SimpleNetworkWrapper messages: spawn particle and
 * swing arm.
 */
public final class LCNetworking {

    private static final double PARTICLE_RANGE = 64.0D;

    private LCNetworking() {
    }

    public static void registerPayloads() {
        PayloadTypeRegistry.playS2C().register(SpawnParticlePayload.ID, SpawnParticlePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SwingHandPayload.ID, SwingHandPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(AbilityBarPayload.ID, AbilityBarPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UseAbilityPayload.ID, UseAbilityPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(OpenExtendedInventoryPayload.ID, OpenExtendedInventoryPayload.CODEC);
    }

    /** Server receivers for client keybinds. */
    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(UseAbilityPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            player.method_5682().execute(() -> {
                PlayerAbilities.use(player, payload.abilityId());
                AbilityBarSync.send(player);
            });
        });
        ServerPlayNetworking.registerGlobalReceiver(OpenExtendedInventoryPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            player.method_5682().execute(() -> lucraft.mods.lucraftcore.extendedinventory.ExtendedInventoryHandler.open(player));
        });
    }

    /** Spawns particles for one player. */
    public static void sendParticle(class_3222 player, class_2394 effect, class_243 position, class_243 velocity, int count) {
        class_2960 id = class_7923.field_41180.method_10221(effect.method_10295());
        if (id == null)
            return;
        if (ServerPlayNetworking.canSend(player, SpawnParticlePayload.ID))
            ServerPlayNetworking.send(player, SpawnParticlePayload.create(id, position, velocity, count));
    }

    /** Spawns particles for every player within range of the position. */
    public static void sendParticle(class_3218 world, class_243 position, class_2394 effect, class_243 velocity, int count) {
        for (class_3222 player : world.method_18456()) {
            if (player.method_5707(position) <= PARTICLE_RANGE * PARTICLE_RANGE)
                sendParticle(player, effect, position, velocity, count);
        }
    }

    /** Shows an arm swing on an entity to nearby players. */
    public static void sendSwing(class_3218 world, int entityId, class_243 position, class_1268 hand) {
        SwingHandPayload payload = new SwingHandPayload(entityId, hand == class_1268.field_5808);
        for (class_3222 player : world.method_18456()) {
            if (player.method_5707(position) <= PARTICLE_RANGE * PARTICLE_RANGE
                    && ServerPlayNetworking.canSend(player, SwingHandPayload.ID))
                ServerPlayNetworking.send(player, payload);
        }
    }

    /** Logged once at startup so a missing registration is easy to spot. */
    public static void logRegistration() {
        LucraftCore.LOGGER.debug("Registered payloads: {}, {}",
                SpawnParticlePayload.ID.comp_2242(), SwingHandPayload.ID.comp_2242());
    }
}
