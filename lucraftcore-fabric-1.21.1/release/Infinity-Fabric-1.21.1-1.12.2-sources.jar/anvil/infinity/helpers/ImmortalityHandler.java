package anvil.infinity.helpers;

import lucraft.mods.lucraftcore.superpowers.PlayerAbilities;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_3222;
import net.minecraft.class_8103;

/**
 * The Soul Stone made its wearer effectively immortal by setting a huge maximum
 * health (the original used {@code Float.MAX_VALUE}). The modern health bar
 * draws one heart per two health points, so the port keeps a normal sized
 * health boost and simply ignores damage that would be lethal instead.
 */
public final class ImmortalityHandler {

    public static final String ABILITY_ID = "immortality";

    private ImmortalityHandler() {
    }

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof class_3222 player))
                return true;
            if (!PlayerAbilities.isActive(player, ABILITY_ID))
                return true;
            // /kill and other admin damage still works.
            if (source.method_48789(class_8103.field_42242))
                return true;
            return amount < player.method_6032();
        });
    }
}
