package lucraft.mods.lucraftcore.infinity.render;

import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

/**
 * The original {@code ModelInfinityGauntlet}: a Techne-style model of a hand
 * wearing the gauntlet, with six stone blocks on the knuckles and the two-part
 * fingers that close when the gauntlet is held.
 *
 * <p>Every box, pivot, rotation point and UV is taken from the 1.12 model, so
 * the 64x16 {@code models/infinity_gauntlet.png} maps identically.</p>
 */
public final class GauntletModel {

    private static final float FINGER_ANGLE = -0.34906584F;
    private static final float THUMB_ANGLE = -0.17453292F;

    private GauntletModel() {
    }

    /** A built model plus the parts the renderer needs to pose. */
    public record Built(class_630 root, class_630 index, class_630 middle, class_630 ring,
                        class_630 pinkie, class_630 thumb, class_630 indexTip, class_630 middleTip,
                        class_630 ringTip, class_630 pinkieTip, class_630 thumbTip) {
    }

    public static Built create() {
        class_5609 data = new class_5609();
        class_5610 root = data.method_32111();

        class_5610 shape1 = root.method_32117("shape1",
                class_5606.method_32108().method_32101(0, 0).method_32097(-3.0F, 0.0F, -3.0F, 6, 4, 6),
                class_5603.method_32090(0.0F, 20.0F, 0.0F));

        root.method_32117("hand",
                class_5606.method_32108().method_32101(24, 0).method_32097(-2.5F, 0.0F, -2.5F, 5, 4, 5),
                class_5603.method_32090(0.0F, 16.0F, 0.0F));

        class_5610 index = root.method_32117("index_0",
                class_5606.method_32108().method_32101(0, 0).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32090(-2.0F, 16.0F, -2.0F));
        class_5610 indexTip = index.method_32117("index_1",
                class_5606.method_32108().method_32101(43, 2).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32091(0.0F, -2.0F, 0.0F, FINGER_ANGLE, 0.0F, 0.0F));

        class_5610 middle = root.method_32117("middle_0",
                class_5606.method_32108().method_32101(18, 0).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32090(-0.6F, 16.0F, -2.0F));
        class_5610 middleTip = middle.method_32117("middle_1",
                class_5606.method_32108().method_32101(47, 2).method_32097(-0.5F, -3.0F, -0.5F, 1, 3, 1),
                class_5603.method_32091(0.0F, -2.0F, 0.0F, FINGER_ANGLE, 0.0F, 0.0F));

        class_5610 ring = root.method_32117("ring_0",
                class_5606.method_32108().method_32101(22, 0).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32090(0.7F, 16.0F, -2.0F));
        class_5610 ringTip = ring.method_32117("ring_1",
                class_5606.method_32108().method_32101(51, 2).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32091(0.0F, -2.0F, 0.0F, FINGER_ANGLE, 0.0F, 0.0F));

        class_5610 pinkie = root.method_32117("pinkie_0",
                class_5606.method_32108().method_32101(39, 0).method_32097(-0.5F, -1.0F, -0.5F, 1, 1, 1),
                class_5603.method_32090(2.0F, 16.0F, -2.0F));
        class_5610 pinkieTip = pinkie.method_32117("pinkie_1",
                class_5606.method_32108().method_32101(55, 2).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32091(0.0F, -1.0F, 0.0F, FINGER_ANGLE, 0.0F, 0.0F));

        class_5610 thumb = root.method_32117("thumb_0",
                class_5606.method_32108().method_32101(43, 0).method_32097(-1.0F, -1.0F, -0.5F, 1, 1, 1),
                class_5603.method_32091(-2.0F, 16.0F, 1.0F, 0.0F, 0.0F, THUMB_ANGLE));
        class_5610 thumbTip = thumb.method_32117("thumb_1",
                class_5606.method_32108().method_32101(59, 2).method_32097(-0.5F, -2.0F, -0.5F, 1, 2, 1),
                class_5603.method_32091(-0.5F, -1.0F, 0.0F, FINGER_ANGLE, 0.0F, 0.0F));

        root.method_32117("stone_0", stone(47, 0), class_5603.method_32090(1.4F, 16.2F, -2.6F));
        root.method_32117("stone_1", stone(51, 0), class_5603.method_32090(0.2F, 16.2F, -2.6F));
        root.method_32117("stone_2", stone(55, 0), class_5603.method_32090(-1.1F, 16.2F, -2.6F));
        root.method_32117("stone_3", stone(59, 0), class_5603.method_32090(-2.4F, 16.2F, -2.6F));
        root.method_32117("stone_4", stone(25, 2), class_5603.method_32090(-0.4F, 17.7F, -2.6F));
        root.method_32117("stone_5", stone(39, 2), class_5603.method_32090(-2.6F, 16.6F, 0.5F));

        class_630 model = class_5607.method_32110(data, 64, 16).method_32109();
        return new Built(model,
                model.method_32086("index_0"), model.method_32086("middle_0"), model.method_32086("ring_0"),
                model.method_32086("pinkie_0"), model.method_32086("thumb_0"),
                model.method_32086("index_0").method_32086("index_1"),
                model.method_32086("middle_0").method_32086("middle_1"),
                model.method_32086("ring_0").method_32086("ring_1"),
                model.method_32086("pinkie_0").method_32086("pinkie_1"),
                model.method_32086("thumb_0").method_32086("thumb_1"));
    }

    private static class_5606 stone(int u, int v) {
        return class_5606.method_32108().method_32101(u, v).method_32097(0.0F, 0.0F, 0.0F, 1, 1, 1);
    }

    /** The original config option that hides the fingers entirely. */
    public static void setFingersVisible(Built model, boolean visible) {
        model.index().field_3665 = visible;
        model.middle().field_3665 = visible;
        model.ring().field_3665 = visible;
        model.pinkie().field_3665 = visible;
        model.thumb().field_3665 = visible;
    }

    /**
     * The original "Fist" pose: the hand closes around whatever it holds. The
     * 1.12 renderer applied these angles while the gauntlet was held or in the
     * hotbar and left the hand open when it lay on the ground.
     */
    public static void setFist(Built model, boolean fist) {
        if (!fist)
            return;
        model.index().field_3654 = -1.0F;
        model.middle().field_3654 = -1.0F;
        model.ring().field_3654 = -1.0F;
        model.pinkie().field_3654 = -1.0F;
        model.thumb().field_3675 = (float) Math.toRadians(90.0D);

        model.indexTip().field_3654 = -0.6F;
        model.middleTip().field_3654 = -0.6F;
        model.ringTip().field_3654 = -0.6F;
        model.pinkieTip().field_3654 = -0.6F;
        model.thumbTip().field_3654 = -1.4F;
    }
}
