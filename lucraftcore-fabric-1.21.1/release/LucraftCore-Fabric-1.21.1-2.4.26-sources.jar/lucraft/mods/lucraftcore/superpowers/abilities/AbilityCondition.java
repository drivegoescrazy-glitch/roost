package lucraft.mods.lucraftcore.superpowers.abilities;

import net.minecraft.class_3222;

/** Gate that decides whether an ability may run for a player. */
public interface AbilityCondition {

    boolean test(class_3222 player);

    /** JSON type name, used when reading addon pack data. */
    String type();
}
