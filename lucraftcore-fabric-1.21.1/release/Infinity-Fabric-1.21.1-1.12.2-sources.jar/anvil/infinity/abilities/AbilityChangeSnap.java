package anvil.infinity.abilities;

import anvil.infinity.capabilities.GauntletUserInformation;
import anvil.infinity.capabilities.SnapPlayerData;
import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/** Change Snap: cycles the selected snap result and shows it above the hotbar. */
public class AbilityChangeSnap extends Ability {

    public AbilityChangeSnap(class_3222 player) {
        super(player);
    }

    @Override
    public String getId() {
        return "changesnap";
    }

    @Override
    public AbilityType getType() {
        return AbilityType.ACTION;
    }

    @Override
    protected boolean onUse() {
        SnapPlayerData data = GauntletUserInformation.get(player);
        SnapPlayerData changed = data.withSnapResult(data.snapResult().next());
        GauntletUserInformation.set(player, changed);
        player.method_7353(class_2561.method_43470("Selected ability is: " + changed.snapResult()), true);
        return true;
    }
}
