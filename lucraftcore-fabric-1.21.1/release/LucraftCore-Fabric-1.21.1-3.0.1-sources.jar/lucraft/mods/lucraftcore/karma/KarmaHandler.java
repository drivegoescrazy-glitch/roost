package lucraft.mods.lucraftcore.karma;

import com.mojang.serialization.Codec;
import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.karma.KarmaStat.KarmaClass;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1569;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;

public class KarmaHandler {

    public static final AttachmentType<Map<String, Integer>> KARMA = AttachmentRegistry.createPersistent(
            LucraftCore.id("karma"), Codec.unboundedMap(Codec.STRING, Codec.INT));

    /** Forces the karma attachment to register before player data loads. */
    public static void registerAttachments() {
        java.util.Objects.requireNonNull(KARMA);
    }

    public static Map<String, Integer> getStats(class_1657 player) {
        // Codec-decoded maps are immutable, so hand out a mutable copy and let the
        // callers that change it store it back.
        Map<String, Integer> attached = player.getAttachedOrCreate(KARMA, HashMap::new);
        return new HashMap<>(attached);
    }

    public static int getKarmaStat(class_1657 player, KarmaStat stat) {
        return getStats(player).getOrDefault(stat.getName(), 0);
    }

    public static void setKarmaStat(class_1657 player, KarmaStat stat, int amount) {
        Map<String, Integer> stats = getStats(player);
        stats.put(stat.getName(), amount);
        player.setAttached(KARMA, stats);
    }

    public static void increaseKarmaStat(class_1657 player, KarmaStat stat, int amount) {
        setKarmaStat(player, stat, getKarmaStat(player, stat) + amount);
    }

    public static void increaseKarmaStat(class_1657 player, KarmaStat stat) {
        increaseKarmaStat(player, stat, 1);
    }

    public static int getKarma(class_1657 player) {
        Map<String, Integer> stats = getStats(player);
        int karma = 0;
        for (KarmaStat stat : KarmaStat.ALL)
            karma += stat.getAmount() * stats.getOrDefault(stat.getName(), 0);
        return karma;
    }

    public static KarmaClass getKarmaClass(class_1657 player) {
        int karma = getKarma(player);
        for (KarmaClass karmaClass : KarmaClass.values()) {
            if (karmaClass.contains(karma))
                return karmaClass;
        }
        return KarmaClass.NEUTRAL;
    }

    public static boolean isEvilPlayer(class_1657 player) {
        return getKarma(player) <= -26;
    }

    public static boolean isGoodPlayer(class_1657 player) {
        return getKarma(player) >= 26;
    }

    public static boolean isMonster(class_1309 entity) {
        return entity instanceof class_1569 || entity.method_5864().method_5891() == class_1311.field_6302;
    }

    public static boolean isGoodEntity(class_1309 entity) {
        if (entity instanceof class_1657 player)
            return isGoodPlayer(player);
        return entity instanceof class_1646;
    }

    /** Awards karma for a player kill, mirroring the original death handler. */
    public static void onKill(class_3222 player, class_1309 victim) {
        if (isMonster(victim)) {
            increaseKarmaStat(player, KarmaStat.MONSTER_KILL);
        } else if (victim instanceof class_1657 target) {
            if (isGoodPlayer(target))
                increaseKarmaStat(player, KarmaStat.GOOD_PLAYER_KILL);
            else if (isEvilPlayer(target))
                increaseKarmaStat(player, KarmaStat.BAD_PLAYER_KILL);
        } else if (isGoodEntity(victim)) {
            increaseKarmaStat(player, KarmaStat.GOOD_PLAYER_KILL);
        }
    }
}
