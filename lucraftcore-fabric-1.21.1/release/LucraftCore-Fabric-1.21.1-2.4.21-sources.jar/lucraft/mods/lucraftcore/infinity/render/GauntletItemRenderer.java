package lucraft.mods.lucraftcore.infinity.render;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.items.InventoryInfinityGauntlet;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import java.util.List;

/**
 * The original 3D gauntlet item renderer: the gauntlet model with the texture
 * of the 1.12 mod, closed into a fist while held, and every inserted stone
 * drawn as the same small cube the stones use elsewhere, at the knuckle
 * positions the original renderer defined.
 */
public class GauntletItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {

    public static final class_2960 TEXTURE = LucraftCore.id("textures/models/infinity_gauntlet.png");

    @Override
    public void render(class_1799 stack, class_811 mode, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        if (stack.method_7960() || !(stack.method_7909() instanceof ItemInfinityGauntlet))
            return;

        GauntletModel.Built model = GauntletModel.create();
        // A gauntlet lying on the ground shows an open hand; a held one is a fist.
        GauntletModel.setFist(model, mode != class_811.field_4318
                && mode != class_811.field_4319
                && mode != class_811.field_4317);

        matrices.method_22903();
        matrices.method_22904(0.5D, 1.8D, 0.5D);
        matrices.method_22905(-1.0F, -1.0F, -1.0F);
        model.root().method_22699(matrices,
                vertexConsumers.getBuffer(class_1921.method_23578(TEXTURE)),
                light, overlay, 0xFFFFFFFF);

        List<class_1799> stones = ItemInfinityGauntlet.getStones(stack);
        for (int i = 0; i < stones.size() && i < InventoryInfinityGauntlet.SLOTS.length; i++) {
            class_1799 stone = stones.get(i);
            if (stone.method_7960())
                continue;
            BuiltinItemRendererRegistry.DynamicItemRenderer renderer =
                    BuiltinItemRendererRegistry.INSTANCE.get(stone.method_7909());
            if (renderer == null)
                continue;

            matrices.method_22903();
            translateToStone(matrices, InventoryInfinityGauntlet.SLOTS[i]);
            matrices.method_22905(0.35F, 0.35F, 0.35F);
            matrices.method_22904(-0.5D, -0.5D, -0.5D);
            renderer.render(stone, mode, matrices, vertexConsumers, light, overlay);
            matrices.method_22909();
        }

        matrices.method_22909();
    }

    /** The original per-stone placement on the gauntlet. */
    private static void translateToStone(class_4587 matrices, EnumInfinityStone type) {
        switch (type) {
            case SOUL -> matrices.method_22904(0.119D, 1.07D, -0.14D);
            case REALITY -> matrices.method_22904(0.044D, 1.07D, -0.14D);
            case SPACE -> matrices.method_22904(-0.0375D, 1.07D, -0.14D);
            case POWER -> matrices.method_22904(-0.118D, 1.07D, -0.14D);
            case MIND -> matrices.method_22904(0.006D, 1.164D, -0.14D);
            case TIME -> {
                matrices.method_22904(-0.14D, 1.095D, 0.062D);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
            }
        }
    }
}
