package lucraft.mods.lucraftcore.superpowers;

import lucraft.mods.lucraftcore.util.energy.EnergyItemStorage;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

/**
 * Energy source for abilities: drains FE from items the player carries
 * (inventory, armour, off hand), the same pool the original mod used through
 * its energy items.
 */
public final class AbilityEnergy {

    private AbilityEnergy() {
    }

    public static int getStored(class_3222 player) {
        int stored = 0;
        for (class_1799 stack : energyStacks(player))
            stored += EnergyItemStorage.getStored(stack);
        return stored;
    }

    /** Consumes the cost, returning false when the player cannot pay it. */
    public static boolean consume(class_3222 player, int amount) {
        if (amount <= 0)
            return true;
        if (getStored(player) < amount)
            return false;
        int remaining = amount;
        for (class_1799 stack : energyStacks(player)) {
            if (remaining <= 0)
                break;
            EnergyItemStorage storage = new EnergyItemStorage(stack, Integer.MAX_VALUE, 0, Integer.MAX_VALUE);
            remaining -= storage.extractEnergy(remaining, false);
        }
        return remaining <= 0;
    }

    /** Adds energy to the player's energy items, returning the amount accepted. */
    public static int charge(class_3222 player, int amount) {
        if (amount <= 0)
            return 0;
        int accepted = 0;
        for (class_1799 stack : energyStacks(player)) {
            if (accepted >= amount)
                break;
            EnergyItemStorage storage = new EnergyItemStorage(stack, Integer.MAX_VALUE, Integer.MAX_VALUE, 0);
            accepted += storage.receiveEnergy(amount - accepted, false);
        }
        return accepted;
    }

    private static List<class_1799> energyStacks(class_3222 player) {
        List<class_1799> stacks = new ArrayList<>();
        for (class_1799 stack : player.method_31548().field_7547)
            if (EnergyItemStorage.isEnergyItem(stack))
                stacks.add(stack);
        for (class_1799 stack : player.method_31548().field_7548)
            if (EnergyItemStorage.isEnergyItem(stack))
                stacks.add(stack);
        for (class_1799 stack : player.method_31548().field_7544)
            if (EnergyItemStorage.isEnergyItem(stack))
                stacks.add(stack);
        return stacks;
    }
}
