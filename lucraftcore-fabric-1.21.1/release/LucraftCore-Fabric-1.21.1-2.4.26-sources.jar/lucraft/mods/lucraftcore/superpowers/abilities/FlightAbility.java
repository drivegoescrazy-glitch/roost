package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_3222;

public class FlightAbility extends Ability {

    private final float speed;
    private final float sprintSpeed;

    public FlightAbility(class_3222 player, float speed, float sprintSpeed) {
        super(player);
        this.speed = speed;
        this.sprintSpeed = sprintSpeed;
    }

    @Override
    public String getId() {
        return "flight";
    }

    @Override
    public AbilityType getType() {
        return AbilityType.TOGGLE;
    }

    @Override
    protected void onEnabled() {
        player.method_31549().field_7478 = true;
        player.method_7355();
    }

    @Override
    protected void onDisabled() {
        if (!player.method_7337() && !player.method_7325()) {
            player.method_31549().field_7478 = false;
            player.method_31549().field_7479 = false;
        }
        player.method_7355();
    }

    @Override
    protected void onTick() {
        if (player.method_31549().field_7479 || player.method_5624()) {
            player.method_31549().method_7248(player.method_5624() ? sprintSpeed : speed);
        }
        player.field_6017 = 0.0F;
    }

    @Override
    protected void cleanup() {
        if (!player.method_7337() && !player.method_7325()) {
            player.method_31549().field_7478 = false;
            player.method_31549().field_7479 = false;
        }
        player.method_31549().method_7248(0.05F);
        player.method_7355();
    }
}
