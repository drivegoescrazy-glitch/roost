package lucraft.mods.lucraftcore.utilities.blocks;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_7923;

/**
 * Fuel burn times for the furnace generator. Vanilla's fuel map is not exposed
 * through a public API, so common fuels are listed explicitly and tags cover
 * the rest.
 */
public final class FuelValues {

    private FuelValues() {
    }

    public static int burnTime(class_1799 stack) {
        if (stack == null || stack.method_7960())
            return 0;
        class_1792 item = stack.method_7909();
        if (item == class_1802.field_8187)
            return 20000;
        if (item == class_1802.field_8713 || item == class_1802.field_8665)
            return 1600;
        if (item == class_1802.field_8797)
            return 16000;
        if (item == class_1802.field_8894)
            return 2400;
        if (item == class_1802.field_17533)
            return 4001;
        if (item == class_1802.field_8135)
            return 800;
        if (item == class_1802.field_8600)
            return 100;
        if (stack.method_31573(class_3489.field_15539))
            return 300;
        if (stack.method_31573(class_3489.field_15537))
            return 300;
        if (stack.method_31573(class_3489.field_15534))
            return 150;
        if (stack.method_31573(class_3489.field_15528))
            return 100;
        if (item == class_1802.field_8465 || item == class_1802.field_8536 || item == class_1802.field_8106)
            return 300;

        class_2960 id = class_7923.field_41178.method_10221(item);
        if ("lucraftcore".equals(id.method_12836()))
            return 0;
        return 0;
    }

    public static boolean isFuel(class_1799 stack) {
        return burnTime(stack) > 0;
    }
}
