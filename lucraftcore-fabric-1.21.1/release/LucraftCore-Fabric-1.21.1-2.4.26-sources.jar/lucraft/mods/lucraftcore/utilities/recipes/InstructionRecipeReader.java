package lucraft.mods.lucraftcore.utilities.recipes;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

public class InstructionRecipeReader {

    /**
     * Format (both the original and the modern item syntax are accepted):
     * {"output": {"item": "lucraftcore:hammer", "amount": 1, "data": 0},
     *  "requirements": [{"item": "minecraft:iron_ingot", "amount": 2}]}
     */
    public static int read(class_2960 id, JsonObject json) {
        try {
            class_1799 output = stack(json.getAsJsonObject("output"));
            if (output.method_7960())
                return 0;
            List<class_1799> requirements = new ArrayList<>();
            JsonArray array = json.has("requirements") ? json.getAsJsonArray("requirements") : new JsonArray();
            for (JsonElement element : array) {
                class_1799 stack = stack(element.getAsJsonObject());
                if (!stack.method_7960())
                    requirements.add(stack);
            }
            InstructionRecipe.register(new InstructionRecipe(id, output, requirements));
            return 1;
        } catch (Exception e) {
            LucraftCore.LOGGER.error("Broken instruction recipe {}: {}", id, e.getMessage());
            return 0;
        }
    }

    private static class_1799 stack(JsonObject json) {
        if (json == null || !json.has("item") && !json.has("id"))
            return class_1799.field_8037;
        String name = json.has("id") ? json.get("id").getAsString() : json.get("item").getAsString();
        class_2960 itemId = class_2960.method_12829(name);
        class_1792 item = itemId == null ? null : class_7923.field_41178.method_10223(itemId);
        if (item == null)
            return class_1799.field_8037;
        int count = json.has("count") ? json.get("count").getAsInt()
                : json.has("amount") ? json.get("amount").getAsInt() : 1;
        return new class_1799(item, Math.max(1, count));
    }
}
