package lucraft.mods.lucraftcore.util.sounds;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

/** Sound events used by energy blasts and the infinity gauntlet. */
public final class LCSounds {

    public static final class_3414 ENERGY_BLAST = create("energy_blast");
    public static final class_3414 INFINITY_STONE_EQUIP = create("infinity_stone_equip");
    public static final class_3414 USE_INFINITY_GAUNTLET = create("use_infinity_gauntlet");

    private LCSounds() {
    }

    private static class_3414 create(String name) {
        class_2960 id = LucraftCore.id(name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void register() {
        LucraftCore.LOGGER.debug("Registered sound events: energy_blast, infinity_stone_equip, use_infinity_gauntlet");
    }
}
