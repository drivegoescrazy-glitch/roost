package lucraft.mods.lucraftcore.client;

import lucraft.mods.lucraftcore.util.network.EnergyBeamPayload;
import lucraft.mods.lucraftcore.util.network.SpawnParticlePayload;
import lucraft.mods.lucraftcore.util.network.SwingHandPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_243;
import net.minecraft.class_638;
import net.minecraft.class_7923;

/**
 * Client receivers for the mod's S2C payloads.
 *
 * <p>Fabric runs play-payload handlers on the network thread. Everything here
 * touches state the render and tick threads read — the particle manager, entity
 * swings, the beam list — so each handler is scheduled onto the client thread;
 * doing it from the network thread could corrupt a list or particle manager
 * while it is being rendered, which crashes the client and, in single player,
 * takes the integrated server down with it ("Server closed").</p>
 */
public final class ClientNetworkHandlers {

    private ClientNetworkHandlers() {
    }

    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(EnergyBeamPayload.ID,
                (payload, context) -> context.client().execute(() -> EnergyBeams.add(payload)));

        ClientPlayNetworking.registerGlobalReceiver(SpawnParticlePayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    class_638 world = context.client().field_1687;
                    if (world == null)
                        return;
                    class_2396<?> type = class_7923.field_41180.method_10223(payload.particle());
                    if (!(type instanceof class_2394 effect))
                        return;
                    class_243 position = payload.position();
                    class_243 velocity = payload.velocity();
                    for (int i = 0; i < payload.count(); i++)
                        world.method_8466(effect, true, position.field_1352, position.field_1351, position.field_1350,
                                velocity.field_1352, velocity.field_1351, velocity.field_1350);
                }));

        ClientPlayNetworking.registerGlobalReceiver(SwingHandPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    class_638 world = context.client().field_1687;
                    if (world == null)
                        return;
                    if (world.method_8469(payload.entityId()) instanceof class_1309 entity)
                        entity.method_23667(payload.mainHand() ? class_1268.field_5808 : class_1268.field_5810, true);
                }));
    }
}
