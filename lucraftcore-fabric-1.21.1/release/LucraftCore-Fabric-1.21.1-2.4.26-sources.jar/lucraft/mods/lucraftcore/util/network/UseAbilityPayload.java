package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** C2S request to use or toggle an ability from the ability bar. */
public record UseAbilityPayload(String abilityId) implements class_8710 {

    public static final class_8710.class_9154<UseAbilityPayload> ID = new class_8710.class_9154<>(LucraftCore.id("use_ability"));

    public static final class_9139<class_9129, UseAbilityPayload> CODEC = class_9139.method_56434(
            class_9135.field_48554, UseAbilityPayload::abilityId,
            UseAbilityPayload::new);

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
