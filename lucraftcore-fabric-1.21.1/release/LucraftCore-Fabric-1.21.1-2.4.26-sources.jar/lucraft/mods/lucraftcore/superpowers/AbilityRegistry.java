package lucraft.mods.lucraftcore.superpowers;

import lucraft.mods.lucraftcore.superpowers.abilities.AbilityConfig;
import lucraft.mods.lucraftcore.superpowers.abilities.AttributeAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.CommandRunnerAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.EnergyBlastAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.FlightAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.GeneratorAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.HealingAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.PotionAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.PunchAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.SizeAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.SprintAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.TeleportAbility;
import lucraft.mods.lucraftcore.superpowers.abilities.TogglePotionAbility;
import net.minecraft.class_1294;
import net.minecraft.class_1322;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AbilityRegistry {

    @FunctionalInterface
    public interface AbilityFactory {
        Ability create(class_3222 player, AbilityConfig config);
    }

    public static final Map<String, AbilityFactory> ABILITIES = new LinkedHashMap<>();

    static {
        register("flight", (player, config) -> new FlightAbility(player,
                (float) config.getDouble("speed", 0.1D), (float) config.getDouble("sprint_speed", 0.2D)));
        register("speed", (player, config) -> attribute(player, "speed",
                class_5134.field_23719, config.getDouble("amount", 0.3D),
                class_1322.class_1323.field_6330));
        register("strength", (player, config) -> attribute(player, "strength",
                class_5134.field_23721, config.getDouble("amount", 4.0D),
                class_1322.class_1323.field_6328));
        register("health", (player, config) -> attribute(player, "health",
                class_5134.field_23716, config.getDouble("amount", 10.0D),
                class_1322.class_1323.field_6328));
        register("jump_boost", (player, config) -> attribute(player, "jump_boost",
                class_5134.field_23728, config.getDouble("amount", 0.2D),
                class_1322.class_1323.field_6328));
        register("step_assist", (player, config) -> attribute(player, "step_assist",
                class_5134.field_47761, config.getDouble("amount", 0.5D),
                class_1322.class_1323.field_6328));
        register("knockback_resistance", (player, config) -> attribute(player, "knockback_resistance",
                class_5134.field_23718, config.getDouble("amount", 0.5D),
                class_1322.class_1323.field_6328));
        register("fall_resistance", (player, config) -> attribute(player, "fall_resistance",
                class_5134.field_49077, config.getDouble("amount", -0.5D),
                class_1322.class_1323.field_6328));
        register("damage_resistance", (player, config) -> attribute(player, "damage_resistance",
                class_5134.field_23724, config.getDouble("amount", 4.0D),
                class_1322.class_1323.field_6328));
        register("water_breathing", (player, config) -> new PotionAbility(player, "water_breathing",
                class_1294.field_5923, config.getInt("amplifier", 0)));
        register("tough_lungs", (player, config) -> new PotionAbility(player, "tough_lungs",
                class_1294.field_5923, config.getInt("amplifier", 0)));
        register("fire_resistance", (player, config) -> new PotionAbility(player, "fire_resistance",
                class_1294.field_5918, config.getInt("amplifier", 0)));
        register("slowfall", (player, config) -> new PotionAbility(player, "slowfall",
                class_1294.field_5906, config.getInt("amplifier", 0)));
        register("invisibility", (player, config) -> new TogglePotionAbility(player, "invisibility",
                class_1294.field_5905, config.getInt("amplifier", 0)));
        register("healing", (player, config) -> new HealingAbility(player,
                config.getInt("frequency", 20), (float) config.getDouble("amount", 1.0D)));
        register("teleport", (player, config) -> new TeleportAbility(player, config.getDouble("distance", 30.0D)));
        register("size_change", (player, config) -> new SizeAbility(player,
                (float) config.getDouble("size", 2.0D), (float) config.getDouble("default_size", 1.0D)));
        register("sprint", SprintAbility::new);
        register("generator", GeneratorAbility::new);
        register("energy_blast", EnergyBlastAbility::new);
        register("punch", PunchAbility::new);
        register("command", CommandRunnerAbility::new);
    }

    private static Ability attribute(class_3222 player, String id,
                                     net.minecraft.class_6880<net.minecraft.class_1320> attribute,
                                     double amount, class_1322.class_1323 operation) {
        return new AttributeAbility(player, id, attribute, amount, operation);
    }

    public static void register(String id, AbilityFactory factory) {
        ABILITIES.put(id, factory);
    }

    public static List<String> ids() {
        return List.copyOf(ABILITIES.keySet());
    }

    public static boolean exists(String id) {
        return ABILITIES.containsKey(normalize(id));
    }

    public static Ability create(String id, class_3222 player) {
        return create(AbilityConfig.of(normalize(id)), player);
    }

    public static Ability create(AbilityConfig config, class_3222 player) {
        AbilityFactory factory = ABILITIES.get(normalize(config.abilityId()));
        if (factory == null)
            return null;
        Ability ability = factory.create(player, config);
        if (ability == null)
            return null;
        ability.configure(config.energyCost(), config.cooldown(), config.conditions());
        return ability;
    }

    /** Accepts both "flight" and "lucraftcore:flight". */
    public static String normalize(String id) {
        if (id == null)
            return "";
        return id.startsWith("lucraftcore:") ? id.substring("lucraftcore:".length()) : id;
    }
}
