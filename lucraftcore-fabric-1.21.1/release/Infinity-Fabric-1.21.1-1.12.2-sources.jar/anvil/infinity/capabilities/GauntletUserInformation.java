package anvil.infinity.capabilities;

import anvil.infinity.Infinity;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

/** Access to the per player infinity data (the original gauntlet capability). */
public final class GauntletUserInformation {

    public static final AttachmentType<SnapPlayerData> PLAYER_DATA = AttachmentRegistry.createPersistent(
            Infinity.id("player_data"), SnapPlayerData.CODEC);

    private GauntletUserInformation() {
    }

    /** The player's data, created with the original defaults when absent. */
    public static SnapPlayerData get(class_1657 player) {
        return player.getAttachedOrCreate(PLAYER_DATA, SnapPlayerData::new);
    }

    public static void set(class_1657 player, SnapPlayerData data) {
        player.setAttached(PLAYER_DATA, data);
    }

    /** Non player entities get a throwaway copy, exactly like the original. */
    public static SnapPlayerData getDataByEntity(class_1309 entity) {
        if (entity instanceof class_1657 player)
            return get(player);
        return new SnapPlayerData();
    }

    public static void logRegistration() {
        Infinity.LOGGER.debug("Registered infinity player data attachment");
    }
}
