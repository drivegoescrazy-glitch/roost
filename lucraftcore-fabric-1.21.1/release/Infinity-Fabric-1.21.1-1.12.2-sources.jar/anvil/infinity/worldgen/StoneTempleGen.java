package anvil.infinity.worldgen;

import anvil.infinity.Infinity;
import anvil.infinity.items.Items;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2595;
import net.minecraft.class_3218;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5250;

/** Places {@code infinity:stonetemple} and fills its chest with the stone. */
public final class StoneTempleGen {

    /** Chest slot the original generator inserted the stone into. */
    public static final int STONE_SLOT = 13;

    private StoneTempleGen() {
    }

    public static boolean generate(class_3218 world, class_2338 position) {
        if (InfinityWorldGenerator.canGenMind(world))
            return spawn(world, position, Items.MIND_STONE, "Mind");
        if (InfinityWorldGenerator.canGenSpace(world))
            return spawn(world, position, Items.SPACE_STONE, "Space");
        if (InfinityWorldGenerator.canGenReality(world))
            return spawn(world, position, Items.REALITY_STONE, "Reality");
        if (InfinityWorldGenerator.canGenTime(world))
            return spawn(world, position, Items.TIME_STONE, "Time");
        if (InfinityWorldGenerator.canGenSoul(world))
            return spawn(world, position, Items.SOUL_STONE, "Soul");
        if (InfinityWorldGenerator.canGenPower(world))
            return spawn(world, position, Items.POWER_STONE, "Power");
        return false;
    }

    private static boolean spawn(class_3218 world, class_2338 position, class_1792 stone, String name) {
        Optional<class_3499> optional = world.method_14183()
                .method_15094(Infinity.id("stonetemple"));
        if (optional.isEmpty()) {
            Infinity.LOGGER.error("Missing structure infinity:stonetemple");
            return false;
        }

        class_3499 template = optional.get();
        class_2338 origin = position.method_10084();
        class_3492 placement = new class_3492()
                .method_15125(class_2415.field_11302)
                .method_15123(class_2470.field_11467)
                .method_15133(false);
        template.method_15172(world, origin, origin, placement, world.method_8409(), class_2248.field_31036);

        // The original put the stone in the chest marked by the structure's data
        // block; the port puts it in the temple's only chest.
        class_2338 min = origin;
        class_2338 max = origin.method_10069(template.method_15160().method_10263() - 1, template.method_15160().method_10264() - 1,
                template.method_15160().method_10260() - 1);
        for (class_2338 pos : class_2338.method_10097(min, max)) {
            if (world.method_8321(pos) instanceof class_2595 chest) {
                chest.method_5447(STONE_SLOT, new class_1799(stone));
                chest.method_5431();
                break;
            }
        }

        WorldData data = WorldData.get(world);
        if (stone == Items.MIND_STONE) {
            data.mind = true;
            data.mindx = position.method_10263();
            data.mindz = position.method_10260();
        } else if (stone == Items.SPACE_STONE) {
            data.space = true;
            data.spacex = position.method_10263();
            data.spacez = position.method_10260();
        } else if (stone == Items.REALITY_STONE) {
            data.reality = true;
            data.realityx = position.method_10263();
            data.realityz = position.method_10260();
        } else if (stone == Items.TIME_STONE) {
            data.time = true;
            data.timex = position.method_10263();
            data.timez = position.method_10260();
        } else if (stone == Items.SOUL_STONE) {
            data.soul = true;
            data.soulx = position.method_10263();
            data.soulz = position.method_10260();
        } else if (stone == Items.POWER_STONE) {
            data.power = true;
            data.powerx = position.method_10263();
            data.powerz = position.method_10260();
        }
        data.method_80();

        sendMessage(world, name);
        return true;
    }

    private static void sendMessage(class_3218 world, String stone) {
        class_5250 message = class_2561.method_43470("The " + stone + " Stone has been generated")
                .method_27695(class_124.field_1065, class_124.field_1067);
        world.method_8503().method_3760().method_43514(message, false);
    }
}
