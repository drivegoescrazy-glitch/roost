package lucraft.mods.lucraftcore.superpowers.effects;

import java.util.List;
import net.minecraft.class_3222;

/**
 * Cosmetic or state effect attached to a suit or superpower (glow, trail, name
 * change, aura). Effects are shared instances; anything player specific must be
 * keyed by the player's UUID.
 */
public interface Effect {

    String type();

    default void onApply(class_3222 player) {
    }

    default void tick(class_3222 player, int ticks) {
    }

    default void onRemove(class_3222 player) {
    }

    List<lucraft.mods.lucraftcore.superpowers.abilities.AbilityCondition> conditions();

    default boolean areConditionsMet(class_3222 player) {
        for (lucraft.mods.lucraftcore.superpowers.abilities.AbilityCondition condition : conditions())
            if (!condition.test(player))
                return false;
        return true;
    }
}
