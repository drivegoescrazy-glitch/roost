package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.Ability;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/** Extra movement speed that only applies while the player is sprinting. */
public class SprintAbility extends Ability {

    private final AbilityConfig config;
    private final class_2960 modifierId;
    private boolean applied;

    public SprintAbility(class_3222 player, AbilityConfig config) {
        super(player);
        this.config = config;
        this.modifierId = LucraftCore.id("ability_sprint_" + config.abilityId().replace(':', '_'));
    }

    @Override
    public String getId() {
        return config.abilityId();
    }

    @Override
    protected void onTick() {
        if (player.method_5624()) {
            if (!applied) {
                class_1324 instance = player.method_5996(class_5134.field_23719);
                if (instance != null) {
                    instance.method_6200(modifierId);
                    instance.method_26835(new class_1322(modifierId,
                            config.getDouble("amount", 0.3D), class_1322.class_1323.field_6330));
                    applied = true;
                }
            }
        } else {
            removeModifier();
        }
    }

    @Override
    protected void cleanup() {
        removeModifier();
    }

    private void removeModifier() {
        if (!applied)
            return;
        class_1324 instance = player.method_5996(class_5134.field_23719);
        if (instance != null)
            instance.method_6200(modifierId);
        applied = false;
    }
}
