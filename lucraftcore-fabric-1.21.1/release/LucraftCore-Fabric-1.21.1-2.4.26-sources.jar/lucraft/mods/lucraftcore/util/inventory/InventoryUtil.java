package lucraft.mods.lucraftcore.util.inventory;

import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1799;

/** Insertion, extraction and counting helpers for any {@link class_1263}. */
public final class InventoryUtil {

    private InventoryUtil() {
    }

    /**
     * Inserts a stack, merging into existing stacks first and then filling
     * empty slots. Returns the remainder (empty when everything fitted).
     */
    public static class_1799 insert(class_1263 inventory, class_1799 stack, boolean simulate) {
        if (inventory == null || stack.method_7960())
            return stack;
        class_1799 remaining = stack.method_7972();

        for (int pass = 0; pass < 2 && !remaining.method_7960(); pass++) {
            for (int slot = 0; slot < inventory.method_5439() && !remaining.method_7960(); slot++) {
                if (!inventory.method_5437(slot, remaining))
                    continue;
                class_1799 existing = inventory.method_5438(slot);
                if (pass == 0) {
                    if (existing.method_7960() || !class_1799.method_31577(existing, remaining))
                        continue;
                    int limit = Math.min(inventory.method_5444(), existing.method_7914());
                    int move = Math.min(remaining.method_7947(), limit - existing.method_7947());
                    if (move <= 0)
                        continue;
                    if (!simulate) {
                        existing.method_7933(move);
                        inventory.method_5431();
                    }
                    remaining.method_7934(move);
                } else {
                    if (!existing.method_7960())
                        continue;
                    int move = Math.min(remaining.method_7947(), inventory.method_58350(remaining));
                    if (move <= 0)
                        continue;
                    if (!simulate) {
                        inventory.method_5447(slot, remaining.method_46651(move));
                        inventory.method_5431();
                    }
                    remaining.method_7934(move);
                }
            }
        }
        return remaining;
    }

    /** Removes up to {@code max} matching items and returns them as one stack. */
    public static class_1799 extract(class_1263 inventory, Predicate<class_1799> predicate, int max, boolean simulate) {
        if (inventory == null || max <= 0)
            return class_1799.field_8037;
        class_1799 result = class_1799.field_8037;
        int remaining = max;
        for (int slot = 0; slot < inventory.method_5439() && remaining > 0; slot++) {
            class_1799 existing = inventory.method_5438(slot);
            if (existing.method_7960() || !predicate.test(existing))
                continue;
            int take = Math.min(existing.method_7947(), remaining);
            if (result.method_7960())
                result = existing.method_46651(take);
            else if (class_1799.method_31577(result, existing))
                result.method_7933(take);
            else
                continue;
            remaining -= take;
            if (!simulate) {
                existing.method_7934(take);
                if (existing.method_7960())
                    inventory.method_5447(slot, class_1799.field_8037);
                inventory.method_5431();
            }
        }
        return result;
    }

    /** Total number of the given stack's item, ignoring components. */
    public static int count(class_1263 inventory, class_1799 stack) {
        int count = 0;
        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            class_1799 existing = inventory.method_5438(slot);
            if (!existing.method_7960() && class_1799.method_31577(existing, stack))
                count += existing.method_7947();
        }
        return count;
    }

    public static boolean hasSpaceFor(class_1263 inventory, class_1799 stack) {
        return insert(inventory, stack, true).method_7960();
    }

    public static boolean isEmpty(class_1263 inventory) {
        for (int slot = 0; slot < inventory.method_5439(); slot++)
            if (!inventory.method_5438(slot).method_7960())
                return false;
        return true;
    }
}
