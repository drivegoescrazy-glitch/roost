package anvil.infinity.registry;

import anvil.infinity.Infinity;
import net.minecraft.class_2378;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

/** Sound events. The original registered one {@code infinity:snap} event. */
public final class InfinitySounds {

    public static final class_3414 SNAP = class_2378.method_10230(class_7923.field_41172,
            Infinity.id("snap"), class_3414.method_47908(Infinity.id("snap")));

    private InfinitySounds() {
    }

    public static void register() {
        Infinity.LOGGER.debug("Registered sound event infinity:snap");
    }
}
