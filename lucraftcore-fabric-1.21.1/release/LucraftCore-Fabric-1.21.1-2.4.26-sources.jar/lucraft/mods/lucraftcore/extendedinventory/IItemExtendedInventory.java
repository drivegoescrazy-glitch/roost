package lucraft.mods.lucraftcore.extendedinventory;

import net.minecraft.class_1657;
import net.minecraft.class_1799;

/** Implemented by items that can be worn in the extended inventory. */
public interface IItemExtendedInventory {

    ExtendedInventoryItemType getEIItemType(class_1799 stack);

    default void onWornTick(class_1799 stack, class_1657 player) {
    }

    default void onEquipped(class_1799 stack, class_1657 player) {
    }

    default void onUnequipped(class_1799 stack, class_1657 player) {
    }

    default boolean useButton(class_1799 stack, class_1657 player) {
        return false;
    }

    default String getAbilityBarDescription(class_1799 stack, class_1657 player) {
        return "";
    }

    default void onPressedButton(class_1799 stack, class_1657 player, boolean pressed) {
    }

    default boolean canEquip(class_1799 stack, class_1657 player) {
        return true;
    }

    default boolean canUnequip(class_1799 stack, class_1657 player) {
        return true;
    }

    enum ExtendedInventoryItemType {
        NECKLACE, MANTLE, WRIST
    }
}
