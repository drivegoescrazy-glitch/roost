package anvil.infinity.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_3222;

/** Stop time: freezes the day cycle by stepping the world time back a tick. */
public class AbilityStopTime extends Ability {

    public AbilityStopTime(class_3222 player) {
        super(player);
    }

    @Override
    public String getId() {
        return "stop_time";
    }

    @Override
    public AbilityType getType() {
        return AbilityType.TOGGLE;
    }

    @Override
    protected void onTick() {
        var world = player.method_51469();
        world.method_29199(world.method_8532() - 1L);
    }
}
