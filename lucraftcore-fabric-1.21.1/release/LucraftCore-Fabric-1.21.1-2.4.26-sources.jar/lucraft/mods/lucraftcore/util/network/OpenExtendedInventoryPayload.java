package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** C2S request from the extended inventory keybind. */
public record OpenExtendedInventoryPayload() implements class_8710 {

    public static final OpenExtendedInventoryPayload INSTANCE = new OpenExtendedInventoryPayload();

    public static final class_8710.class_9154<OpenExtendedInventoryPayload> ID =
            new class_8710.class_9154<>(LucraftCore.id("open_extended_inventory"));

    public static final class_9139<class_9129, OpenExtendedInventoryPayload> CODEC =
            class_9139.method_56431(INSTANCE);

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
