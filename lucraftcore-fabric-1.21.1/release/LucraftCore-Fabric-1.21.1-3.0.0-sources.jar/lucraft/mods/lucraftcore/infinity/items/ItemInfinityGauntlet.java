package lucraft.mods.lucraftcore.infinity.items;

import com.mojang.serialization.Codec;
import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.screen.InfinityGauntletScreenHandler;
import lucraft.mods.lucraftcore.util.sounds.LCSounds;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_3419;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9331;
import java.util.ArrayList;
import java.util.List;

/** Holds six infinity stones and opens the original stone screen on right-click. */
public class ItemInfinityGauntlet extends ItemIndestructible {

    /** Stone stacks by slot; empty entries are absent from the component. */
    public static final class_9331<List<class_1799>> STONES = class_2378.method_10230(class_7923.field_49658,
            LucraftCore.id("infinity_stones"),
            class_9331.<List<class_1799>>method_57873()
                    .method_57881(Codec.list(class_1799.field_49266))
                    // Without this the gauntlet cannot be sent to the client and
                    // the whole stack fails to sync, which drops the connection
                    // as soon as a player carries one.
                    .method_57882(class_9139.<class_9129, List<class_1799>>method_56438(
                            (stacks, buf) -> {
                                buf.method_10804(stacks.size());
                                for (class_1799 stack : stacks)
                                    class_1799.field_49268.encode(buf, stack);
                            },
                            buf -> {
                                int size = buf.method_10816();
                                List<class_1799> stacks = new ArrayList<>(size);
                                for (int i = 0; i < size; i++)
                                    stacks.add(class_1799.field_49268.decode(buf));
                                return stacks;
                            }))
                    .method_57880());

    public ItemInfinityGauntlet() {
        super();
    }

    public static List<class_1799> getStones(class_1799 gauntlet) {
        return gauntlet.method_57825(STONES, List.of());
    }

    public static boolean hasStone(class_1799 gauntlet, EnumInfinityStone stone) {
        for (class_1799 stack : getStones(gauntlet)) {
            if (stack.method_7909() instanceof ItemInfinityStone infinityStone
                    && infinityStone.getType() == stone)
                return true;
        }
        return false;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 gauntlet = player.method_5998(hand);
        if (!(gauntlet.method_7909() instanceof ItemInfinityGauntlet))
            return class_1271.method_22430(gauntlet);

        // The whole interaction is guarded: this runs on the server thread, so a
        // throw here would drop the player out of the world ("Server closed").
        try {
            if (player.method_5715()) {
                class_1799 other = player.method_5998(hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808);
                if (!world.field_9236 && other.method_7909() instanceof ItemInfinityStone stone && !stone.isContainer()) {
                    InventoryInfinityGauntlet inventory = new InventoryInfinityGauntlet(gauntlet);
                    if (inventory.insert(other)) {
                        other.method_7934(1);
                        world.method_8396(null, player.method_24515(), LCSounds.INFINITY_STONE_EQUIP,
                                class_3419.field_15248, 1.0F, 1.0F);
                    } else {
                        player.method_7353(class_2561.method_43471("lucraftcore.info.gauntlet_slot_taken"), true);
                    }
                }
                return class_1271.method_22427(gauntlet);
            }

            if (!world.field_9236) {
                InventoryInfinityGauntlet inventory = new InventoryInfinityGauntlet(gauntlet);
                player.method_17355(new class_747(
                        (syncId, playerInventory, playerEntity) ->
                                new InfinityGauntletScreenHandler(syncId, playerInventory, inventory),
                        class_2561.method_43471("container.lucraftcore.infinity_gauntlet")));
            }
            return class_1271.method_22427(gauntlet);
        } catch (Throwable t) {
            LucraftCore.reportError("using the infinity gauntlet", t);
            return class_1271.method_22430(gauntlet);
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        List<class_1799> stones = getStones(stack);
        if (stones.isEmpty()) {
            tooltip.add(class_2561.method_43471("lucraftcore.info.gauntlet_empty").method_27692(class_124.field_1080));
            return;
        }
        for (class_1799 stone : stones) {
            if (stone.method_7909() instanceof ItemInfinityStone infinityStone)
                tooltip.add(class_2561.method_43470(" - ").method_10852(stone.method_7964().method_27661()
                        .method_27692(infinityStone.getType().getTextColor())).method_27692(class_124.field_1080));
        }
    }

    /** The gauntlet is indestructible, so it never takes damage. */
    public static boolean isStoneCompatible(EnumInfinityStone slot, class_1799 stack) {
        if (!(stack.method_7909() instanceof ItemInfinityStone stone) || stone.isContainer())
            return false;
        return stone.getType() == slot;
    }

    /** Small holder used by lookups that do not need a full screen. */
    public static List<class_1799> stoneList(class_1277 inventory) {
        List<class_1799> list = new ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (!inventory.method_5438(i).method_7960())
                list.add(inventory.method_5438(i));
        }
        return list;
    }
}
