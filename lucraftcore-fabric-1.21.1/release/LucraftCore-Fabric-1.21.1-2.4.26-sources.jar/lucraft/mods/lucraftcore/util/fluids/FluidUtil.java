package lucraft.mods.lucraftcore.util.fluids;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3611;
import net.minecraft.class_3612;

/** Bucket interaction helpers for tanks. */
public final class FluidUtil {

    public static final int BUCKET_VOLUME = 1000;

    private FluidUtil() {
    }

    /** Fluid held by a filled bucket, or {@link class_3612#field_15906}. */
    public static class_3611 fluidOfBucket(class_1799 stack) {
        if (stack.method_7960())
            return class_3612.field_15906;
        if (stack.method_31574(class_1802.field_8705))
            return class_3612.field_15910;
        if (stack.method_31574(class_1802.field_8187))
            return class_3612.field_15908;
        return class_3612.field_15906;
    }

    public static boolean isFilledBucket(class_1799 stack) {
        return fluidOfBucket(stack) != class_3612.field_15906;
    }

    public static boolean isEmptyBucket(class_1799 stack) {
        return !stack.method_7960() && stack.method_31574(class_1802.field_8550);
    }

    /**
     * Empties a water or lava bucket into the tank. Returns the resulting
     * container stack, or an empty stack when the transfer is not possible.
     */
    public static class_1799 emptyBucketIntoTank(class_1799 bucket, FluidTank tank) {
        if (tank == null)
            return class_1799.field_8037;
        class_3611 fluid = fluidOfBucket(bucket);
        if (fluid == class_3612.field_15906)
            return class_1799.field_8037;
        if (tank.fill(fluid, BUCKET_VOLUME, true) < BUCKET_VOLUME)
            return class_1799.field_8037;
        tank.fill(fluid, BUCKET_VOLUME, false);
        return new class_1799(class_1802.field_8550);
    }

    /**
     * Fills an empty bucket from the tank. Returns the filled bucket, or an
     * empty stack when there is not enough fluid.
     */
    public static class_1799 fillBucketFromTank(class_1799 bucket, FluidTank tank) {
        if (tank == null || !isEmptyBucket(bucket) || tank.getAmount() < BUCKET_VOLUME)
            return class_1799.field_8037;
        class_1792 bucketItem = tank.getFluid().method_15774();
        if (bucketItem == class_1802.field_8162)
            return class_1799.field_8037;
        tank.drain(BUCKET_VOLUME, false);
        return new class_1799(bucketItem);
    }

    public static boolean canDrainInto(class_1799 stack, FluidTank tank) {
        return isFilledBucket(stack) && tank.fill(fluidOfBucket(stack), BUCKET_VOLUME, true) == BUCKET_VOLUME;
    }

    public static boolean canFillFrom(FluidTank tank) {
        return tank != null && tank.getAmount() >= BUCKET_VOLUME && tank.getFluid().method_15774() != class_1802.field_8162;
    }
}
