package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Asks the client to spawn particles at a position. */
public record SpawnParticlePayload(class_2960 particle, class_2487 data) implements class_8710 {

    public static final class_8710.class_9154<SpawnParticlePayload> ID = new class_8710.class_9154<>(LucraftCore.id("spawn_particle"));

    public static final class_9139<class_9129, SpawnParticlePayload> CODEC = class_9139.method_56435(
            class_2960.field_48267, SpawnParticlePayload::particle,
            class_9135.field_48556, SpawnParticlePayload::data,
            SpawnParticlePayload::new);

    public static SpawnParticlePayload create(class_2960 particle, class_243 position, class_243 velocity, int count) {
        class_2487 data = new class_2487();
        data.method_10549("x", position.field_1352);
        data.method_10549("y", position.field_1351);
        data.method_10549("z", position.field_1350);
        data.method_10549("vx", velocity.field_1352);
        data.method_10549("vy", velocity.field_1351);
        data.method_10549("vz", velocity.field_1350);
        data.method_10569("count", Math.max(1, count));
        return new SpawnParticlePayload(particle, data);
    }

    public class_243 position() {
        return new class_243(data.method_10574("x"), data.method_10574("y"), data.method_10574("z"));
    }

    public class_243 velocity() {
        return new class_243(data.method_10574("vx"), data.method_10574("vy"), data.method_10574("vz"));
    }

    public int count() {
        return Math.max(1, data.method_10550("count"));
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
