package lucraft.mods.lucraftcore.util.fluids;

import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;

/**
 * Forge's {@code FluidTank} equivalent. Minecraft 1.21 no longer has
 * {@code FluidStack}, so a tank stores the fluid and its amount directly.
 * Amounts are in millibuckets (1000 mB = one bucket).
 */
public class FluidTank {

    private class_3611 fluid;
    private int amount;
    private final int capacity;
    private Runnable listener = () -> {
    };

    public FluidTank(int capacity) {
        this(class_3612.field_15906, 0, capacity);
    }

    public FluidTank(class_3611 fluid, int amount, int capacity) {
        this.capacity = Math.max(0, capacity);
        this.fluid = normalize(fluid);
        this.amount = Math.max(0, Math.min(this.capacity, amount));
    }

    public FluidTank setListener(Runnable listener) {
        this.listener = listener == null ? () -> {
        } : listener;
        return this;
    }

    public class_3611 getFluid() {
        return amount <= 0 ? class_3612.field_15906 : fluid;
    }

    public int getAmount() {
        return amount;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isEmpty() {
        return amount <= 0;
    }

    public boolean isFull() {
        return amount >= capacity;
    }

    public boolean contains(class_3611 fluid) {
        return amount > 0 && this.fluid.method_15780(normalize(fluid));
    }

    /** Fills the tank, returning the amount accepted. */
    public int fill(class_3611 fluid, int maxAmount, boolean simulate) {
        class_3611 incoming = normalize(fluid);
        if (incoming == class_3612.field_15906 || maxAmount <= 0)
            return 0;
        if (amount > 0 && !this.fluid.method_15780(incoming))
            return 0;
        int filled = Math.min(capacity - amount, maxAmount);
        if (!simulate && filled > 0) {
            this.fluid = incoming;
            this.amount += filled;
            listener.run();
        }
        return filled;
    }

    /** Drains up to {@code maxAmount}, returning the amount removed. */
    public int drain(int maxAmount, boolean simulate) {
        int drained = Math.min(amount, Math.max(0, maxAmount));
        if (!simulate && drained > 0) {
            amount -= drained;
            if (amount == 0)
                fluid = class_3612.field_15906;
            listener.run();
        }
        return drained;
    }

    /** Drains and returns the fluid that was removed. */
    public class_3611 drainFluid(int maxAmount, boolean simulate) {
        if (amount <= 0 || maxAmount <= 0)
            return class_3612.field_15906;
        class_3611 drainedFluid = fluid;
        if (drain(maxAmount, simulate) <= 0)
            return class_3612.field_15906;
        return simulate ? drainedFluid : amount > 0 ? this.fluid : drainedFluid;
    }

    public void setFluid(class_3611 fluid) {
        this.fluid = normalize(fluid);
        if (this.fluid == class_3612.field_15906)
            this.amount = 0;
        else
            this.amount = Math.min(amount, capacity);
    }

    public void setAmount(int amount) {
        this.amount = Math.max(0, Math.min(capacity, amount));
        if (this.amount == 0)
            this.fluid = class_3612.field_15906;
    }

    public void setFluidAmount(class_3611 fluid, int amount) {
        this.fluid = normalize(fluid);
        this.amount = Math.max(0, Math.min(capacity, amount));
        if (this.amount == 0)
            this.fluid = class_3612.field_15906;
    }

    public void clear() {
        this.fluid = class_3612.field_15906;
        this.amount = 0;
    }

    public class_2487 writeNbt(class_2487 nbt) {
        nbt.method_10582("Fluid", class_7923.field_41173.method_10221(fluid).toString());
        nbt.method_10569("Amount", amount);
        return nbt;
    }

    public void readNbt(class_2487 nbt) {
        class_2960 id = class_2960.method_12829(nbt.method_10558("Fluid"));
        class_3611 read = id == null ? class_3612.field_15906 : class_7923.field_41173.method_10223(id);
        this.fluid = normalize(read);
        this.amount = Math.max(0, Math.min(capacity, nbt.method_10550("Amount")));
        if (this.amount == 0)
            this.fluid = class_3612.field_15906;
    }

    private static class_3611 normalize(class_3611 fluid) {
        return fluid == null ? class_3612.field_15906 : fluid;
    }
}
