package anvil.infinity.registry;

import anvil.infinity.Infinity;
import anvil.infinity.effects.EffectSnap;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/** Status effect registry (the original's {@code effectSnap}). */
public final class InfinityEffects {

    public static final class_1291 SNAP = class_2378.method_10230(class_7923.field_41174,
            Infinity.id("effect_snap"), new EffectSnap());

    private InfinityEffects() {
    }

    public static void register() {
        Infinity.LOGGER.debug("Registered status effect infinity:effect_snap");
    }
}
