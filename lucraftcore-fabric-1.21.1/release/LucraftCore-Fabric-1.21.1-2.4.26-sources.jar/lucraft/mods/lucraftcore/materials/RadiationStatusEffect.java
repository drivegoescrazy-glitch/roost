package lucraft.mods.lucraftcore.materials;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_4081;


public class RadiationStatusEffect extends class_1291 {

    public RadiationStatusEffect() {
        super(class_4081.field_18272, 0x4d4d4d);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        int interval = 25 >> amplifier;
        return interval <= 0 || duration % interval == 0;
    }

    @Override
    public boolean method_5572(class_1309 entity, int amplifier) {
        entity.method_5643(entity.method_48923().method_48831(), 3.0F);
        return true;
    }
}
