package lucraft.mods.lucraftcore.karma;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_4081;
import net.minecraft.class_7923;

public class KnockOutEffect extends class_1291 {

    public KnockOutEffect() {
        super(class_4081.field_18272, 0x4d4d4d);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }

    @Override
    public boolean method_5572(class_1309 entity, int amplifier) {
        entity.method_18800(0, 0, 0);
        entity.field_6037 = true;
        entity.field_6017 = 0;

        class_1293 instance = entity.method_6112(class_7923.field_41174.method_47983(this));
        if (instance != null && instance.method_5584() <= 1 && entity instanceof class_3222 player) {
            class_2338 spawn = player.method_51469().method_43126();
            player.method_5859(spawn.method_10263() + 0.5D, spawn.method_10264(), spawn.method_10260() + 0.5D);
        }
        return true;
    }
}
