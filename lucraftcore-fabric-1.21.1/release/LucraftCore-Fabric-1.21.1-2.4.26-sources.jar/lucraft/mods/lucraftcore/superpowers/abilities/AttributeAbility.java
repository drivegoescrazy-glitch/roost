package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.Ability;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6880;

public class AttributeAbility extends Ability {

    private final String id;
    private final class_6880<class_1320> attribute;
    private final double amount;
    private final class_1322.class_1323 operation;

    public AttributeAbility(class_3222 player, String id, class_6880<class_1320> attribute,
                            double amount, class_1322.class_1323 operation) {
        super(player);
        this.id = id;
        this.attribute = attribute;
        this.amount = amount;
        this.operation = operation;
    }

    @Override
    public String getId() {
        return id;
    }

    private class_2960 modifierId() {
        return LucraftCore.id("ability_" + id);
    }

    @Override
    protected void onEnabled() {
        class_1324 instance = player.method_5996(attribute);
        if (instance == null)
            return;
        instance.method_6200(modifierId());
        instance.method_26837(new class_1322(modifierId(), amount, operation));
    }

    @Override
    protected void onDisabled() {
        cleanup();
    }

    @Override
    protected void cleanup() {
        class_1324 instance = player.method_5996(attribute);
        if (instance != null)
            instance.method_6200(modifierId());
    }
}
