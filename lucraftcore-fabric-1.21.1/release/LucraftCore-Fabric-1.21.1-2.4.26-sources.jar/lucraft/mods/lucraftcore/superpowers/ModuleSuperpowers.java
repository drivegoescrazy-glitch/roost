package lucraft.mods.lucraftcore.superpowers;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.effects.EffectHandler;
import lucraft.mods.lucraftcore.superpowers.suitsets.SuitSet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;
import java.util.List;

public class ModuleSuperpowers {

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                PlayerAbilities.tickSuit(player);
                PlayerAbilities.tickPower(player);
                PlayerAbilities.tick(player);
                PlayerAbilities.tickGauntlet(player);

                SuitSet worn = SuitSet.getWornSuit(player);
                EffectHandler.tick(player, "suit", worn == null ? List.of() : worn.getEffects());
                Superpower power = SuperpowerHandler.getPower(player);
                EffectHandler.tick(player, "power", power == null ? List.of() : power.getEffects());

                if (player.field_6012 % 20 == 0)
                    AbilityBarSync.send(player);
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> PlayerAbilities.sync(handler.field_14140));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            PlayerAbilities.clear(handler.field_14140);
            EffectHandler.clearAll(handler.field_14140);
        });

        CommandAbility.register();
        CommandSuperpower.register();

        LucraftCore.LOGGER.info("Superpowers module registered: {} abilities", AbilityRegistry.ABILITIES.size());
    }
}
