package lucraft.mods.lucraftcore.superpowers.suitsets;

import com.google.gson.JsonObject;
import lucraft.mods.lucraftcore.superpowers.effects.Effect;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class SuitSet {

    private final class_2960 id;
    private final String name;
    private final Map<class_1304, class_1792> pieces = new EnumMap<>(class_1304.class);
    private final List<String> abilities = new ArrayList<>();
    private final List<Effect> effects = new ArrayList<>();
    private final Map<class_1304, Boolean> glow = new EnumMap<>(class_1304.class);
    private class_2960 parent;
    private class_2561 description = class_2561.method_43473();
    private JsonObject data = new JsonObject();
    private String creativeTab;

    public SuitSet(class_2960 id, String name) {
        this.id = id;
        this.name = name;
    }

    public class_2960 getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Map<class_1304, class_1792> getPieces() {
        return pieces;
    }

    public void setPiece(class_1304 slot, class_1792 item) {
        pieces.put(slot, item);
    }

    public class_1792 getPiece(class_1304 slot) {
        return pieces.get(slot);
    }

    public List<String> getAbilities() {
        return abilities;
    }

    public List<Effect> getEffects() {
        return effects;
    }

    public class_2960 getParent() {
        return parent;
    }

    public void setParent(class_2960 parent) {
        this.parent = parent;
    }

    public class_2561 getDescription() {
        return description;
    }

    public void setDescription(class_2561 description) {
        this.description = description;
    }

    public JsonObject getData() {
        return data;
    }

    public void setData(JsonObject data) {
        this.data = data == null ? new JsonObject() : data;
    }

    public String getCreativeTab() {
        return creativeTab;
    }

    public void setCreativeTab(String creativeTab) {
        this.creativeTab = creativeTab;
    }

    public boolean hasGlow(class_1304 slot) {
        return glow.getOrDefault(slot, false);
    }

    public void setGlow(class_1304 slot, boolean value) {
        glow.put(slot, value);
    }

    public boolean hasFullSuit(class_1309 entity) {
        for (class_1304 slot : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
            class_1792 piece = pieces.get(slot);
            if (piece == null)
                continue;
            class_1799 stack = entity.method_6118(slot);
            if (stack.method_7960() || stack.method_7909() != piece)
                return false;
        }
        return !pieces.isEmpty();
    }

    public static SuitSet getWornSuit(class_1309 entity) {
        for (class_1304 slot : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
            class_1799 stack = entity.method_6118(slot);
            if (!stack.method_7960() && stack.method_7909() instanceof SuitSetArmorItem armor) {
                SuitSet suit = armor.getSuitSet();
                if (suit.hasFullSuit(entity))
                    return suit;
            }
        }
        return null;
    }
}
