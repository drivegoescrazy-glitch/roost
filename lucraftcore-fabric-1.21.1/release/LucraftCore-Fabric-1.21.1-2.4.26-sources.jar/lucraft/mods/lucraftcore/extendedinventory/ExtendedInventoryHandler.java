package lucraft.mods.lucraftcore.extendedinventory;

import lucraft.mods.lucraftcore.LucraftCore;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;

/** Persistent extended inventory and its chest-style screen. */
public final class ExtendedInventoryHandler {

    public static final AttachmentType<ExtendedInventoryData> EXTENDED = AttachmentRegistry.createPersistent(
            LucraftCore.id("extended_inventory"), ExtendedInventoryData.CODEC);

    private ExtendedInventoryHandler() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571())
                tick(player);
        });
    }

    public static ExtendedInventoryData get(class_3222 player) {
        return player.getAttachedOrCreate(EXTENDED, ExtendedInventoryData::empty);
    }

    public static class_1799 getStack(class_3222 player, int slot) {
        return get(player).get(slot);
    }

    public static void setStack(class_3222 player, int slot, class_1799 stack) {
        player.setAttached(EXTENDED, get(player).with(slot, stack));
    }

    /** Ticks worn necklaces, mantles and wrist items. */
    public static void tick(class_3222 player) {
        for (int slot = 0; slot <= ExtendedInventoryData.SLOT_WRIST; slot++) {
            class_1799 stack = getStack(player, slot);
            if (!stack.method_7960() && stack.method_7909() instanceof IItemExtendedInventory item)
                item.onWornTick(stack, player);
        }
    }

    /** Opens the five extra slots in a vanilla chest-style screen. */
    public static void open(class_3222 player) {
        class_1277 inventory = createInventory(player);
        player.method_17355(new class_747((syncId, playerInventory, playerEntity) ->
                new class_1707(class_3917.field_18664, syncId, playerInventory,
                        inventory, 1), class_2561.method_43471("container.lucraftcore.extended_inventory")));
    }

    /** Cheat-friendly direct access for commands and self tests. */
    public static class_1277 createInventory(class_3222 player) {
        ExtendedInventoryData data = get(player);
        class_1277 inventory = new class_1277(9) {
            @Override
            public boolean method_5437(int slot, class_1799 stack) {
                return slot >= 0 && slot < ExtendedInventoryData.SIZE;
            }
        };
        for (int i = 0; i < ExtendedInventoryData.SIZE; i++)
            inventory.method_5447(i, data.get(i));
        inventory.method_5489(changed -> {
            ExtendedInventoryData current = get(player);
            for (int i = 0; i < ExtendedInventoryData.SIZE; i++)
                current = current.with(i, changed.method_5438(i));
            player.setAttached(EXTENDED, current);
        });
        return inventory;
    }

    /** Called when a player equips or removes an extended inventory item. */
    public static void notifyChanged(class_1657 player, class_1799 oldStack, class_1799 newStack) {
        if (oldStack.method_7909() instanceof IItemExtendedInventory item)
            item.onUnequipped(oldStack, player);
        if (newStack.method_7909() instanceof IItemExtendedInventory item)
            item.onEquipped(newStack, player);
    }
}
