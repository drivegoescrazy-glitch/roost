package lucraft.mods.lucraftcore.utilities;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class ItemInjection extends class_1792 {

    public ItemInjection() {
        super(new class_1792.class_1793().method_7889(1));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("lucraftcore.info.emptyinjection"));
    }
}
