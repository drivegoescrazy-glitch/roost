package lucraft.mods.lucraftcore.infinity.screen;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

/**
 * The original gauntlet screen: the 256x256 {@code infinity_gauntlet.png}
 * drawn as a 176x211 panel, with no title text (the 1.12 GUI drew none).
 */
public class InfinityGauntletScreen extends class_465<InfinityGauntletScreenHandler> {

    private static final class_2960 TEXTURE = LucraftCore.id("textures/gui/infinity_gauntlet.png");

    public InfinityGauntletScreen(InfinityGauntletScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = 176;
        this.field_2779 = 211;
        this.field_25267 = 8;
        this.field_25268 = 6;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        context.method_25302(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        // The original screen has no title or inventory label.
    }
}
