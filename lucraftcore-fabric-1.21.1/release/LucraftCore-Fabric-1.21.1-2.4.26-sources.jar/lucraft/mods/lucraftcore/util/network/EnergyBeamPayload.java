package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Carries one energy blast shot to the clients that should see it: where the
 * bolt starts, where it ends and its colour. The original mod spawned an
 * {@code EntityEnergyBlast} for this, whose renderer drew a glowing line along
 * the bolt's motion; the port sends the same line to the client instead of
 * keeping a projectile entity in the world.
 */
public record EnergyBeamPayload(class_2487 data) implements class_8710 {

    public static final class_8710.class_9154<EnergyBeamPayload> ID =
            new class_8710.class_9154<>(LucraftCore.id("energy_beam"));

    public static final class_9139<class_9129, EnergyBeamPayload> CODEC = class_9139.method_56434(
            class_9135.field_48556, EnergyBeamPayload::data,
            EnergyBeamPayload::new);

    public static EnergyBeamPayload create(class_243 from, class_243 to, int color) {
        class_2487 data = new class_2487();
        data.method_10549("fx", from.field_1352);
        data.method_10549("fy", from.field_1351);
        data.method_10549("fz", from.field_1350);
        data.method_10549("tx", to.field_1352);
        data.method_10549("ty", to.field_1351);
        data.method_10549("tz", to.field_1350);
        data.method_10569("color", color);
        return new EnergyBeamPayload(data);
    }

    public class_243 from() {
        return new class_243(data.method_10574("fx"), data.method_10574("fy"), data.method_10574("fz"));
    }

    public class_243 to() {
        return new class_243(data.method_10574("tx"), data.method_10574("ty"), data.method_10574("tz"));
    }

    public int color() {
        return data.method_10550("color");
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
