package lucraft.mods.lucraftcore.infinity.screen;

import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityStone;
import lucraft.mods.lucraftcore.util.sounds.LCSounds;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3419;

/**
 * A gauntlet slot that only accepts its own stone type and plays the original
 * equip sound when a stone is placed, like the 1.12 {@code SlotInfinityStone}.
 */
public class SlotInfinityStone extends class_1735 {

    public final EnumInfinityStone type;
    private final class_1657 player;

    public SlotInfinityStone(class_1263 inventory, class_1657 player, EnumInfinityStone type,
                             int index, int x, int y) {
        super(inventory, index, x, y);
        this.type = type;
        this.player = player;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return stack.method_7909() instanceof ItemInfinityStone stone && !stone.isContainer() && stone.getType() == type;
    }

    @Override
    public void method_7668() {
        super.method_7668();
        if (!player.method_37908().field_9236 && method_7677().method_7909() instanceof ItemInfinityStone)
            player.method_37908().method_8396(null, player.method_24515(), LCSounds.INFINITY_STONE_EQUIP,
                    class_3419.field_15248, 1.0F, 1.0F);
    }
}
