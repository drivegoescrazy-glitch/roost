package anvil.infinity.client;

import anvil.infinity.Infinity;
import anvil.infinity.config.InfinityConfig;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityStone;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_630;
import net.minecraft.class_765;
import net.minecraft.class_811;

/**
 * The original stones were not flat textures: Lucraft drew a small rotating 3D
 * cube, tinted with the stone's configured colour and overlaid with two
 * additive glint passes in the shine colour. This reproduces that renderer with
 * the same cube, UV layout, scale, tint and glint animation.
 */
public class StoneItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {

    // Lucraft ships the stone texture; the original renderer used it too.
    private static final class_2960 STONE_TEXTURE = class_2960.method_60655("lucraftcore", "textures/models/stone.png");

    private static class_630 cube;

    /** 6x6x6 cube at the original rotation point (0, 21, 0), 32x16 texture. */
    public static class_630 cube() {
        if (cube == null) {
            class_5609 data = new class_5609();
            data.method_32111().method_32117("stone",
                    class_5606.method_32108().method_32101(0, 0).method_32097(-3.0F, -3.0F, -3.0F, 6, 6, 6),
                    class_5603.method_32090(0.0F, 21.0F, 0.0F));
            cube = class_5607.method_32110(data, 32, 16).method_32109();
        }
        return cube;
    }

    @Override
    public void render(class_1799 stack, class_811 mode, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        if (stack.method_7960() || !(stack.method_7909() instanceof ItemInfinityStone stone))
            return;

        matrices.method_22903();
        try {
            renderCube(stone, matrices, vertexConsumers);
        } catch (Throwable t) {
            Infinity.LOGGER.error("Error rendering an infinity stone", t);
        } finally {
            matrices.method_22909();
        }
    }

    private static void renderCube(ItemInfinityStone stone, class_4587 matrices,
                                   class_4597 vertexConsumers) {
        int color = InfinityConfig.color(stone.getType());
        int shine = InfinityConfig.shine(stone.getType());

        matrices.method_22904(0.5D, -0.1D, 0.5D);
        matrices.method_22905(0.4F, 0.4F, 0.4F);

        // Drawn without back-face culling: the gauntlet's own transform mirrors
        // the model in first and third person, which reverses the winding of the
        // cube's faces and would otherwise leave parts of the stone missing.
        cube().method_22699(matrices, vertexConsumers.getBuffer(class_1921.method_23578(STONE_TEXTURE)),
                class_765.field_32767, class_4608.field_21444, color | 0xFF000000);

        // Two additive glint passes. In the original these were drawn with the
        // drift and the 1/3 scale on the *texture* matrix: only the shine moved,
        // never the cube. The glint layer owns that animation here, so the cube
        // is drawn in place and the layer scrolls the glint over it.
        for (int pass = 0; pass < 2; pass++) {
            cube().method_22699(matrices, vertexConsumers.getBuffer(class_1921.method_23590()),
                    class_765.field_32767, class_4608.field_21444,
                    (shine & 0xFFFFFF) | 0x80000000);
        }
    }
}
