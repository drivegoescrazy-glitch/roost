package lucraft.mods.lucraftcore.utilities.blocks;

import lucraft.mods.lucraftcore.utilities.recipes.BoilerRecipe;
import lucraft.mods.lucraftcore.utilities.recipes.MachineRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import lucraft.mods.lucraftcore.util.energy.EnergyStorage;
import lucraft.mods.lucraftcore.util.fluids.FluidTank;
import lucraft.mods.lucraftcore.util.fluids.FluidUtil;

/** Heats one fluid into another using FE. Tanks hold 5000 mB each. */
public class BoilerBlockEntity extends UtilitiesBlockEntity {

    public static final int TANK_CAPACITY = 5_000;
    public static final int CAPACITY = 50_000;
    public static final int MAX_TRANSFER = 1_000;

    private final FluidTank inputTank = new FluidTank(TANK_CAPACITY);
    private final FluidTank outputTank = new FluidTank(TANK_CAPACITY);
    private final EnergyStorage energy = new EnergyStorage(CAPACITY, MAX_TRANSFER, MAX_TRANSFER);
    private BoilerRecipe activeRecipe;
    private int progress;
    private int maxProgress;

    public BoilerBlockEntity(class_2338 pos, class_2680 state) {
        super(UtilitiesBlocks.BOILER_ENTITY, pos, state, 9);
        inputTank.setListener(this::method_5431);
        outputTank.setListener(this::method_5431);
    }

    public FluidTank getInputTank() {
        return inputTank;
    }

    public FluidTank getOutputTank() {
        return outputTank;
    }

    public EnergyStorage getEnergy() {
        return energy;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, BoilerBlockEntity entity) {
        if (world.field_9236)
            return;
        entity.tickServer();
    }

    private void tickServer() {
        transferBuckets();

        if (activeRecipe == null) {
            activeRecipe = MachineRecipes.findBoiler(inputTank.getFluid(), inputTank.getAmount());
            if (activeRecipe == null)
                return;
            if (outputTank.fill(activeRecipe.output(), activeRecipe.outputAmount(), true) < activeRecipe.outputAmount()) {
                activeRecipe = null;
                return;
            }
            maxProgress = Math.max(1, activeRecipe.time());
            progress = 0;
        }

        int cost = activeRecipe.energyPerTick();
        if (energy.extractEnergy(cost, true) < cost) {
            activeRecipe = null;
            return;
        }
        energy.extractEnergy(cost, false);
        progress++;
        if (progress >= maxProgress) {
            inputTank.drain(activeRecipe.inputAmount(), false);
            outputTank.fill(activeRecipe.output(), activeRecipe.outputAmount(), false);
            activeRecipe = null;
            progress = 0;
        }
        method_5431();
    }

    /** Moves fluids between buckets in the four container slots and the tanks. */
    private void transferBuckets() {
        for (int slot = 0; slot < 2; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960() || !FluidUtil.isFilledBucket(stack))
                continue;
            class_1799 result = FluidUtil.emptyBucketIntoTank(stack, inputTank);
            if (!result.method_7960()) {
                inventory.method_5447(slot, result);
                method_5431();
            }
        }
        for (int slot = 2; slot < 4; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960() || !FluidUtil.isEmptyBucket(stack))
                continue;
            class_1799 result = FluidUtil.fillBucketFromTank(stack, outputTank);
            if (!result.method_7960()) {
                inventory.method_5447(slot, result);
                method_5431();
            }
        }
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10566("InputTank", inputTank.writeNbt(new class_2487()));
        nbt.method_10566("OutputTank", outputTank.writeNbt(new class_2487()));
        nbt.method_10569("Energy", energy.getEnergyStored());
        nbt.method_10569("Progress", progress);
        nbt.method_10569("MaxProgress", maxProgress);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        inputTank.readNbt(nbt.method_10562("InputTank"));
        outputTank.readNbt(nbt.method_10562("OutputTank"));
        energy.setEnergyStored(nbt.method_10550("Energy"));
        progress = nbt.method_10550("Progress");
        maxProgress = nbt.method_10550("MaxProgress");
    }
}
