package lucraft.mods.lucraftcore.utilities.blocks;

import lucraft.mods.lucraftcore.utilities.ItemInstruction;
import lucraft.mods.lucraftcore.utilities.recipes.InstructionRecipe;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import java.util.List;

/**
 * Holds an instruction item and prepares recipes. Crafting consumes the
 * requirements from the player's inventory.
 */
public class ConstructionTableBlockEntity extends UtilitiesBlockEntity {

    private int selectedRecipe = -1;

    public ConstructionTableBlockEntity(class_2338 pos, class_2680 state) {
        super(UtilitiesBlocks.CONSTRUCTION_TABLE_ENTITY, pos, state, 9, 1);
    }

    public List<InstructionRecipe> getRecipes() {
        return getRecipes(inventory.method_5438(0));
    }

    public List<InstructionRecipe> getRecipes(class_1799 instruction) {
        return instruction.method_7960() ? List.of() : ItemInstruction.getRecipes(instruction);
    }

    public InstructionRecipe getSelectedRecipe() {
        List<InstructionRecipe> recipes = getRecipes();
        if (recipes.isEmpty())
            return null;
        if (selectedRecipe < 0 || selectedRecipe >= recipes.size())
            selectedRecipe = 0;
        return recipes.get(selectedRecipe);
    }

    public void selectNextRecipe() {
        List<InstructionRecipe> recipes = getRecipes();
        if (recipes.isEmpty()) {
            selectedRecipe = -1;
            return;
        }
        selectedRecipe = (Math.max(0, selectedRecipe) + 1) % recipes.size();
        method_5431();
    }

    public boolean craft(class_1657 player) {
        return craftFrom(player, inventory.method_5438(0));
    }

    /**
     * Crafts the first recipe from the given instruction stack that the player
     * can pay for, consuming the requirements and giving the output.
     */
    public boolean craftFrom(class_1657 player, class_1799 instruction) {
        for (InstructionRecipe recipe : getRecipes(instruction)) {
            if (!recipe.hasRequirements(player.method_31548()))
                continue;
            recipe.consume(player.method_31548());
            class_1799 output = recipe.getOutput().method_7972();
            if (!player.method_31548().method_7394(output))
                player.method_7328(output, false);
            method_5431();
            return true;
        }
        return false;
    }
}
