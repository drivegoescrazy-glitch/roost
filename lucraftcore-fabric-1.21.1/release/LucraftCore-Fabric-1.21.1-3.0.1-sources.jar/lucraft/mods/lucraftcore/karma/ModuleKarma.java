package lucraft.mods.lucraftcore.karma;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.karma.KarmaStat.KarmaClass;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.Map;

public class ModuleKarma {

    public static class_1291 KNOCKOUT;
    public static class_6880<class_1291> KNOCKOUT_ENTRY;

    public static void register() {
        // Load the persistent karma attachment during initialization, before
        // player data is read.
        KarmaHandler.registerAttachments();
        KNOCKOUT = class_2378.method_10230(class_7923.field_41174, LucraftCore.id("knock_out"), new KnockOutEffect());
        KNOCKOUT_ENTRY = class_7923.field_41174.method_47983(KNOCKOUT);

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.method_5529() instanceof class_3222 player)
                LucraftCore.guard("karma kill handling", () -> KarmaHandler.onKill(player, entity));
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) ->
                dispatcher.register(class_2170.method_9247("karma")
                        .executes(context -> info(context.getSource(), context.getSource().method_9207()))
                        .then(class_2170.method_9247("set")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("target", class_2186.method_9305())
                                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer())
                                                .executes(context -> {
                                                    class_3222 target = class_2186.method_9315(context, "target");
                                                    int amount = IntegerArgumentType.getInteger(context, "amount");
                                                    KarmaHandler.setKarmaStat(target, KarmaStat.MODIFIED, amount);
                                                    context.getSource().method_9226(() -> class_2561.method_43470("Set karma of " + target.method_5477().getString() + " to " + KarmaHandler.getKarma(target)), true);
                                                    return KarmaHandler.getKarma(target);
                                                }))))
                        .then(class_2170.method_9247("add")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("target", class_2186.method_9305())
                                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer())
                                                .executes(context -> {
                                                    class_3222 target = class_2186.method_9315(context, "target");
                                                    int amount = IntegerArgumentType.getInteger(context, "amount");
                                                    KarmaHandler.increaseKarmaStat(target, KarmaStat.MODIFIED, amount);
                                                    context.getSource().method_9226(() -> class_2561.method_43470("Karma of " + target.method_5477().getString() + " is now " + KarmaHandler.getKarma(target)), true);
                                                    return KarmaHandler.getKarma(target);
                                                }))))
                        .then(class_2170.method_9247("knockout")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("target", class_2186.method_9305())
                                        .executes(context -> {
                                            class_3222 target = class_2186.method_9315(context, "target");
                                            target.method_6092(new class_1293(KNOCKOUT_ENTRY, 600, 0));
                                            context.getSource().method_9226(() -> class_2561.method_43470("Knocked out " + target.method_5477().getString()), true);
                                            return 1;
                                        })))
                        .then(class_2170.method_9244("target", class_2186.method_9305())
                                .executes(context -> info(context.getSource(), class_2186.method_9315(context, "target"))))));

        LucraftCore.LOGGER.info("Karma module registered");
    }

    private static int info(class_2168 source, class_3222 player) {
        int karma = KarmaHandler.getKarma(player);
        KarmaClass karmaClass = KarmaHandler.getKarmaClass(player);
        source.method_9226(() -> class_2561.method_43470(player.method_5477().getString() + "'s Karma").method_27692(class_124.field_1067), false);
        Map<String, Integer> stats = KarmaHandler.getStats(player);
        for (KarmaStat stat : KarmaStat.ALL) {
            int count = stats.getOrDefault(stat.getName(), 0);
            source.method_9226(() -> class_2561.method_43470(" " + stat.getName() + ": " + count + " (" + stat.getAmount() + " each = " + (count * stat.getAmount()) + ")"), false);
        }
        source.method_9226(() -> class_2561.method_43470(" Karma: " + karma), false);
        source.method_9226(() -> class_2561.method_43470(" Class: ").method_10852(class_2561.method_43471(karmaClass.getTranslationKey())), false);
        return karma;
    }
}
