package lucraft.mods.lucraftcore.superpowers.suitsets;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_6880;

public class SuitSetArmorItem extends class_1738 {

    private final SuitSet suitSet;
    private final boolean glow;

    public SuitSetArmorItem(class_6880<net.minecraft.class_1741> material, class_8051 type, class_1793 settings,
                            SuitSet suitSet, boolean glow) {
        super(material, type, settings);
        this.suitSet = suitSet;
        this.glow = glow;
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return glow || super.method_7886(stack);
    }

    public SuitSet getSuitSet() {
        return suitSet;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43470(suitSet.getName()).method_27692(class_124.field_1065));
        if (!suitSet.getAbilities().isEmpty()) {
            tooltip.add(class_2561.method_43471("lucraftcore.info.abilities").method_27692(class_124.field_1061));
            for (String ability : suitSet.getAbilities())
                tooltip.add(class_2561.method_43470("- ").method_27692(class_124.field_1061)
                        .method_10852(class_2561.method_43471("ability.lucraftcore." + ability).method_27692(class_124.field_1080)));
        }
    }
}
