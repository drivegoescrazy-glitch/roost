package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public class TeleportAbility extends Ability {

    private final double distance;

    public TeleportAbility(class_3222 player, double distance) {
        super(player);
        this.distance = distance;
        setMaxCooldown(60);
    }

    @Override
    public String getId() {
        return "teleport";
    }

    @Override
    public AbilityType getType() {
        return AbilityType.ACTION;
    }

    @Override
    protected boolean onUse() {
        class_243 direction = player.method_5828(1.0F);
        class_243 eye = player.method_33571();
        class_239 hit = player.method_5745(distance, 0.0F, false);
        class_243 target = hit.method_17783() == class_239.class_240.field_1333
                ? eye.method_1019(direction.method_1021(distance))
                : hit.method_17784().method_1020(direction.method_1021(0.5D));
        player.method_5859(target.field_1352, target.field_1351, target.field_1350);
        player.field_6017 = 0.0F;
        return true;
    }
}
