package lucraft.mods.lucraftcore.client;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.util.network.AbilityBarPayload;
import lucraft.mods.lucraftcore.util.network.UseAbilityPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * HUD ability bar, laid out like the original 1.12 one: a vertical column of
 * 22x22 frames from {@code textures/gui/ability_bar.png} hanging from the top
 * left of the screen, one ability per frame, the selected ability's name shown
 * beside its frame and the use/scroll keys spelled out.
 */
public final class AbilityBarClient {

    private static final class_2960 BAR_TEXTURE = LucraftCore.id("textures/gui/ability_bar.png");
    /** Frame UV inside the 256x256 sheet: the white frame (EnumAbilityBarColor.WHITE). */
    private static final int FRAME_U = 0;
    private static final int FRAME_V = 36;
    private static final int FRAME_SIZE = 22;
    private static final int FRAME_STEP = 21;
    /** How many entries the bar shows at once, as in the original. */
    private static final int ENTRY_SHOW_AMOUNT = 5;

    private static final List<AbilityBarPayload.Entry> ENTRIES = new CopyOnWriteArrayList<>();
    private static int selected;

    private static class_304 nextKey;
    private static class_304 previousKey;
    private static class_304 useKey;

    private AbilityBarClient() {
    }

    public static void register() {
        nextKey = KeyBindingHelper.registerKeyBinding(new class_304("key.lucraftcore.ability_next",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_BRACKET, "category.lucraftcore"));
        previousKey = KeyBindingHelper.registerKeyBinding(new class_304("key.lucraftcore.ability_previous",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_LEFT_BRACKET, "category.lucraftcore"));
        useKey = KeyBindingHelper.registerKeyBinding(new class_304("key.lucraftcore.ability_use",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_V, "category.lucraftcore"));

        // The bar is rebuilt every second and the HUD reads this list while it
        // renders, so the update has to happen on the client thread: mutating it
        // from the network thread is a concurrent-modification crash.
        ClientPlayNetworking.registerGlobalReceiver(AbilityBarPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ENTRIES.clear();
                    ENTRIES.addAll(payload.entries());
                    if (selected >= ENTRIES.size())
                        selected = 0;
                }));

        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (nextKey.method_1436())
                if (!ENTRIES.isEmpty())
                    selected = (selected + 1) % ENTRIES.size();
            while (previousKey.method_1436())
                if (!ENTRIES.isEmpty())
                    selected = (selected - 1 + ENTRIES.size()) % ENTRIES.size();
            while (useKey.method_1436())
                if (!ENTRIES.isEmpty())
                    ClientPlayNetworking.send(new UseAbilityPayload(ENTRIES.get(selected).id()));
        });
    }

    private static void render(class_332 context) {
        // Drawing must never throw out of the HUD hook: an exception here leaves
        // the blend state behind, which is what shows up as the black screen with
        // glowing buttons after a crash.
        LucraftCore.guard("ability bar hud", () -> renderBar(context));
    }

    private static void renderBar(class_332 context) {
        if (ENTRIES.isEmpty())
            return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842)
            return;

        // The original hung the bar from the top left corner, starting at y = 12,
        // and showed five entries starting at the selected one.
        int x = 2;
        int y = 12;
        int shown = Math.min(ENTRY_SHOW_AMOUNT, ENTRIES.size());
        for (int slot = 0; slot < shown; slot++) {
            int index = (selected + slot) % ENTRIES.size();
            AbilityBarPayload.Entry entry = ENTRIES.get(index);
            int frameY = y + slot * FRAME_STEP;
            boolean active = index == selected;

            context.method_25290(BAR_TEXTURE, x, frameY, FRAME_U, FRAME_V, FRAME_SIZE, FRAME_SIZE,
                    256, 256);

            // Ability icon: the original 16x16 sprite drawn inside the 22x22 frame.
            AbilityIcons.draw(context, entry.id(), x + 3, frameY + 3);

            if (entry.enabled())
                context.method_25294(x + 4, frameY + 18, x + 18, frameY + 19, 0xFF00FF88);

            if (entry.cooldown() > 0 && entry.maxCooldown() > 0) {
                int height = Math.round((float) entry.cooldown() / entry.maxCooldown() * 14.0F);
                context.method_25294(x + 4, frameY + 18 - height, x + 18, frameY + 18, 0x99000000);
            }

            if (active) {
                // Name preview to the right of the selected frame, like the
                // original's key/description text.
                String name = displayName(entry.id());
                context.method_25294(x + FRAME_SIZE + 2, frameY + 4, x + FRAME_SIZE + 8
                        + client.field_1772.method_1727(name), frameY + 16, 0x80000000);
                context.method_51433(client.field_1772, name, x + FRAME_SIZE + 5, frameY + 7,
                        0xFEFEFE, true);
            }
        }

        if (ENTRIES.size() > shown) {
            String up = keyName(previousKey);
            String down = keyName(nextKey);
            int hintY = y + shown * FRAME_STEP + 2;
            context.method_51433(client.field_1772, up + " / " + down, x + 4, hintY, 0xFFB0B0B0, true);
            context.method_51433(client.field_1772, keyName(useKey), x + FRAME_SIZE + 5, y + 7,
                    0xFFB0B0B0, true);
        }
    }

    /** "fire_resistance" -> "Fire Resistance", as the original showed display names. */
    private static String displayName(String id) {
        if (id.isEmpty())
            return "?";
        String[] words = id.split("_");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty())
                continue;
            if (builder.length() > 0)
                builder.append(' ');
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return builder.toString();
    }

    private static String keyName(class_304 binding) {
        return binding.method_16007().getString();
    }
}
