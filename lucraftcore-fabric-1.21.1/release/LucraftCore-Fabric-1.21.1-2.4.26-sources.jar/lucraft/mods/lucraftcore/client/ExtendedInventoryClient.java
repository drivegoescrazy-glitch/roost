package lucraft.mods.lucraftcore.client;

import lucraft.mods.lucraftcore.util.network.OpenExtendedInventoryPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Keybind that asks the server to open the extended inventory. */
public final class ExtendedInventoryClient {

    private static class_304 openKey;

    private ExtendedInventoryClient() {
    }

    public static void register() {
        openKey = KeyBindingHelper.registerKeyBinding(new class_304("key.lucraftcore.extended_inventory",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_H, "category.lucraftcore"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.method_1436()) {
                if (client.field_1724 != null)
                    ClientPlayNetworking.send(OpenExtendedInventoryPayload.INSTANCE);
            }
        });
    }
}
