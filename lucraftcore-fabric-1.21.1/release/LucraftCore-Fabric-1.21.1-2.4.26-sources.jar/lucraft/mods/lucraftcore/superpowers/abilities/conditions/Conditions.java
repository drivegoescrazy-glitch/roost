package lucraft.mods.lucraftcore.superpowers.abilities.conditions;

import lucraft.mods.lucraftcore.addonpacks.AddonPackHandler;
import lucraft.mods.lucraftcore.superpowers.PlayerAbilities;
import lucraft.mods.lucraftcore.superpowers.Superpower;
import lucraft.mods.lucraftcore.superpowers.SuperpowerHandler;
import lucraft.mods.lucraftcore.superpowers.abilities.AbilityCondition;
import net.minecraft.class_1291;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.List;

/** Built-in ability conditions, matching the original addon-pack condition types. */
public final class Conditions {

    private Conditions() {
    }

    public record HeldItem(class_2960 item) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            net.minecraft.class_1792 held = class_7923.field_41178.method_10223(item);
            return held != null && (player.method_6047().method_31574(held) || player.method_6079().method_31574(held));
        }

        @Override
        public String type() {
            return "held_item";
        }
    }

    public record HasSuperpower(class_2960 power) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            Superpower superpower = SuperpowerHandler.getPower(player);
            return superpower != null && superpower.getId().equals(power);
        }

        @Override
        public String type() {
            return "superpower";
        }
    }

    public record Level(int level) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            return SuperpowerHandler.getLevel(player) >= level;
        }

        @Override
        public String type() {
            return "level";
        }
    }

    public record AbilityEnabled(String abilityId) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            return PlayerAbilities.isActive(player, abilityId);
        }

        @Override
        public String type() {
            return "ability";
        }
    }

    public record ScoreboardTag(String tag) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            return player.method_5752().contains(tag);
        }

        @Override
        public String type() {
            return "scoreboard_tag";
        }
    }

    public record HasEffect(class_2960 effect) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            class_1291 statusEffect = class_7923.field_41174.method_10223(effect);
            if (statusEffect == null)
                return false;
            class_6880<class_1291> entry = class_7923.field_41174.method_47983(statusEffect);
            return entry != null && player.method_6059(entry);
        }

        @Override
        public String type() {
            return "potion";
        }
    }

    public record AddonPack(String pack) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            return AddonPackHandler.getPacks().stream().anyMatch(info -> info.getFileName().equals(pack));
        }

        @Override
        public String type() {
            return "addonpack";
        }
    }

    public record All(List<AbilityCondition> conditions) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            for (AbilityCondition condition : conditions)
                if (!condition.test(player))
                    return false;
            return true;
        }

        @Override
        public String type() {
            return "and";
        }
    }

    public record Any(List<AbilityCondition> conditions) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            for (AbilityCondition condition : conditions)
                if (condition.test(player))
                    return true;
            return false;
        }

        @Override
        public String type() {
            return "or";
        }
    }

    public record Not(AbilityCondition condition) implements AbilityCondition {
        @Override
        public boolean test(class_3222 player) {
            return !condition.test(player);
        }

        @Override
        public String type() {
            return "not";
        }
    }
}
