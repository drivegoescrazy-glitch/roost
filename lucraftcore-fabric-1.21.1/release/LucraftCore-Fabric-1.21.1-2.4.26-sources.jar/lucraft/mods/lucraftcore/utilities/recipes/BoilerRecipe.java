package lucraft.mods.lucraftcore.utilities.recipes;

import net.minecraft.class_3611;

/** One boiler recipe: a fluid converted into another fluid using FE. */
public record BoilerRecipe(class_3611 input, int inputAmount, class_3611 output, int outputAmount, int energy, int time) {

    public boolean matches(class_3611 fluid, int amount) {
        return fluid == input && amount >= inputAmount;
    }

    public int energyPerTick() {
        return time <= 0 ? energy : Math.max(1, energy / time);
    }
}
