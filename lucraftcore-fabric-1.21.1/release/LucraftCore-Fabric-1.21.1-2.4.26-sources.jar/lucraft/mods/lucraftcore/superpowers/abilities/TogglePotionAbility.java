package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.AbilityType;
import net.minecraft.class_1291;
import net.minecraft.class_3222;
import net.minecraft.class_6880;

public class TogglePotionAbility extends PotionAbility {

    public TogglePotionAbility(class_3222 player, String id, class_6880<class_1291> effect, int amplifier) {
        super(player, id, effect, amplifier);
    }

    @Override
    public AbilityType getType() {
        return AbilityType.TOGGLE;
    }
}
