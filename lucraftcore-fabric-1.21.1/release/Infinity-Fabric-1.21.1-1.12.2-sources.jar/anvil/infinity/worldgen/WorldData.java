package anvil.infinity.worldgen;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_4284;
import net.minecraft.class_7225;

/**
 * Per world record of which stones have already generated, replacing the
 * original {@code WorldSavedData} of the same name and NBT layout.
 */
public class WorldData extends class_18 {

    public static final String NAME = "generated_stones";

    public static final class_18.class_8645<WorldData> TYPE = new class_18.class_8645<>(
            WorldData::new, WorldData::fromNbt, class_4284.field_45077);

    public boolean power;
    public boolean space;
    public boolean reality;
    public boolean soul;
    public boolean time;
    public boolean mind;

    public int powerx;
    public int spacex;
    public int realityx;
    public int soulx;
    public int timex;
    public int mindx;

    public int powerz;
    public int spacez;
    public int realityz;
    public int soulz;
    public int timez;
    public int mindz;

    public WorldData() {
    }

    public static WorldData get(class_3218 world) {
        class_3218 overworld = world.method_8503().method_30002();
        return overworld.method_17983().method_17924(TYPE, NAME);
    }

    public static WorldData fromNbt(class_2487 nbt, class_7225.class_7874 registries) {
        WorldData data = new WorldData();
        data.power = nbt.method_10577("power");
        data.space = nbt.method_10577("space");
        data.reality = nbt.method_10577("reality");
        data.soul = nbt.method_10577("soul");
        data.time = nbt.method_10577("time");
        data.mind = nbt.method_10577("mind");
        data.powerx = nbt.method_10550("powerX");
        data.spacex = nbt.method_10550("spaceX");
        data.realityx = nbt.method_10550("realityX");
        data.soulx = nbt.method_10550("soulX");
        data.timex = nbt.method_10550("timeX");
        data.mindx = nbt.method_10550("mindX");
        data.powerz = nbt.method_10550("powerZ");
        data.spacez = nbt.method_10550("spaceZ");
        data.realityz = nbt.method_10550("realityZ");
        data.soulz = nbt.method_10550("soulZ");
        data.timez = nbt.method_10550("timeZ");
        data.mindz = nbt.method_10550("mindZ");
        return data;
    }

    @Override
    public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registries) {
        nbt.method_10556("power", power);
        nbt.method_10556("space", space);
        nbt.method_10556("reality", reality);
        nbt.method_10556("soul", soul);
        nbt.method_10556("time", time);
        nbt.method_10556("mind", mind);
        nbt.method_10569("powerX", powerx);
        nbt.method_10569("spaceX", spacex);
        nbt.method_10569("realityX", realityx);
        nbt.method_10569("soulX", soulx);
        nbt.method_10569("timeX", timex);
        nbt.method_10569("mindX", mindx);
        nbt.method_10569("powerZ", powerz);
        nbt.method_10569("spaceZ", spacez);
        nbt.method_10569("realityZ", realityz);
        nbt.method_10569("soulZ", soulz);
        nbt.method_10569("timeZ", timez);
        nbt.method_10569("mindZ", mindz);
        return nbt;
    }
}
