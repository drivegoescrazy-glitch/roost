package lucraft.mods.lucraftcore.superpowers;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import lucraft.mods.lucraftcore.superpowers.abilities.AbilityConfig;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import java.util.List;

/** Player and operator commands for data-driven superpowers. */
public final class CommandSuperpower {

    private CommandSuperpower() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) ->
                dispatcher.register(class_2170.method_9247("superpower")
                        .then(class_2170.method_9247("list").executes(CommandSuperpower::list))
                        .then(class_2170.method_9247("info")
                                .then(class_2170.method_9244("power", StringArgumentType.greedyString())
                                        .suggests((context, builder) -> class_2172.method_9265(
                                                SuperpowerRegistry.getAll().stream()
                                                        .map(power -> power.getId().toString()).toList(), builder))
                                        .executes(CommandSuperpower::info)))
                        .then(class_2170.method_9247("set")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .then(class_2170.method_9244("power", StringArgumentType.greedyString())
                                                .suggests((context, builder) -> class_2172.method_9265(
                                                        SuperpowerRegistry.getAll().stream()
                                                                .map(power -> power.getId().toString()).toList(), builder))
                                                .executes(CommandSuperpower::set))))
                        .then(class_2170.method_9247("remove")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .executes(CommandSuperpower::remove)))
                        .then(class_2170.method_9247("xp")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer())
                                                .executes(CommandSuperpower::addXp))))));
    }

    private static int list(CommandContext<class_2168> context) {
        List<Superpower> powers = List.copyOf(SuperpowerRegistry.getAll());
        context.getSource().method_9226(() -> class_2561.method_43470("[Lucraft] " + powers.size() + " superpower(s)"), false);
        for (Superpower power : powers)
            context.getSource().method_9226(() -> class_2561.method_43470(" - " + power.getId()
                    + ": " + power.getName().getString() + " (" + power.getMaxLevel() + " level(s), "
                    + power.getAbilities().size() + " ability config(s))"), false);
        return powers.size();
    }

    private static int info(CommandContext<class_2168> context) {
        class_2960 id = class_2960.method_12829(StringArgumentType.getString(context, "power"));
        Superpower power = SuperpowerRegistry.get(id);
        if (power == null) {
            context.getSource().method_9213(class_2561.method_43470("Unknown superpower " + id));
            return 0;
        }
        context.getSource().method_9226(() -> class_2561.method_43470(power.getId() + " — " + power.getName().getString()
                + " — " + power.getDescription().getString()), false);
        int[] thresholds = power.getLevelXp();
        StringBuilder levels = new StringBuilder();
        for (int index = 0; index < thresholds.length; index++)
            levels.append(index == 0 ? "" : ", ").append("L").append(index + 1).append("@").append(thresholds[index]).append("xp");
        String levelLine = levels.toString();
        context.getSource().method_9226(() -> class_2561.method_43470("levels: " + levelLine), false);
        for (AbilityConfig config : power.getAbilities())
            context.getSource().method_9226(() -> class_2561.method_43470("  ability " + config.abilityId()
                    + " (level " + config.level() + ", energy " + config.energyCost()
                    + ", cooldown " + config.cooldown()
                    + (config.conditions().isEmpty() ? "" : ", conditions " + config.conditions().size()) + ")"), false);
        return 1;
    }

    private static int set(CommandContext<class_2168> context) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_2960 id = class_2960.method_12829(StringArgumentType.getString(context, "power"));
        Superpower power = SuperpowerRegistry.get(id);
        if (power == null) {
            context.getSource().method_9213(class_2561.method_43470("Unknown superpower " + id));
            return 0;
        }
        int count = 0;
        for (class_3222 player : class_2186.method_9312(context, "targets")) {
            SuperpowerHandler.setPower(player, power);
            count++;
        }
        int applied = count;
        context.getSource().method_9226(() -> class_2561.method_43470("Set " + power.getId() + " on " + applied + " player(s)"), true);
        return count;
    }

    private static int remove(CommandContext<class_2168> context) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        int count = 0;
        for (class_3222 player : class_2186.method_9312(context, "targets")) {
            SuperpowerHandler.removePower(player);
            count++;
        }
        int removed = count;
        context.getSource().method_9226(() -> class_2561.method_43470("Removed superpower from " + removed + " player(s)"), true);
        return count;
    }

    private static int addXp(CommandContext<class_2168> context) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        int amount = IntegerArgumentType.getInteger(context, "amount");
        int levels = 0;
        int players = 0;
        for (class_3222 player : class_2186.method_9312(context, "targets")) {
            levels += SuperpowerHandler.addXp(player, amount);
            players++;
        }
        int gained = levels;
        int affected = players;
        context.getSource().method_9226(() -> class_2561.method_43470("Gave " + amount + " xp to " + affected
                + " player(s), " + gained + " level(s) gained"), true);
        return levels;
    }
}
