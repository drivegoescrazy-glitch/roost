package lucraft.mods.lucraftcore.utilities.blocks;

import lucraft.mods.lucraftcore.util.energy.EnergyItemStorage;
import lucraft.mods.lucraftcore.util.energy.EnergyStorage;
import lucraft.mods.lucraftcore.util.energy.EnergyUtil;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/** Burns furnace fuel into FE and charges energy items in its second slot. */
public class FurnaceGeneratorBlockEntity extends UtilitiesBlockEntity {

    public static final int CAPACITY = 100_000;
    public static final int MAX_TRANSFER = 1_000;
    public static final int ENERGY_PER_TICK = 10;

    private final EnergyStorage energy = new EnergyStorage(CAPACITY, MAX_TRANSFER, MAX_TRANSFER);
    private int fuelTicks;
    private int totalFuelTicks;

    public FurnaceGeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(UtilitiesBlocks.FURNACE_GENERATOR_ENTITY, pos, state, 9);
    }

    public EnergyStorage getEnergy() {
        return energy;
    }

    public int getFuelTicks() {
        return fuelTicks;
    }

    public int getTotalFuelTicks() {
        return totalFuelTicks;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, FurnaceGeneratorBlockEntity entity) {
        if (world.field_9236)
            return;
        entity.tickServer();
    }

    private void tickServer() {
        boolean changed = false;
        class_1799 fuelStack = inventory.method_5438(0);

        if (fuelTicks <= 0 && !fuelStack.method_7960() && energy.getEnergyStored() < CAPACITY) {
            int burnTime = FuelValues.burnTime(fuelStack);
            if (burnTime > 0) {
                fuelTicks = burnTime;
                totalFuelTicks = burnTime;
                if (fuelStack.method_31574(class_1802.field_8187))
                    inventory.method_5447(0, new class_1799(class_1802.field_8550));
                else
                    fuelStack.method_7934(1);
                changed = true;
            }
        }

        if (fuelTicks > 0) {
            fuelTicks--;
            energy.receiveEnergy(ENERGY_PER_TICK, false);
            changed = true;
        }

        class_1799 chargeSlot = inventory.method_5438(1);
        if (EnergyItemStorage.isEnergyItem(chargeSlot) && !energy.isEmpty()) {
            if (EnergyUtil.chargeItem(energy, chargeSlot, MAX_TRANSFER) > 0)
                changed = true;
        }

        if (changed)
            method_5431();
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("Energy", energy.getEnergyStored());
        nbt.method_10569("FuelTicks", fuelTicks);
        nbt.method_10569("TotalFuelTicks", totalFuelTicks);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        energy.setEnergyStored(nbt.method_10550("Energy"));
        fuelTicks = nbt.method_10550("FuelTicks");
        totalFuelTicks = nbt.method_10550("TotalFuelTicks");
    }
}
