package lucraft.mods.lucraftcore.superpowers.effects;

import com.google.gson.JsonObject;
import lucraft.mods.lucraftcore.superpowers.abilities.AbilityCondition;
import lucraft.mods.lucraftcore.util.network.LCNetworking;
import lucraft.mods.lucraftcore.util.particles.LCParticles;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Built-in suit and superpower effects. */
public final class Effects {

    private Effects() {
    }

    /** Base class carrying the JSON config and conditions. */
    public abstract static class Configured implements Effect {

        protected final JsonObject data;
        private final List<AbilityCondition> conditions;

        protected Configured(JsonObject data, List<AbilityCondition> conditions) {
            this.data = data == null ? new JsonObject() : data;
            this.conditions = conditions == null ? List.of() : List.copyOf(conditions);
        }

        @Override
        public List<AbilityCondition> conditions() {
            return conditions;
        }

        protected int getInt(String key, int fallback) {
            return data.has(key) ? data.get(key).getAsInt() : fallback;
        }

        protected double getDouble(String key, double fallback) {
            return data.has(key) ? data.get(key).getAsDouble() : fallback;
        }

        protected String getString(String key, String fallback) {
            return data.has(key) ? data.get(key).getAsString() : fallback;
        }
    }

    /** Applies the vanilla glowing outline while active. */
    public static class Glow extends Configured {

        public Glow(JsonObject data, List<AbilityCondition> conditions) {
            super(data, conditions);
        }

        @Override
        public String type() {
            return "glow";
        }

        @Override
        public void onApply(class_3222 player) {
            player.method_6092(new class_1293(class_1294.field_5912,
                    class_1293.field_42106, 0, true, false, false));
        }

        @Override
        public void onRemove(class_3222 player) {
            player.method_6016(class_1294.field_5912);
        }
    }

    /** Leaves a particle trail behind the player. */
    public static class Trail extends Configured {

        public Trail(JsonObject data, List<AbilityCondition> conditions) {
            super(data, conditions);
        }

        @Override
        public String type() {
            return "trail";
        }

        @Override
        public void tick(class_3222 player, int ticks) {
            int interval = Math.max(1, getInt("interval", 2));
            if (ticks % interval != 0)
                return;
            int count = Math.max(1, getInt("count", 1));
            LCNetworking.sendParticle(player.method_51469(), player.method_19538().method_1031(0, 0.9D, 0),
                    LCParticles.COLORED_CLOUD, class_243.field_1353, count);
        }
    }

    /** Spawns particles in a small radius around the player. */
    public static class Aura extends Configured {

        public Aura(JsonObject data, List<AbilityCondition> conditions) {
            super(data, conditions);
        }

        @Override
        public String type() {
            return "aura";
        }

        @Override
        public void tick(class_3222 player, int ticks) {
            int interval = Math.max(1, getInt("interval", 5));
            if (ticks % interval != 0)
                return;
            double radius = Math.max(0.1D, getDouble("radius", 0.8D));
            int count = Math.max(1, getInt("count", 2));
            for (int index = 0; index < count; index++) {
                double angle = player.method_59922().method_43058() * Math.PI * 2.0D;
                double offsetX = Math.cos(angle) * radius;
                double offsetZ = Math.sin(angle) * radius;
                class_243 position = player.method_19538().method_1031(offsetX, player.method_59922().method_43058() * 1.6D, offsetZ);
                LCNetworking.sendParticle(player.method_51469(), position, LCParticles.COLORED_CLOUD, class_243.field_1353, 1);
            }
        }
    }

    /** Renames the player while active and restores the old name afterwards. */
    public static class NameChange extends Configured {

        private static final Map<UUID, class_2561> ORIGINAL_NAMES = new HashMap<>();

        public NameChange(JsonObject data, List<AbilityCondition> conditions) {
            super(data, conditions);
        }

        @Override
        public String type() {
            return "name_change";
        }

        @Override
        public void onApply(class_3222 player) {
            ORIGINAL_NAMES.putIfAbsent(player.method_5667(), player.method_5797());
            player.method_5665(class_2561.method_43470(getString("name", player.method_5477().getString())));
            player.method_5880(true);
        }

        @Override
        public void onRemove(class_3222 player) {
            class_2561 original = ORIGINAL_NAMES.remove(player.method_5667());
            player.method_5665(original);
            player.method_5880(original != null);
        }
    }
}
