package anvil.infinity.helpers;

import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;

/** Broadcasts the "was dusted away" line, as the original helper did. */
public final class SnapMessageHelper {

    private SnapMessageHelper() {
    }

    public static void deathMessage(class_1309 entity) {
        MinecraftServer server = entity.method_5682();
        if (server == null)
            return;
        class_5250 message = class_2561.method_43470(entity.method_5477().getString() + " ")
                .method_10852(class_2561.method_43471("infinity.snap.death"));
        server.method_3760().method_43514(message, false);
    }
}
