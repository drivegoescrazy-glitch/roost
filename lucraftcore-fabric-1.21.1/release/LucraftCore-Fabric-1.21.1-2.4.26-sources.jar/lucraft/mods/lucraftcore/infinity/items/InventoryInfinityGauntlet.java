package lucraft.mods.lucraftcore.infinity.items;

import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import java.util.ArrayList;
import java.util.List;

/** Six stone slots stored in the gauntlet's data component, in original order. */
public class InventoryInfinityGauntlet extends class_1277 {

    public static final EnumInfinityStone[] SLOTS = {
            EnumInfinityStone.SOUL,
            EnumInfinityStone.REALITY,
            EnumInfinityStone.SPACE,
            EnumInfinityStone.POWER,
            EnumInfinityStone.MIND,
            EnumInfinityStone.TIME
    };

    private final class_1799 gauntlet;

    public InventoryInfinityGauntlet(class_1799 gauntlet) {
        super(SLOTS.length);
        this.gauntlet = gauntlet;
        List<class_1799> stored = ItemInfinityGauntlet.getStones(gauntlet);
        for (int i = 0; i < SLOTS.length; i++)
            super.method_5447(i, i < stored.size() ? stored.get(i) : class_1799.field_8037);
        method_5489(inventory -> save());
    }

    public class_1799 getGauntlet() {
        return gauntlet;
    }

    /** Places one stone of the matching type into its slot. */
    public boolean insert(class_1799 stone) {
        if (!(stone.method_7909() instanceof ItemInfinityStone infinityStone) || infinityStone.isContainer())
            return false;
        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] != infinityStone.getType())
                continue;
            if (method_5438(i).method_7960()) {
                method_5447(i, stone.method_46651(1));
                return true;
            }
            return false;
        }
        return false;
    }

    /** Writes the slots back into the gauntlet's component. */
    public void save() {
        if (!(gauntlet.method_7909() instanceof ItemInfinityGauntlet))
            return;
        List<class_1799> list = new ArrayList<>(SLOTS.length);
        for (int i = 0; i < SLOTS.length; i++)
            list.add(method_5438(i));
        gauntlet.method_57379(ItemInfinityGauntlet.STONES, list);
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot < 0 || slot >= SLOTS.length)
            return false;
        return ItemInfinityGauntlet.isStoneCompatible(SLOTS[slot], stack);
    }

    @Override
    public int method_5444() {
        return 1;
    }
}
