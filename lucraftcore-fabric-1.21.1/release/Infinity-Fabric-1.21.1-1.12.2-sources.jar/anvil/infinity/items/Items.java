package anvil.infinity.items;

import anvil.infinity.Infinity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/** The six infinity stones, registered under their original ids. */
public final class Items {

    public static final List<class_1792> ALL = new ArrayList<>();

    public static class_1792 POWER_STONE;
    public static class_1792 MIND_STONE;
    public static class_1792 REALITY_STONE;
    public static class_1792 SOUL_STONE;
    public static class_1792 TIME_STONE;
    public static class_1792 SPACE_STONE;

    private Items() {
    }

    public static void register() {
        POWER_STONE = register("power_stone", new ItemPowerStone());
        MIND_STONE = register("mind_stone", new ItemMindStone());
        REALITY_STONE = register("reality_stone", new ItemRealityStone());
        SOUL_STONE = register("soul_stone", new ItemSoulStone());
        TIME_STONE = register("time_stone", new ItemTimeStone());
        SPACE_STONE = register("space_stone", new ItemSpaceStone());
        Infinity.LOGGER.debug("Registered {} infinity stones", ALL.size());
    }

    private static class_1792 register(String name, class_1792 item) {
        class_1792 registered = class_2378.method_10230(class_7923.field_41178, Infinity.id(name), item);
        ALL.add(registered);
        return registered;
    }
}
