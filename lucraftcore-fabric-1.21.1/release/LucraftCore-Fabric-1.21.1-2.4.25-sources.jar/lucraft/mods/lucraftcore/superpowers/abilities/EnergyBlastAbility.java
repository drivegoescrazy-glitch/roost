package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import lucraft.mods.lucraftcore.superpowers.AbilityType;
import lucraft.mods.lucraftcore.util.network.LCNetworking;
import lucraft.mods.lucraftcore.util.particles.LCParticles;
import lucraft.mods.lucraftcore.util.sounds.LCSounds;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

/**
 * Energy blast: the original laser shot. It damages the first entity in the
 * player's line of sight and sends the glowing bolt the 1.12 mod drew with
 * {@code EntityEnergyBlast} to nearby clients. Costs energy per shot.
 */
public class EnergyBlastAbility extends Ability {

    private final AbilityConfig config;

    public EnergyBlastAbility(class_3222 player, AbilityConfig config) {
        super(player);
        this.config = config;
    }

    @Override
    public String getId() {
        return config.abilityId();
    }

    @Override
    public AbilityType getType() {
        return AbilityType.ACTION;
    }

    @Override
    protected boolean onUse() {
        if (!payEnergy())
            return false;

        class_3218 world = player.method_51469();
        double range = config.getDouble("range", 24.0D);
        float damage = (float) config.getDouble("damage", 4.0D);
        class_243 eye = player.method_33571();
        class_243 direction = player.method_5828(1.0F);
        class_243 end = eye.method_1019(direction.method_1021(range));

        class_3965 blockHit = world.method_17742(new class_3959(eye, end,
                class_3959.class_3960.field_17558, class_3959.class_242.field_1348, player));
        double maxDistance = blockHit.method_17783() == class_239.class_240.field_1333 ? range : eye.method_1022(blockHit.method_17784());
        class_1309 target = AbilityTargeting.findTarget(world, player, eye, direction, maxDistance);

        class_243 hitPos;
        if (target != null)
            hitPos = target.method_5829().method_1005();
        else if (blockHit.method_17783() == class_239.class_240.field_1333)
            hitPos = end;
        else
            hitPos = blockHit.method_17784();

        // The bolt itself: the original's default blast colour is red, the stone
        // blasts use the power stone's purple.
        int color = config.getInt("color", getId().startsWith("infinity_") ? 0x9900FF : 0xFF0000);
        LCNetworking.sendBeam(world, eye, hitPos, color);
        LCNetworking.sendParticle(world, hitPos, LCParticles.COLORED_CLOUD, class_243.field_1353, 6);

        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                LCSounds.ENERGY_BLAST, class_3419.field_15248, 1.0F, 1.0F);
        if (target != null)
            target.method_5643(world.method_48963().method_48815(player, player), damage);
        return true;
    }
}
