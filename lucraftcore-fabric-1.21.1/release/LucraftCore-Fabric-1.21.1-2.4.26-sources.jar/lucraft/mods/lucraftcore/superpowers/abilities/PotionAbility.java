package lucraft.mods.lucraftcore.superpowers.abilities;

import lucraft.mods.lucraftcore.superpowers.Ability;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_3222;
import net.minecraft.class_6880;

public class PotionAbility extends Ability {

    private final String id;
    private final class_6880<class_1291> effect;
    private final int amplifier;

    public PotionAbility(class_3222 player, String id, class_6880<class_1291> effect, int amplifier) {
        super(player);
        this.id = id;
        this.effect = effect;
        this.amplifier = amplifier;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    protected void onTick() {
        if (ticks % 20 == 0)
            player.method_6092(new class_1293(effect, 60, amplifier, true, false, false));
    }

    @Override
    protected void onDisabled() {
        player.method_6016(effect);
    }

    @Override
    protected void cleanup() {
        player.method_6016(effect);
    }
}
