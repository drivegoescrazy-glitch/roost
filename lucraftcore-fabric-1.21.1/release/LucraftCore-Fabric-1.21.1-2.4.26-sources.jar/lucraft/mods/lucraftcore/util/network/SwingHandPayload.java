package lucraft.mods.lucraftcore.util.network;

import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Asks clients to show an arm swing on an entity. */
public record SwingHandPayload(int entityId, boolean mainHand) implements class_8710 {

    public static final class_8710.class_9154<SwingHandPayload> ID = new class_8710.class_9154<>(LucraftCore.id("swing_hand"));

    public static final class_9139<class_9129, SwingHandPayload> CODEC = class_9139.method_56435(
            class_9135.field_48550, SwingHandPayload::entityId,
            class_9135.field_48547, SwingHandPayload::mainHand,
            SwingHandPayload::new);

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
