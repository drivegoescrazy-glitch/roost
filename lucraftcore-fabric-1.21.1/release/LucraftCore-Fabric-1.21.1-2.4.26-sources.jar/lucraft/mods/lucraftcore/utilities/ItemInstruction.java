package lucraft.mods.lucraftcore.utilities;

import com.mojang.serialization.Codec;
import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.utilities.recipes.InstructionRecipe;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;
import java.util.ArrayList;
import java.util.List;

public class ItemInstruction extends class_1792 {

    public static final class_9331<List<String>> RECIPES = class_2378.method_10230(class_7923.field_49658,
            LucraftCore.id("instruction_recipes"),
            class_9331.<List<String>>method_57873().method_57881(Codec.list(Codec.STRING)).method_57880());

    public ItemInstruction() {
        super(new class_1792.class_1793().method_7889(1));
    }

    public static class_1799 createStack(InstructionRecipe recipe) {
        return createStack(List.of(recipe.getId()));
    }

    public static class_1799 createStack(List<class_2960> ids) {
        class_1799 stack = new class_1799(UtilitiesItems.INSTRUCTION);
        List<String> list = new ArrayList<>();
        for (class_2960 id : ids)
            list.add(id.toString());
        stack.method_57379(RECIPES, list);
        return stack;
    }

    public static List<InstructionRecipe> getRecipes(class_1799 stack) {
        List<String> ids = stack.method_57824(RECIPES);
        List<InstructionRecipe> recipes = new ArrayList<>();
        if (ids == null)
            return recipes;
        for (String value : ids) {
            class_2960 id = class_2960.method_12829(value);
            InstructionRecipe recipe = id == null ? null : InstructionRecipe.byId(id);
            if (recipe != null)
                recipes.add(recipe);
        }
        return recipes;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        List<InstructionRecipe> recipes = getRecipes(stack);
        if (recipes.isEmpty()) {
            tooltip.add(class_2561.method_43471("lucraftcore.info.noinstructionrecipes").method_27692(class_124.field_1080));
            return;
        }
        for (InstructionRecipe recipe : recipes) {
            tooltip.add(recipe.getOutput().method_7964().method_27661().method_27692(class_124.field_1067));
            for (class_1799 requirement : recipe.getRequirements())
                tooltip.add(class_2561.method_43470(" - " + requirement.method_7947() + "x ").method_10852(requirement.method_7964()).method_27692(class_124.field_1080));
        }
    }
}
