package lucraft.mods.lucraftcore.util.triggers;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import java.util.Optional;

/** Advancement trigger fired when a player uses an ability. */
public class AbilityUsedCriterion extends class_4558<AbilityUsedCriterion.Conditions> {

    @Override
    public Codec<Conditions> method_54937() {
        return Conditions.CODEC;
    }

    public void trigger(class_3222 player, String abilityId) {
        class_2960 id = class_2960.method_12829(abilityId);
        method_22510(player, conditions -> conditions.ability().map(ability -> ability.equals(id)).orElse(true));
    }

    public record Conditions(Optional<class_5258> player, Optional<class_2960> ability)
            implements class_4558.class_8788 {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_5258.field_47234.optionalFieldOf("player").forGetter(Conditions::comp_2029),
                class_2960.field_25139.optionalFieldOf("ability").forGetter(Conditions::ability)
        ).apply(instance, Conditions::new));
    }
}
