package anvil.infinity;

import anvil.infinity.abilities.InfinityAbilities;
import anvil.infinity.capabilities.GauntletUserInformation;
import anvil.infinity.command.GeneratedStonesCommand;
import anvil.infinity.compat.CompatHandler;
import anvil.infinity.config.InfinityConfig;
import anvil.infinity.helpers.ImmortalityHandler;
import anvil.infinity.registry.InfinityEffects;
import anvil.infinity.items.Items;
import anvil.infinity.registry.InfinitySounds;
import anvil.infinity.worldgen.InfinityWorldGenerator;
import lucraft.mods.lucraftcore.infinity.ModuleInfinity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Infinityraft: infinity stones, the snap and the stone temples.
 *
 * <p>Fabric 1.21.1 port of the original 1.12.2 Forge addon. The gauntlet,
 * generator and stone handling live in the ported Lucraft: Core; this mod adds
 * the six stones, their abilities, the snap, the temple worldgen and the
 * {@code /generatedStones} command.</p>
 */
public class Infinity implements ModInitializer {

    public static final String MOD_ID = "infinity";
    public static final String NAME = "Infinityraft";
    public static final String VERSION = "1.12";

    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** The original "Lucraft: Core | Infinity" creative tab. */
    public static class_1761 TAB;

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        LOGGER.info("Infinityraft (Fabric 1.21.1) loading");
        InfinityConfig.load();
        InfinitySounds.register();
        InfinityEffects.register();
        Items.register();
        InfinityAbilities.register();
        CompatHandler.check();
        ImmortalityHandler.register();
        registerTab();
        GeneratedStonesCommand.register();
        InfinityWorldGenerator.register();
        GauntletUserInformation.logRegistration();
        LOGGER.info("Infinityraft loaded: {} stones, {} abilities", Items.ALL.size(),
                InfinityAbilities.REGISTERED.size());
    }

    private void registerTab() {
        TAB = class_2378.method_10230(class_7923.field_44687, id("infinity"),
                FabricItemGroup.builder()
                        .method_47321(class_2561.method_43471("itemGroup.tabInfinity"))
                        .method_47320(() -> new class_1799(ModuleInfinity.INFINITY_GAUNTLET))
                        .method_47317((context, entries) -> {
                            // Same order as the original tab: gauntlet, cast, generator, stones.
                            if (ModuleInfinity.INFINITY_GAUNTLET != null)
                                entries.method_45421(ModuleInfinity.INFINITY_GAUNTLET);
                            if (ModuleInfinity.INFINITY_GAUNTLET_CAST != null)
                                entries.method_45421(ModuleInfinity.INFINITY_GAUNTLET_CAST);
                            if (ModuleInfinity.INFINITY_GENERATOR != null)
                                entries.method_45421(ModuleInfinity.INFINITY_GENERATOR);
                            for (var item : Items.ALL)
                                entries.method_45421(item);
                        })
                        .method_47324());
    }
}
