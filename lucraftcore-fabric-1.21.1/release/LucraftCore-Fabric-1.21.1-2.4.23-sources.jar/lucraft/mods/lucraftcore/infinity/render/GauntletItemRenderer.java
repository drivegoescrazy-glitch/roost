package lucraft.mods.lucraftcore.infinity.render;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.infinity.EnumInfinityStone;
import lucraft.mods.lucraftcore.infinity.items.InventoryInfinityGauntlet;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import java.util.List;

/**
 * The original 3D gauntlet item renderer: the gauntlet model with the texture
 * of the 1.12 mod in its fingerless variant, worn around the hand while held,
 * and every inserted stone drawn as the same small cube the stones use
 * elsewhere, at the knuckle positions the original renderer defined.
 *
 * <p>The placement is the original one. The 1.12 mod described the item with a
 * {@code builtin/entity} model whose {@code display} block positioned the item
 * cube per camera mode, and its {@code TileEntityItemStackRenderer} then moved
 * the model inside that cube with {@code translate(0.5, 1.8, 0.5)} and
 * {@code scale(-1, -1, -1)}. Both halves are reproduced here unchanged, so the
 * cuff ends up around the player's hand in first and third person exactly as it
 * did in the original mod.</p>
 *
 * <p>In the inventory the item is the original 2D icon instead of the model,
 * drawn flat over the whole slot.</p>
 */
public class GauntletItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {

    public static final class_2960 TEXTURE = LucraftCore.id("textures/models/infinity_gauntlet.png");
    /** The original 1.12 item icon, used for the inventory and only there. */
    public static final class_2960 ICON_TEXTURE = LucraftCore.id("textures/item/infinity_gauntlet.png");

    @Override
    public void render(class_1799 stack, class_811 mode, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        if (stack.method_7960() || !(stack.method_7909() instanceof ItemInfinityGauntlet))
            return;

        matrices.method_22903();

        if (mode == class_811.field_4317) {
            // In the inventory the gauntlet is the original 2D sprite of the mod,
            // not the 3D model.
            renderIcon(matrices, vertexConsumers, light, overlay);
            matrices.method_22909();
            return;
        }

        GauntletModel.Built model = GauntletModel.create();
        // The gauntlet is worn over the hand: the original ships the version
        // without the separate finger parts (LCConfig.fingersOnGauntlet = false).
        GauntletModel.setFingersVisible(model, false);

        // The body of the original TileEntityItemStackRenderer.
        matrices.method_22904(0.5D, 1.8D, 0.5D);
        matrices.method_22905(-1.0F, -1.0F, -1.0F);
        model.root().method_22699(matrices,
                vertexConsumers.getBuffer(class_1921.method_23578(TEXTURE)),
                light, overlay, 0xFFFFFFFF);

        List<class_1799> stones = ItemInfinityGauntlet.getStones(stack);
        for (int i = 0; i < stones.size() && i < InventoryInfinityGauntlet.SLOTS.length; i++) {
            class_1799 stone = stones.get(i);
            if (stone.method_7960())
                continue;
            BuiltinItemRendererRegistry.DynamicItemRenderer renderer =
                    BuiltinItemRendererRegistry.INSTANCE.get(stone.method_7909());
            if (renderer == null)
                continue;

            matrices.method_22903();
            translateToStone(matrices, InventoryInfinityGauntlet.SLOTS[i]);
            matrices.method_22905(0.35F, 0.35F, 0.35F);
            matrices.method_22904(-0.5D, -0.5D, -0.5D);
            renderer.render(stone, mode, matrices, vertexConsumers, light, overlay);
            matrices.method_22909();
        }

        matrices.method_22909();
    }

    /**
     * Draws the original 16x16 item icon as a flat quad filling the item cube.
     * The item cube is the 0..1 box the GUI hands to builtin renderers, and the
     * GUI matrix flips Y, so the texture rows are reversed to keep the sprite
     * upright.
     */
    private static void renderIcon(class_4587 matrices, class_4597 vertexConsumers,
                                   int light, int overlay) {
        class_4587.class_4665 entry = matrices.method_23760();
        class_4588 buffer = vertexConsumers.getBuffer(class_1921.method_23578(ICON_TEXTURE));
        float z = 0.5F;
        iconVertex(buffer, entry, light, overlay, 0.0F, 0.0F, z, 0.0F, 1.0F);
        iconVertex(buffer, entry, light, overlay, 1.0F, 0.0F, z, 1.0F, 1.0F);
        iconVertex(buffer, entry, light, overlay, 1.0F, 1.0F, z, 1.0F, 0.0F);
        iconVertex(buffer, entry, light, overlay, 0.0F, 1.0F, z, 0.0F, 0.0F);
    }

    private static void iconVertex(class_4588 buffer, class_4587.class_4665 entry, int light, int overlay,
                                   float x, float y, float z, float u, float v) {
        buffer.method_22918(entry.method_23761(), x, y, z)
                .method_39415(0xFFFFFFFF)
                .method_22913(u, v)
                .method_22922(overlay)
                .method_60803(light)
                .method_60831(entry, 0.0F, 0.0F, 1.0F);
    }

    /** The original per-stone placement on the gauntlet. */
    private static void translateToStone(class_4587 matrices, EnumInfinityStone type) {
        switch (type) {
            case SOUL -> matrices.method_22904(0.119D, 1.07D, -0.14D);
            case REALITY -> matrices.method_22904(0.044D, 1.07D, -0.14D);
            case SPACE -> matrices.method_22904(-0.0375D, 1.07D, -0.14D);
            case POWER -> matrices.method_22904(-0.118D, 1.07D, -0.14D);
            case MIND -> matrices.method_22904(0.006D, 1.164D, -0.14D);
            case TIME -> {
                matrices.method_22904(-0.14D, 1.095D, 0.062D);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
            }
        }
    }
}
