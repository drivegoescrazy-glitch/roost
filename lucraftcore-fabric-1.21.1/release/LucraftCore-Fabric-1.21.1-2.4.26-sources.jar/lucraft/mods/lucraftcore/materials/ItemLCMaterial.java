package lucraft.mods.lucraftcore.materials;

import lucraft.mods.lucraftcore.LCConfig;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class ItemLCMaterial extends class_1792 {

    private final Material material;
    private final Material.Component component;

    public ItemLCMaterial(Material material, Material.Component component) {
        super(new class_1792.class_1793().method_7889(64));
        this.material = material;
        this.component = component;
    }

    public Material getMaterial() {
        return material;
    }

    public Material.Component getComponent() {
        return component;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (!world.field_9236 && LCConfig.radiation && material.isRadioactive() && entity instanceof class_1309 living) {
            living.method_6092(new class_1293(ModuleMaterials.radiationEntry(), 100, 1));
        }
        super.method_7888(stack, world, entity, slot, selected);
    }
}
