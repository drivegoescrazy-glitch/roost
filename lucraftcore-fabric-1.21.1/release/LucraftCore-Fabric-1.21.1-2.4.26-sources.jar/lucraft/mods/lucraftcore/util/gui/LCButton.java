package lucraft.mods.lucraftcore.util.gui;

import net.minecraft.class_2561;
import net.minecraft.class_4185;

/** Button with the mod's default narration. */
public class LCButton extends class_4185 {

    public LCButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    public static LCButton of(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        return new LCButton(x, y, width, height, message, onPress);
    }
}
