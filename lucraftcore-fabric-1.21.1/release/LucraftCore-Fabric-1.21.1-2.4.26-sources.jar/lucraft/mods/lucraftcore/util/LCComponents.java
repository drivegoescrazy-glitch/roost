package lucraft.mods.lucraftcore.util;

import com.mojang.serialization.Codec;
import lucraft.mods.lucraftcore.LucraftCore;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

/** Data components shared by the engine layer. */
public final class LCComponents {

    /** Stored energy of an item, in FE. */
    public static final class_9331<Integer> ENERGY = class_2378.method_10230(
            class_7923.field_49658,
            LucraftCore.id("energy"),
            class_9331.<Integer>method_57873()
                    .method_57881(Codec.INT)
                    .method_57882(class_9135.field_48550)
                    .method_57880());

    private LCComponents() {
    }

    /** Forces class initialisation so the components are registered. */
    public static void register() {
        LucraftCore.LOGGER.debug("Registered data components (energy)");
    }
}
