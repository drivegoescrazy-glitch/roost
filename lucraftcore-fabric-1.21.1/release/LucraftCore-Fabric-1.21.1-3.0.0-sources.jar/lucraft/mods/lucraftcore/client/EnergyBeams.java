package lucraft.mods.lucraftcore.client;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.util.network.EnergyBeamPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The energy blast bolt. The 1.12 mod fired an {@code EntityEnergyBlast} — a
 * throwable moving at 1.5 blocks per tick whose renderer drew a glowing line
 * one block long along its motion with ten additive glow layers and a white
 * core ({@code LCRenderHelper.drawGlowingLine}). The beam is drawn the same way
 * here: the shot travels from the player's eyes to the point the server's
 * hitscan reached, then disappears.
 *
 * <p>The list is written from the client thread only (the payload handler
 * schedules onto it), and the renderer is exception safe: the matrix stack is
 * always popped, so a bad frame can never leave the game's renderer wedged on
 * the main menu.</p>
 */
public final class EnergyBeams {

    private static final class_2960 WHITE_TEXTURE = LucraftCore.id("textures/models/white.png");

    /** The original throwable's throw velocity. */
    private static final double SPEED = 1.5D;
    /** Length of the glowing line the original renderer drew. */
    private static final double BOLT_LENGTH = 1.0D;
    /** Half width of the white core, in blocks. */
    private static final double CORE_HALF_WIDTH = 0.045D;
    /** Glow layers: half width multiplier and alpha, outermost first. */
    private static final float[][] LAYERS = {
            {3.0F, 0.10F},
            {2.0F, 0.16F},
            {1.3F, 0.26F},
            {0.7F, 1.0F}
    };

    /** One shot in flight. */
    private static final class Beam {
        private final class_243 from;
        private final class_243 direction;
        private final double length;
        private final int color;
        private double travelled;

        private Beam(class_243 from, class_243 direction, double length, int color) {
            this.from = from;
            this.direction = direction;
            this.length = length;
            this.color = color;
        }

        private boolean finished() {
            return this.travelled > this.length + BOLT_LENGTH;
        }
    }

    private static final List<Beam> BEAMS = new CopyOnWriteArrayList<>();

    private EnergyBeams() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> LucraftCore.guard("energy beam tick", () -> {
            for (Beam beam : BEAMS) {
                beam.travelled += SPEED;
                if (beam.finished())
                    BEAMS.remove(beam);
            }
        }));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(EnergyBeams::render);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> BEAMS.clear());
    }

    /** Adds a shot that the server resolved. Must be called on the client thread. */
    public static void add(EnergyBeamPayload payload) {
        class_243 from = payload.from();
        class_243 to = payload.to();
        if (!isFinite(from) || !isFinite(to))
            return;
        class_243 delta = to.method_1020(from);
        double length = delta.method_1033();
        if (!(length > 1.0E-4D) || !Double.isFinite(length))
            return;
        BEAMS.add(new Beam(from, delta.method_1029(), length, payload.color()));
    }

    public static void clear() {
        BEAMS.clear();
    }

    private static void render(WorldRenderContext context) {
        if (BEAMS.isEmpty())
            return;
        class_4587 matrices = context.matrixStack();
        if (matrices == null || context.consumers() == null || context.camera() == null)
            return;

        class_243 camera = context.camera().method_19326();
        matrices.method_22903();
        try {
            matrices.method_22904(-camera.field_1352, -camera.field_1351, -camera.field_1350);
            class_4587.class_4665 entry = matrices.method_23760();
            class_4588 buffer = context.consumers().getBuffer(class_1921.method_42600(WHITE_TEXTURE));

            for (Beam beam : BEAMS) {
                // The bolt is a segment trailing the travelling head, clipped at
                // the muzzle so the shot grows out of the player's hand.
                double head = Math.min(beam.travelled, beam.length);
                double tail = Math.max(0.0D, head - BOLT_LENGTH);
                if (head <= tail)
                    continue;
                class_243 start = beam.from.method_1019(beam.direction.method_1021(tail));
                class_243 end = beam.from.method_1019(beam.direction.method_1021(head));

                class_243 axis = end.method_1020(start);
                if (!(axis.method_1027() > 1.0E-6D))
                    continue;
                axis = axis.method_1029();
                // A single ribbon turned to face the camera. Two crossed ribbons
                // would be edge-on (and so invisible) from most angles and show
                // as an X where they overlap, so the bolt is one billboarded quad.
                class_243 across = perpendicular(axis, camera.method_1020(start));

                float red = ((beam.color >> 16) & 0xFF) / 255.0F;
                float green = ((beam.color >> 8) & 0xFF) / 255.0F;
                float blue = (beam.color & 0xFF) / 255.0F;

                for (int layer = 0; layer < LAYERS.length; layer++) {
                    boolean core = layer == LAYERS.length - 1;
                    float r = core ? 1.0F : red;
                    float g = core ? 1.0F : green;
                    float b = core ? 1.0F : blue;
                    float a = LAYERS[layer][1] * (core ? 1.0F : 0.55F);
                    double halfWidth = CORE_HALF_WIDTH * LAYERS[layer][0];
                    quad(buffer, entry, start, end, across, halfWidth, r, g, b, a);
                }
            }
        } catch (Exception e) {
            // Never let a bad shot take the frame (and the client) down.
            lucraft.mods.lucraftcore.LucraftCore.reportError("energy beam render", e);
        } finally {
            matrices.method_22909();
        }
    }

    private static boolean isFinite(class_243 vec) {
        return Double.isFinite(vec.field_1352) && Double.isFinite(vec.field_1351) && Double.isFinite(vec.field_1350);
    }

    /** A unit vector perpendicular to {@code axis}, bent towards {@code hint}. */
    private static class_243 perpendicular(class_243 axis, class_243 hint) {
        class_243 side = axis.method_1036(hint);
        if (side.method_1027() < 1.0E-6D) {
            // Looking straight down the beam: any perpendicular will do.
            side = axis.method_1036(Math.abs(axis.field_1351) > 0.9D
                    ? new class_243(1.0D, 0.0D, 0.0D) : new class_243(0.0D, 1.0D, 0.0D));
        }
        return side.method_1029();
    }

    private static void quad(class_4588 buffer, class_4587.class_4665 entry, class_243 start, class_243 end,
                             class_243 across, double halfWidth, float r, float g, float b, float a) {
        class_243 offset = across.method_1021(halfWidth);
        class_243 a0 = start.method_1020(offset);
        class_243 a1 = start.method_1019(offset);
        class_243 b0 = end.method_1020(offset);
        class_243 b1 = end.method_1019(offset);
        // Emitted with both windings: the beam has to be visible from either side.
        vertex(buffer, entry, a0, r, g, b, a);
        vertex(buffer, entry, b0, r, g, b, a);
        vertex(buffer, entry, b1, r, g, b, a);
        vertex(buffer, entry, a1, r, g, b, a);
        vertex(buffer, entry, a1, r, g, b, a);
        vertex(buffer, entry, b1, r, g, b, a);
        vertex(buffer, entry, b0, r, g, b, a);
        vertex(buffer, entry, a0, r, g, b, a);
    }

    private static void vertex(class_4588 buffer, class_4587.class_4665 entry, class_243 pos,
                               float r, float g, float b, float a) {
        buffer.method_56824(entry, (float) pos.field_1352, (float) pos.field_1351, (float) pos.field_1350)
                .method_22915(r, g, b, a)
                .method_22913(0.5F, 0.5F)
                .method_22922(class_4608.field_21444)
                .method_60803(class_765.field_32767)
                .method_60831(entry, 0.0F, 1.0F, 0.0F);
    }
}
