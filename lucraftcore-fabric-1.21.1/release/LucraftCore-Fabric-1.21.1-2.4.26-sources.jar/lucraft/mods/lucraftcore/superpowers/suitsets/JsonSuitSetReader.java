package lucraft.mods.lucraftcore.superpowers.suitsets;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.superpowers.AbilityRegistry;
import lucraft.mods.lucraftcore.superpowers.effects.EffectReader;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class JsonSuitSetReader {

    private static final String[] SLOT_NAMES = {"head", "chest", "legs", "feet"};
    private static final net.minecraft.class_1304[] SLOTS = {
            net.minecraft.class_1304.field_6169, net.minecraft.class_1304.field_6174,
            net.minecraft.class_1304.field_6172, net.minecraft.class_1304.field_6166
    };
    private static final class_1738.class_8051[] TYPES = {
            class_1738.class_8051.field_41934, class_1738.class_8051.field_41935, class_1738.class_8051.field_41936, class_1738.class_8051.field_41937
    };

    public static SuitSet read(class_2960 id, JsonObject json) {
        try {
            JsonObject armor = json.has("armor_material") ? json.getAsJsonObject("armor_material") : new JsonObject();
            int durability = armor.has("durability") ? armor.get("durability").getAsInt() : 15;
            int enchantability = armor.has("enchantibility") ? armor.get("enchantibility").getAsInt() : 9;
            float toughness = armor.has("toughness") ? armor.get("toughness").getAsFloat() : 0.0F;
            int[] reduction = new int[]{1, 3, 2, 1};
            if (armor.has("damage_reduction_amounts")) {
                JsonArray array = armor.getAsJsonArray("damage_reduction_amounts");
                for (int i = 0; i < Math.min(4, array.size()); i++)
                    reduction[i] = array.get(i).getAsInt();
            }

            Map<class_1738.class_8051, Integer> defense = new EnumMap<>(class_1738.class_8051.class);
            for (int i = 0; i < TYPES.length; i++)
                defense.put(TYPES[i], reduction[i]);

            class_1741 material = new class_1741(defense, enchantability,
                    class_3417.field_14862,
                    () -> class_1856.field_9017,
                    List.of(new class_1741.class_9196(class_2960.method_60655(id.method_12836(), "suit/" + id.method_12832()))),
                    toughness, 0.0F);
            class_2378.method_10230(class_7923.field_48976, id, material);
            class_6880<class_1741> materialEntry = class_7923.field_48976.method_47983(material);

            String name = text(json.get("name"), id.method_12832());
            SuitSet suit = new SuitSet(id, name);
            suit.setDescription(class_2561.method_43470(text(json.get("description"), "")));
            if (json.has("parent"))
                suit.setParent(class_2960.method_12829(json.get("parent").getAsString()));
            if (json.has("creative_tab"))
                suit.setCreativeTab(json.get("creative_tab").getAsString());
            if (json.has("data") && json.get("data").isJsonObject())
                suit.setData(json.getAsJsonObject("data"));
            suit.getEffects().addAll(EffectReader.read(json));

            JsonObject parts = json.has("armor_parts") ? json.getAsJsonObject("armor_parts") : new JsonObject();
            for (int i = 0; i < SLOTS.length; i++) {
                if (!parts.has(SLOT_NAMES[i]))
                    continue;
                class_2960 itemId = class_2960.method_60655(id.method_12836(), id.method_12832() + "_" + SLOT_NAMES[i]);
                JsonObject part = parts.getAsJsonObject(SLOT_NAMES[i]);
                boolean glow = part.has("glow") && part.get("glow").getAsBoolean();
                class_1792 item = new SuitSetArmorItem(materialEntry, TYPES[i],
                        new class_1792.class_1793().method_7895(durability * durabilityFactor(TYPES[i])), suit, glow);
                class_2378.method_10230(class_7923.field_41178, itemId, item);
                suit.setPiece(SLOTS[i], item);
                suit.setGlow(SLOTS[i], glow);
            }

            if (json.has("abilities")) {
                JsonArray abilities = json.getAsJsonArray("abilities");
                for (JsonElement element : abilities) {
                    String ability = null;
                    if (element.isJsonPrimitive())
                        ability = element.getAsString();
                    else if (element.isJsonObject()) {
                        JsonObject object = element.getAsJsonObject();
                        if (object.has("ability"))
                            ability = object.get("ability").getAsString();
                        else if (object.has("type"))
                            ability = object.get("type").getAsString();
                    }
                    if (ability != null) {
                        String key = ability.contains(":") ? ability.substring(ability.indexOf(':') + 1) : ability;
                        if (AbilityRegistry.exists(key))
                            suit.getAbilities().add(key);
                        else
                            LucraftCore.LOGGER.warn("Suit {} uses unknown ability {}", id, ability);
                    }
                }
            }

            SuitSetRegistry.register(suit);
            LucraftCore.LOGGER.info("Registered suit set {} ({} pieces, {} abilities, {} effects)",
                    id, suit.getPieces().size(), suit.getAbilities().size(), suit.getEffects().size());
            return suit;
        } catch (Exception e) {
            LucraftCore.LOGGER.error("Could not read suit set {}", id, e);
            return null;
        }
    }

    private static int durabilityFactor(class_1738.class_8051 type) {
        return switch (type) {
            case field_41934 -> 11;
            case field_41935 -> 16;
            case field_41936 -> 15;
            case field_41937 -> 13;
            default -> 1;
        };
    }

    private static String text(JsonElement element, String fallback) {
        if (element == null || element.isJsonNull())
            return fallback;
        if (element.isJsonPrimitive())
            return element.getAsString();
        JsonObject object = element.getAsJsonObject();
        if (object.has("text"))
            return object.get("text").getAsString();
        if (object.has("translate"))
            return object.get("translate").getAsString();
        return fallback;
    }
}
