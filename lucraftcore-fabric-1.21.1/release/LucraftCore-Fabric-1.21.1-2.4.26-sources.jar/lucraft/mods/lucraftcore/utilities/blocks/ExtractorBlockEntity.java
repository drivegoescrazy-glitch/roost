package lucraft.mods.lucraftcore.utilities.blocks;

import lucraft.mods.lucraftcore.utilities.recipes.ExtractorRecipe;
import lucraft.mods.lucraftcore.utilities.recipes.MachineRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import lucraft.mods.lucraftcore.util.energy.EnergyStorage;

/** Consumes FE to turn an input item into an output item. */
public class ExtractorBlockEntity extends UtilitiesBlockEntity {

    public static final int CAPACITY = 100_000;
    public static final int MAX_TRANSFER = 1_000;

    private final EnergyStorage energy = new EnergyStorage(CAPACITY, MAX_TRANSFER, MAX_TRANSFER);
    private ExtractorRecipe activeRecipe;
    private int progress;
    private int maxProgress;

    public ExtractorBlockEntity(class_2338 pos, class_2680 state) {
        super(UtilitiesBlocks.EXTRACTOR_ENTITY, pos, state, 9, 2, 3);
    }

    public EnergyStorage getEnergy() {
        return energy;
    }

    public int getProgress() {
        return progress;
    }

    public int getMaxProgress() {
        return maxProgress;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, ExtractorBlockEntity entity) {
        if (world.field_9236)
            return;
        entity.tickServer();
    }

    private void tickServer() {
        if (activeRecipe == null) {
            activeRecipe = findRecipe();
            if (activeRecipe == null)
                return;
            maxProgress = Math.max(1, activeRecipe.time());
            progress = 0;
        }

        if (progress <= 0 && !canInsertOutput(activeRecipe.output())) {
            activeRecipe = null;
            return;
        }

        if (energy.extractEnergy(activeRecipe.energyPerTick(), true) < activeRecipe.energyPerTick()) {
            activeRecipe = null;
            return;
        }

        energy.extractEnergy(activeRecipe.energyPerTick(), false);
        progress++;
        method_5431();

        if (progress >= maxProgress) {
            complete(activeRecipe);
            activeRecipe = null;
            progress = 0;
            maxProgress = 0;
        }
    }

    private ExtractorRecipe findRecipe() {
        for (int slot = 0; slot <= 1; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960())
                continue;
            ExtractorRecipe recipe = MachineRecipes.findExtractor(stack);
            if (recipe != null && canInsertOutput(recipe.output()))
                return recipe;
        }
        return null;
    }

    private boolean canInsertOutput(class_1799 output) {
        for (int slot = 2; slot <= 3; slot++) {
            class_1799 existing = inventory.method_5438(slot);
            if (existing.method_7960())
                return true;
            if (class_1799.method_31577(existing, output)
                    && existing.method_7947() + output.method_7947() <= existing.method_7914())
                return true;
        }
        return false;
    }

    private void complete(ExtractorRecipe recipe) {
        for (int slot = 0; slot <= 1; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (!recipe.matches(stack))
                continue;
            stack.method_7934(recipe.inputCount());
            if (stack.method_7960())
                inventory.method_5447(slot, class_1799.field_8037);
            break;
        }
        for (int slot = 2; slot <= 3; slot++) {
            class_1799 existing = inventory.method_5438(slot);
            if (existing.method_7960()) {
                inventory.method_5447(slot, recipe.output().method_7972());
                return;
            }
            if (class_1799.method_31577(existing, recipe.output())) {
                existing.method_7933(recipe.output().method_7947());
                return;
            }
        }
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("Energy", energy.getEnergyStored());
        nbt.method_10569("Progress", progress);
        nbt.method_10569("MaxProgress", maxProgress);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        energy.setEnergyStored(nbt.method_10550("Energy"));
        progress = nbt.method_10550("Progress");
        maxProgress = nbt.method_10550("MaxProgress");
    }
}
