package lucraft.mods.lucraftcore.infinity.blocks;

import lucraft.mods.lucraftcore.LucraftCore;
import lucraft.mods.lucraftcore.infinity.ModuleInfinity;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityStone;
import lucraft.mods.lucraftcore.util.energy.EnergyBlock;
import lucraft.mods.lucraftcore.util.energy.EnergyStorage;
import lucraft.mods.lucraftcore.util.energy.EnergyUtil;
import lucraft.mods.lucraftcore.util.inventory.StackInventory;
import lucraft.mods.lucraftcore.utilities.blocks.UtilitiesBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/** Generates FE from a contained infinity stone and pushes it to neighbours. */
public class InfinityGeneratorBlockEntity extends UtilitiesBlockEntity implements EnergyBlock {

    public static final int CAPACITY = 2_000_000;
    public static final int MAX_TRANSFER = 100_000;

    private final EnergyStorage energy = new EnergyStorage(CAPACITY, MAX_TRANSFER, MAX_TRANSFER);

    public InfinityGeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModuleInfinity.INFINITY_GENERATOR_ENTITY, pos, state, new StackInventory(9) {
            @Override
            public boolean method_5437(int slot, class_1799 stack) {
                return slot == 0 && stack.method_7909() instanceof ItemInfinityStone;
            }
        });
    }

    @Override
    public EnergyStorage getEnergy() {
        return energy;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, InfinityGeneratorBlockEntity entity) {
        if (!world.field_9236)
            LucraftCore.guard("infinity generator tick", () -> entity.tickServer(world));
    }

    private void tickServer(class_1937 world) {
        boolean changed = false;
        class_1799 stoneStack = inventory.method_5438(0);
        if (energy.getEnergyStored() < CAPACITY && stoneStack.method_7909() instanceof ItemInfinityStone stone) {
            int accepted = energy.receiveEnergy(stone.getEnergyPerTick(stoneStack), false);
            changed |= accepted > 0;
        }

        if (energy.getEnergyStored() > 0) {
            int budget = Math.min(energy.getEnergyStored(), MAX_TRANSFER);
            for (class_2350 direction : class_2350.values()) {
                if (budget <= 0)
                    break;
                if (!(world.method_8321(field_11867.method_10093(direction)) instanceof EnergyBlock target))
                    continue;
                int moved = EnergyUtil.transfer(energy, target.getEnergy(), budget);
                budget -= moved;
                changed |= moved > 0;
            }
        }

        if (changed)
            method_5431();
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("Energy", energy.getEnergyStored());
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        energy.setEnergyStored(nbt.method_10550("Energy"));
    }
}
