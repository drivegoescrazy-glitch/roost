package lucraft.mods.lucraftcore.superpowers;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class CommandAbility {

    private static final SuggestionProvider<class_2168> ABILITY_IDS =
            (context, builder) -> class_2172.method_9265(AbilityRegistry.ABILITIES.keySet(), builder);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) ->
                dispatcher.register(class_2170.method_9247("ability")
                        .then(class_2170.method_9247("list").executes(context -> {
                            context.getSource().method_9226(() -> class_2561.method_43470("Abilities: " + String.join(", ", AbilityRegistry.ABILITIES.keySet())), false);
                            return AbilityRegistry.ABILITIES.size();
                        }))
                        .then(class_2170.method_9247("grant")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .then(class_2170.method_9244("ability", StringArgumentType.word())
                                                .suggests(ABILITY_IDS)
                                                .executes(context -> {
                                                    String id = StringArgumentType.getString(context, "ability");
                                                    int count = 0;
                                                    for (class_3222 player : class_2186.method_9312(context, "targets")) {
                                                        if (PlayerAbilities.grant(player, id))
                                                            count++;
                                                    }
                                                    int granted = count;
                                                    context.getSource().method_9226(() -> class_2561.method_43470("Granted " + id + " to " + granted + " player(s)"), true);
                                                    return count;
                                                }))))
                        .then(class_2170.method_9247("revoke")
                                .requires(source -> source.method_9259(2))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .then(class_2170.method_9244("ability", StringArgumentType.word())
                                                .suggests(ABILITY_IDS)
                                                .executes(context -> {
                                                    String id = StringArgumentType.getString(context, "ability");
                                                    int count = 0;
                                                    for (class_3222 player : class_2186.method_9312(context, "targets")) {
                                                        if (PlayerAbilities.revoke(player, id))
                                                            count++;
                                                    }
                                                    int revoked = count;
                                                    context.getSource().method_9226(() -> class_2561.method_43470("Revoked " + id + " from " + revoked + " player(s)"), true);
                                                    return count;
                                                }))))
                        .then(class_2170.method_9247("use")
                                .then(class_2170.method_9244("ability", StringArgumentType.word())
                                        .suggests(ABILITY_IDS)
                                        .executes(context -> use(context.getSource(), context.getSource().method_9207(),
                                                StringArgumentType.getString(context, "ability")))))
                        .then(class_2170.method_9247("status")
                                .then(class_2170.method_9244("target", class_2186.method_9305())
                                        .executes(context -> {
                                            class_3222 player = class_2186.method_9315(context, "target");
                                            context.getSource().method_9226(() -> class_2561.method_43470(player.method_5477().getString() + ": " + PlayerAbilities.getGranted(player)), false);
                                            return 1;
                                        })))));
    }

    private static int use(class_2168 source, class_3222 player, String id) {
        Ability ability = PlayerAbilities.ability(player, id);
        if (ability == null) {
            source.method_9213(class_2561.method_43470("You do not have the ability " + id));
            return 0;
        }
        boolean used = ability.use();
        if (used)
            source.method_9226(() -> class_2561.method_43470(id + " -> " + (ability.isEnabled() ? "enabled" : "disabled")), false);
        return used ? 1 : 0;
    }
}
