package anvil.infinity.snap;

import anvil.infinity.capabilities.GauntletUserInformation;
import anvil.infinity.capabilities.SnapPlayerData;
import anvil.infinity.config.InfinityConfig;
import anvil.infinity.helpers.GauntletHelper;
import anvil.infinity.registry.InfinityEffects;
import lucraft.mods.lucraftcore.infinity.items.ItemInfinityGauntlet;
import lucraft.mods.lucraftcore.karma.KarmaHandler;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1463;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** The snap: kills half of everything, or whatever the selected result says. */
public final class SnapHelper {

    private SnapHelper() {
    }

    public static boolean snap(class_3222 entity) {
        if (!GauntletHelper.hasFullGauntlet(entity))
            return false;

        SnapPlayerData data = GauntletUserInformation.get(entity);
        MinecraftServer server = entity.method_5682();
        if (server == null)
            return false;

        switch (data.snapResult()) {
            case KILLHALF -> {
                List<class_1297> entities = new ArrayList<>();
                for (class_3218 world : server.method_3738())
                    world.method_27909().forEach(entities::add);

                class_5250 message = class_2561.method_43470(entity.method_5477().getString() + ": ")
                        .method_10852(class_2561.method_43471("infinity.snap.text"))
                        .method_27695(class_124.field_1064, class_124.field_1067);
                server.method_3760().method_43514(message, false);

                Random random = new Random();
                boolean kill = false;
                for (class_1297 other : entities) {
                    if (other != entity && other instanceof class_1309 living && kill
                            && !(other instanceof class_1463))
                        living.method_6092(snapEffect(random.nextInt(1191) - 10));
                    kill = !kill;
                }
                return true;
            }
            case DESTROYSTONES -> {
                entity.method_6033(1.0F);
                class_1799 mainHand = entity.method_6047();
                class_1799 offHand = entity.method_6079();
                if (mainHand.method_7909() instanceof ItemInfinityGauntlet)
                    entity.method_6122(class_1268.field_5808, new class_1799(mainHand.method_7909()));
                if (offHand.method_7909() instanceof ItemInfinityGauntlet)
                    entity.method_6122(class_1268.field_5810, new class_1799(offHand.method_7909()));
                entity.method_5643(entity.method_51469().method_48963().method_48829(),
                        entity.method_6032() / 10.0F - 0.01F);
            }
            case CREATIVE -> {
                if (InfinityConfig.snapCreative && entity != null) {
                    if (entity.method_7337())
                        entity.method_7336(net.minecraft.class_1934.field_9215);
                    else
                        entity.method_7336(net.minecraft.class_1934.field_9220);
                    return true;
                }
            }
            case KILLEVIL -> {
                List<class_1297> entities = new ArrayList<>();
                for (class_3218 world : server.method_3738())
                    world.method_27909().forEach(entities::add);

                class_5250 message = class_2561.method_43470(entity.method_5477().getString() + ": ")
                        .method_10852(class_2561.method_43471("infinity.snap.irontext"))
                        .method_27695(class_124.field_1061, class_124.field_1067);
                server.method_3760().method_43514(message, false);

                Random random = new Random();
                for (class_1297 other : entities) {
                    if (other == entity || !(other instanceof class_1309 living))
                        continue;
                    if (other instanceof class_1569) {
                        living.method_6092(snapEffect(random.nextInt(1191) - 10));
                        continue;
                    }
                    if (other instanceof class_1657 player && KarmaHandler.getKarma(player) < 1)
                        living.method_6092(snapEffect(random.nextInt(1191) - 10));
                }
            }
            case BRINGBACK, RECREATE -> {
                // Both were marked WIP in the original and did nothing.
            }
        }
        return false;
    }

    /**
     * The original used the rolled duration as-is; negative values never
     * expired. They are clamped to one tick here so a dusted entity always
     * finishes its snap (0.8% of the original's rolls were negative).
     */
    private static class_1293 snapEffect(int duration) {
        var entry = class_7923.field_41174.method_47983(InfinityEffects.SNAP);
        return new class_1293(entry, Math.max(1, duration));
    }
}
